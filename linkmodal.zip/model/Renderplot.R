
newObjectPlot <- function(input,output,id,plot,height = 280){
  
  source('model/SmartObserve.R',local = T)
  this       <- environment()
  obs        <- newObserve()
  obj        <- list()
  obj$id     <- id
  init       <- TRUE
  
  obs$isInit <- function() return(init)
  
  obj$actionListener <- function(action){
    
    obs$add(action)
  }
  
  obj$plotOutput <- function(){
    
    tipo <- plot$CD_ID_TIPO
    plot <- NULL
    
    if(tipo == 1 || #scatter
       tipo == 2 || #line
       tipo == 3 || #box
       tipo == 4 || #histogram
       tipo == 5 || #density
       tipo == 6 || #bar
       tipo == 7    # Pie
    )
    {
      
      plot <- plotly::plotlyOutput(outputId  = id, height = height)
    }
    else if(tipo == 8){ #MAP
      
      plot <- leaflet::leafletOutput(outputId = id, height = height)
      
    }
    
    return(plot)
  }

  obj$plotRender <- function(expr,env = parent.frame(), quoted = FALSE,proxy  = FALSE){
    
    tipo <- plot$CD_ID_TIPO
    
    if(tipo == 1 || #scatter
       tipo == 2 || #line
       tipo == 3 || #box
       tipo == 4 || #histogram
       tipo == 5 || #density
       tipo == 6 || #bar
       tipo == 7    # Pie
    )
    {
      if (!quoted) {
        quoted <- TRUE
        expr <- substitute(expr)
      }
      shiny::installExprFunction(expr, "func", env, quoted)
      expr2 <- quote(getFromNamespace("prepareWidget", "plotly")(func()))
      renderFunc <- htmlwidgets::shinyRenderWidget(expr2,
                                                   plotly::plotlyOutput, environment(), 
                                                   quoted, 
                                                   cacheHint = list(label = "renderPlotly", userExpr = expr))
      
      output[[id]] <-  shiny::snapshotPreprocessOutput(renderFunc, function(value) {
        json   <- from_JSON(value)
        json$x <- json$x[setdiff(names(json$x), c("visdat","cur_data", "attrs"))]
        to_JSON(json)
      })
     
    }
    else if(tipo == 8){ #MAP

      if(!proxy)
      {
        if (!quoted) {
          quoted <- TRUE
          expr   <- substitute(expr)
        }
        
        output[[id]] <-  htmlwidgets::shinyRenderWidget(expr,leaflet::leafletOutput,env,quoted = quoted)
      }
      else{
        expr()
      }

     }
    
  }

  obj$plot <- function(setor,plot,df,displayModeBar = FALSE,proxy = FALSE){

    gg.tmp    <- NULL

    if('Line' == plot$NAME_TIPO)
    {
      gg.tmp <- plotLine(plot,df,displayModeBar)
    }
    else if('Area' == plot$NAME_TIPO)
    {
      gg.tmp <- plotArea(plot,df,displayModeBar)
    }
    else if('Box' == plot$NAME_TIPO)
    {
      gg.tmp <- plotBox(plot,df,displayModeBar)
    }
    else if('Scatter' == plot$NAME_TIPO)
    {
      gg.tmp <- plotScatter(plot,df,displayModeBar)
    }
    else if('Histogram' == plot$NAME_TIPO)
    {
      gg.tmp <- plotHistogram(plot,df,displayModeBar)
    }
    else if('Density' == plot$NAME_TIPO)
    {
      gg.tmp <- plotDensity(plot,df,displayModeBar)
    }
    else if('Bar' == plot$NAME_TIPO)
    {
      gg.tmp <- plotBar(plot,df,displayModeBar)
    }
    else if('Pie chart' == plot$NAME_TIPO)
    {
      gg.tmp <- plotPie(plot,df,displayModeBar)
    }
    else if('Heat Map' == plot$NAME_TIPO){

      gg.tmp <- plotHeadMap(plot,df,displayModeBar)
    }
    else if('Radar' == plot$NAME_TIPO){
      
      gg <- plotRadar(plot,df,displayModeBar)
    } 
    else if('Map' == plot$NAME_TIPO)
    {
      gg.tmp <- plotMap(id,setor,plot,df,proxy,displayModeBar)
    }
    
    if(init)
       init <<- FALSE
    
     return(gg.tmp)
  }
  
  obj$destroy <- function(){
    
    #destroy this object
    obs$destroy()
    rm(list = ls(all.names = T,envir = this),envir = this)
  }
  
  return(obj)
}

#Plot line
plotLine <- function(plot,df,displayModeBar = F){
 
  text.x      <- plot$TEXT_X_PLOT
  text.y      <- plot$TEXT_Y_PLOT
  text.legend <- plot$TEXT_LEGEND_PLOT
  
  df.point <- df %>% group_by(.data$LEGEND) %>% summarise(Y = last(Y),X= last(X),.groups = 'drop')

  gg <- ggplot2::ggplot(data = df, ggplot2::aes(y = Y,
                                                x = X, 
                                                colour = LEGEND,
                                                text =  purrr::map(
                                                  paste0(
                                                    text.y,": ",Y,
                                                    "\n",text.x,": ",X,
                                                    "\n",text.legend,": ",LEGEND
                                                  ),
                                                  htmltools::HTML
                                                )))
  gg <- gg + ggplot2::geom_line()
  gg <- gg + ggplot2::geom_point(data = df.point,ggplot2::aes(x = X,y = Y,colour = LEGEND))
  gg <- gg + ggplot2::labs(x = text.x,y = text.y,colour = text.legend)
  gg <- gg + themasPlotyGGplot()
 
  gg <- toolsVerticalHozintalLine(plot,gg)
  
  #contrui plotlty
  configDisplayBar(plotly::ggplotly(gg,tooltip = 'text'),text.legend,displayModeBar)
 
}

plotArea <- function(plot,df,displayModeBar = F){
  
  text.x      <- plot$TEXT_X_PLOT
  text.y      <- plot$TEXT_Y_PLOT
  text.legend <- plot$TEXT_LEGEND_PLOT
  
  gg <- ggplot2::ggplot(data = df,ggplot2::aes(y = Y, x = X,fill = LEGEND))
  gg <- gg + ggplot2::geom_area(alpha = 0.4)
  gg <- gg + ggplot2::labs(x = text.x,y = text.y,fill = text.legend)
  gg <- gg + themasPlotyGGplot()

  gg <- toolsVerticalHozintalLine(plot,gg)
  
  #contrui plotlty
  configDisplayBar(gg,text.legend,displayModeBar)
  
}

plotBox <- function(plot,df,displayModeBar = F){
  
  text.x      <- plot$TEXT_X_PLOT
  text.y      <- plot$TEXT_Y_PLOT
  text.legend <- plot$TEXT_LEGEND_PLOT
  
  gg <- ggplot2::ggplot(data = df,ggplot2::aes(y = Y, x = X,fill = LEGEND))
  gg <- gg + ggplot2::geom_boxplot()
  gg <- gg + ggplot2::labs(x = text.x,y = text.y,fill = text.legend)
  gg <- gg + themasPlotyGGplot(text.x.angle = 90)
  
  gg <- toolsVerticalHozintalLine(plot,gg)
  
  #contrui plotlty
  configDisplayBar(gg,text.legend,displayModeBar)
  
}

plotScatter <- function(plot,df,displayModeBar = F){
  
  text.x      <- plot$TEXT_X_PLOT
  text.y      <- plot$TEXT_Y_PLOT
  text.legend <- plot$TEXT_LEGEND_PLOT
  
  gg <- ggplot2::ggplot(data = df,ggplot2::aes(y = Y, x = X,colour = LEGEND))
  gg <- gg + ggplot2::geom_point()
  gg <- gg + ggplot2::labs(x = text.x,y = text.y,colour = text.legend)
  
  if(!(plot$TIPO_X_DATA == "time"))
     gg <- gg + ggplot2::geom_smooth(method = 'lm',formula = y ~ x,se = F,linetype = "dashed")
  
  gg <- gg + themasPlotyGGplot()
  
  gg <- toolsVerticalHozintalLine(plot,gg)
  
  configDisplayBar(gg,text.legend,displayModeBar)
}

plotHistogram <- function(plot,df,displayModeBar = F){
  
  text.x      <- plot$TEXT_X_PLOT
  text.y      <- plot$TEXT_Y_PLOT
  text.legend <- plot$TEXT_LEGEND_PLOT

  gg <- ggplot2::ggplot(data = df,ggplot2::aes(x = X,fill = LEGEND))
  gg <- gg + ggplot2::geom_histogram(bins = 30,binwidth = 0.1,position = 'dodge')
  gg <- gg + ggplot2::stat_bin(bins = 30,binwidth = 0.1,geom='text', color='black',ggplot2::aes(label=..count..),position= ggplot2::position_dodge(width = 0.1),size = 2.5)
  gg <- gg + ggplot2::labs(x = text.x,y = text.y,fill = text.legend)
  gg <- gg + themasPlotyGGplot()

  gg <- toolsVerticalHozintalLine(plot,gg)
  
  configDisplayBar(gg,text.legend,displayModeBar) %>% hoverTextReplace(c("count","X","LEGEND"),c(text.y,text.x,text.legend))
}

plotDensity <- function(plot,df,displayModeBar = F){
  
  text.x      <- plot$TEXT_X_PLOT
  text.y      <- plot$TEXT_Y_PLOT
  text.legend <- plot$TEXT_LEGEND_PLOT
  
  gg <- ggplot2::ggplot(data = df,ggplot2::aes(x = X,fill = LEGEND))
  gg <- gg + ggplot2::geom_density(alpha = 0.8)
  gg <- gg + ggplot2::labs(x = text.x,y = text.y,fill = text.legend)
  gg <- gg + themasPlotyGGplot()
  
  gg <- toolsVerticalHozintalLine(plot,gg)
  
  configDisplayBar(gg,text.legend,displayModeBar) %>% hoverTextReplace(c("density","X","LEGEND"),c(text.y,text.x,text.legend))
  
}

plotBar <- function(plot,df,displayModeBar = F){
  
  text.x      <- plot$TEXT_X_PLOT
  text.y      <- plot$TEXT_Y_PLOT
  text.legend <- plot$TEXT_LEGEND_PLOT
  
  gg <- ggplot2::ggplot(data = df,ggplot2::aes(y = FREQ,x = X,fill = LEGEND))
  gg <- gg + ggplot2::geom_bar(stat="identity", position = ggplot2::position_dodge())
  gg <- gg + ggplot2::labs(x = text.x,y = text.y,fill = text.legend)
  gg <- gg + ggplot2::geom_text(ggplot2::aes(label = paste0(PORCENTAL,'%')),position = ggplot2::position_dodge(width = 0.9),size = 2.5)
  gg <- gg + ggplot2::coord_flip()
  gg <- gg + themasPlotyGGplot()
  
  gg <- toolsVerticalHozintalLine(plot,gg)
  
  configDisplayBar(gg,text.legend,displayModeBar)
  
}

plotPie <- function(plot,df,displayModeBar = F){
  
  text.x      <- plot$TEXT_X_PLOT
  text.y      <- plot$TEXT_Y_PLOT
  text.legend <- plot$TEXT_LEGEND_PLOT
  
  gg <- plotly::plot_ly()
  legendas <- unique(df$LEGEND)
  x.pie <- cumsum(rep(1 / length(legendas),length(legendas)))
  
  for (index in seq_along(legendas)) {
    
    legend <- legendas[index]
    df.aux <- df %>% filter(LEGEND == legend) %>% mutate(COLOR = gg_color_hue(length(unique(X))))
    
    gg <- gg %>% plotly::add_pie(
      data = df.aux,
      labels = ~X,
      values = ~PER,
      textposition = 'inside',
      textinfo = 'label+percent',
      insidetextfont = list(color = '#333333'),
      hoverinfo = 'text',
      text = ~paste(X,' ',PER, '%'),
      hole = 0.5,
      marker = list(colors =  ~COLOR),
      domain = list(y = c(0.0,1),x = c(ifelse(index == 1,0.0,x.pie[index - 1]),x.pie[index]))
      #title=legend
    )
  }
  
  configDisplayBar(gg,text.legend,displayModeBar)
  
}

plotHeadMap <- function(plot,df,displayModeBar = F){
  
  text.x      <- plot$TEXT_X_PLOT
  text.y      <- plot$TEXT_Y_PLOT
  text.legend <- plot$TEXT_LEGEND_PLOT
  
  gg <- ggplot2::ggplot(data = df,ggplot2::aes(y = Y, x = X,fill = LEGEND))
  gg <- gg + ggplot2::geom_tile()
  gg <- gg + ggplot2::labs(x = text.x,y = text.y,colour = text.legend)
  gg <- gg + themasPlotyGGplot()
  
  configDisplayBar(gg,text.legend,displayModeBar)
  
}

plotRadar <- function(plot,df,displayModeBar = F){
  
  text.x      <- plot$TEXT_X_PLOT
  text.y      <- plot$TEXT_Y_PLOT
  text.legend <- plot$TEXT_LEGEND_PLOT

  gg <-  ggradar::ggradar(df)
  
  configDisplayBar(gg,text.legend,displayModeBar)
  
}

plotMap <- function(id,setor,plot,df,proxy,displayModeBar){

  atributos   <- foreach(
                  i = 1:nrow(df),
                  .combine = 'rbind',
                  .inorder = T
                ) %do%{
    
                       x <- df[i,]
                       
                       if(x$ID.X == x$ID.Y){
                         chip <- rlist::list.filter(setor$CHIPS,CD_ID_CHIP == x$ID.X)[[1]]
                         data.frame(
                           IMAGE = paste0("www/image/icone.map/", chip$IMAGE_MODEL),
                           POPUP = paste0( "<b>",chip$NAME_MODEL,": </b>",chip$NAME_CHIP,"<br>")
                         )
                       }else{
                         data.frame(IMAGE = NA,CHIP = NA)
                       }
                       
                     }# end foreach
   #append colunas
   df <- cbind(df,atributos)
   
   if(proxy){
     
     gg <- leaflet::leafletProxy(mapId = id,data = df) %>%
           leaflet::clearImages() %>%
           leaflet::clearShapes() %>%
           leaflet::clearPopups() %>%
           leaflet::clearMarkers()
     
   }else{
     
     gg <- leaflet::leaflet(data = df,
                            options = leaflet::leafletOptions(
                              attributionControl = displayModeBar,
                              attributionControl = displayModeBar,
                              doubleClickZoom    = displayModeBar,
                              scrollWheelZoom    = displayModeBar )) %>%
                             leaflet::addTiles()
   }
  
   gg <- gg %>% 
         leaflet::addMarkers(
              lng = ~ X,
              lat = ~ Y,
              icon = list(iconUrl = ~ IMAGE,iconSize = c(35,35)),
              popup = ~ POPUP,
              labelOptions = labelOptions(
                textOnly = F,
                style = list("box-shadow" = "3px 3px rgba(0,0,0,0.25)", "border-color" = "rgba(0,0,0,0.5)"))
            )
  
  if(nrow(plot$tools) > 0)
  {
    #insert tools
    for (i in 1:nrow(plot$tools)) {
      
      tool <- plot$tools[i,]
      
      if(tool$CD_ID_PTP == 1)
      {
        p <- sf::st_as_sfc(tool$SCRIPT_PT)
        gg <- gg %>% leaflet::addPolygons(
          data = p,
          color = 'lightblue',
          fillOpacity = .5,
          popup = paste0(
            "<b>Cerca virtual: </b>",tool$NAME_PT,"<br>"),
          labelOptions = labelOptions(
            textOnly = F,
            style = list("box-shadow" = "3px 3px rgba(0,0,0,0.25)", "border-color" = "rgba(0,0,0,0.5)"))
        )
      }else{
        
        p <- jsonlite::fromJSON(tool$SCRIPT_PT)
        
        gg <- gg %>% leaflet::addMarkers(
          group = 'marcapont',
          data =  p$coordenadas,
          icon = makeIcon(iconUrl = paste0('image/icone.map/', p$icone)),
          popup = paste0(
            "<b>Marcador: </b>",tool$NAME_PT,"<br>"),
          labelOptions = labelOptions(
            textOnly = F,
            style = list("box-shadow" = "3px 3px rgba(0,0,0,0.25)", "border-color" = "rgba(0,0,0,0.5)"))
        )
        
      }
    }
  }
   
  return(gg)
  
}

configDisplayBar <- function(gg,text.legend,displayModeBar = F){
  
  if(displayModeBar)
  {
    plotly::ggplotly(gg) %>%
      plotly::config(displaylogo = FALSE,
                     displayModeBar = displayModeBar,
                     locale = "pt-br",
                     modeBarButtonsToRemove = list("toImage")
      ) %>%
      layoutPlotyDefault(legend.text = text.legend) %>% plotly::toWebGL()
    
  }else{
    
    plotly::ggplotly(gg) %>%
      plotly::config(displaylogo = FALSE,
                     displayModeBar = displayModeBar,
                     locale = "pt-br",
                     modeBarButtonsToRemove = list("toImage")
      ) %>%
      layoutPloty(legend.text = text.legend)
  }
  
}

toolsVerticalHozintalLine <- function(plot,gg){
  
  if(nrow(plot$tools) > 0)
  {
    #insert tools
    for (i in 1:nrow(plot$tools)) {
      
      tool <- plot$tools[i,]
      
      if(tool$CD_ID_PTP %in% seq(from = 3,to = 15,by = 2)) #line vertical
      {
        obj <- jsonlite::fromJSON(tool$SCRIPT_PT) 
        gg  <- gg + ggplot2::geom_vline(xintercept = obj$value,color = obj$color,linetype  = obj$tipo,size = obj$size)
        
      }else if(tool$CD_ID_PTP %in% seq(from = 4,to = 16,by = 2)) #line horizontal
      {
        obj <- jsonlite::fromJSON(tool$SCRIPT_PT) 
        gg  <- gg + ggplot2::geom_hline(yintercept = obj$value,color = obj$color,linetype = obj$tipo,size = obj$size)
      }
    }
  }
  
  return(gg)
  
}

