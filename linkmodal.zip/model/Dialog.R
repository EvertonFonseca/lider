dialogModal <- function(title,size = 'm',...,footer,callback = NULL){
   
   input  <- get('input')
   output <- get('output')
   
   script <-  htmltools::tags$script(
      paste0(
             "var $content = $('#shiny-modal');
              var intervalId = setInterval(function(){
                  if(!$content.is(':empty')){
                      //do stuff
                      var height = document.getElementById('shiny-modal').clientHeight;
                      var width  = document.getElementById('shiny-modal').clientWidth;
                      Shiny.setInputValue('refreshModal',{'width':width,'height':height,'date':new Date()});
                      clearInterval(intervalId);
                  }
              }, 1000);"))
   
   observeEvent(input$refreshModal,{

      if(!is.null(callback))
         callback(input$refreshModal)
      
      shinyjs::runjs("try{document.getElementById('progressoLoader').remove();}catch(e){}")
      assign('status.loader',value = FALSE,immediate = T,envir = .GlobalEnv)
      
   },ignoreInit = TRUE,once = TRUE)
   
   modal <- modalDialog(
      title = title,
      ...,
      script,
      footer = footer
   )
   
   return(modal)
}

dialogConfirm <- function(title,text,type = 'success',bt_labels = c("Não","Sim"),callback){
   
   input   <- get('input')
   inputId <- 'dialogConfirmCondition'
   
   shinyjs::runjs("var audio = document.getElementById('soundSessionDialog');
                  audio.volume = 0.2;
                  audio.play();")
   
   observeEvent(input[[inputId]],{
      
      callback(input[[inputId]])
      
   },once = TRUE,ignoreInit = T)
   
   shinyWidgets::confirmSweetAlert(
      session = session,
      inputId = inputId,
      type = type,
      title = title,
      text = text,
      btn_labels = bt_labels,
      closeOnClickOutside = FALSE,
      showCloseButton = FALSE
   )
   
   shinyjs::runjs("window.scrollTo(0,0);")
   
   return(invisible())
}

# dialogModal <- function(title,size = 'm',...,footer){
#    
#    input  <- get('input')
#    output <- get('output')
# 
#    script <-  htmltools::tags$script(
#       paste0(
#          "
#               setTimeout(function() {
#               
#               var observer = new MutationObserver(function(mutations) {
# 
#               Shiny.setInputValue('refreshModal',new Date());
#               observer.disconnect();
# 
#               });
#               
#               var target = document.querySelector('#shiny-modal');
#               observer.observe(target, { attributes: true});
#                  
#               },1000);"))
#    
#    observeEvent(input$refreshModal,{
#       
#       output[[paste0('conteinerModal')]] <- renderUI({NULL})
#       
#    },ignoreInit = TRUE,once = TRUE)
#    
#    output[[paste0('conteinerModal')]] <- renderUI({tagList(...)})
#    
#    modal <- modalDialog(
#       title = title,
#       uiOutput(paste0('conteinerModal'),style = 'width: 100%; height: 100%;'),
#       script,
#       footer = footer
#    )
#    
#    return(modal)
# }
