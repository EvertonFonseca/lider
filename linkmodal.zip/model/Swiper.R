swiperId       <- NA
swiperPosition <- 1
swiperChildren <- 0
swiperUiList   <- NULL

swiper <- function(id,...,parent.style = '',width = "600px", height = "300px", loop = FALSE,
                   direction = "horizontal",
                   speed = 400, spaceBetween = 100, mousewheel = FALSE,
                   navigation = FALSE, pagination = FALSE) {
  
  
  direction <- match.arg(direction)
  
  # convert loop into something that JS can understand
  loop <- tolower(loop)
  mousewheel <- tolower(mousewheel)
  
  #id
  swiperId  <<- id
  
  # main tag
  swiperTag <- htmltools::tags$div(
    class = "swiper-container",
    style = paste0("width: ", width, "; ", "height: ", height, ";", style = "position: relative;"),
    
    # slide wrapper
    shiny::tags$div(
      class = "swiper-wrapper",
      ...
    ),
    
    # pagination
    if (pagination) htmltools::tags$div(class = "swiper-pagination"),
    
    # buttons
    if (navigation) {
      htmltools::tagList(
        htmltools::tags$div(class = "swiper-button-prev"),
        htmltools::tags$div(class = "swiper-button-next")
      )
    },
    
    # scrollbar
    htmltools::tags$div(class = "swiper-scrollbar")
  )
  
  #children
  swiperChildren <<- length(pryr::dots(...))
  
  # since we use pagination and navigation above for R, we
  # only convert them here for javascript
  navigation <- tolower(navigation)
  pagination <- tolower(pagination)
  
  if (navigation) {
    navigation <- "navigation: {
              nextEl: '.swiper-button-next',
              prevEl: '.swiper-button-prev'
            }"
  } else {
    navigation <- "//"
  }
  
  if (pagination) {
    pagination <- "pagination: {
              el: '.swiper-pagination',
              dynamicBullets: true
            }"
  } else {
    pagination <- "//"
  }
  
  
  # Javascript: init
  script <- 
    htmltools::tags$script(
      paste0(
        "
        $(document).ready(function () {
          //initialize swiper when document ready

         setTimeout(function() {

         var mySwiper = new Swiper ('.swiper-container', {

            // main effect
            effect: 'slide',
            grabCursor: false,
            centeredSlides: false,
            slidesPerView: 'auto',
            // Optional parameters
            allowTouchMove: false,
            direction: '", direction, "',
            loop: ", loop, ",
            speed: ", speed, ",
            spaceBetween: ", spaceBetween, ",
            mousewheel: ", mousewheel ,",

            // navigation options
            ", navigation, ",

            // pagination options
            ", pagination, "

          });

          $('.swiper-scrollbar').hide();
             
        }, 500);
        });
        "
      )
    )
  # load the script and return the tag
  tags <- htmltools::div(
    id = id,
    style = parent.style,
    script,
    swiperTag
  )
  
  # give HTML dependencies
  htmltools::attachDependencies(tags,swiperDep())
  
}


#' @title Create a swiper slide
#'
#' @description A swiper slide
#'
#' @param ... Slide content
#'
#' @export
swiperSlide <- function(...) {
  htmltools::tags$div(class = "swiper-slide", ...)
}

#' @title Create a swiper slide
#'
#' @description A swiper slide
#'
#' @param ... Slide content
#'
#' @export
swiperSlideUi <- function(outputId,...) {
  
  swiperUiList <<- c(swiperUiList,outputId)
  htmltools::tags$div(class = "swiper-slide", ...)
}

swiperSlideNext <- function(id = NA,speed = 1000){

  if(is.na(id))
    id <- swiperId
  
  if(swiperPosition < swiperChildren){
    
      shinyjs::hide(id = swiperUiList[swiperPosition])
    
      swiperPosition <<- swiperPosition + 1
      
      shinyjs::show(id = swiperUiList[swiperPosition])
  }
    
  shinyjs::runjs(paste0("
                  var doc     = document.getElementById('",id,"');
                  var element = null;
                  for (var i = 0; i < doc.childNodes.length; i++) {
                      if (doc.childNodes[i].className == 'swiper-container swiper-container-horizontal') {
                        element = doc.childNodes[i];
                        break;
                      }        
                  }\n
                 element.swiper.slideNext(",speed,");
                 "))

  
}

swiperSlidePrevious <- function(id = NA,speed = 1000){
  
  if(is.na(id))
     id <- swiperId
  
  if(swiperPosition > 1){
    
     shinyjs::hide(id = swiperUiList[swiperPosition])
    
     swiperPosition <<- swiperPosition - 1

     shinyjs::show(id = swiperUiList[swiperPosition])
  }
  
  shinyjs::runjs(paste0("
                  var doc     = document.getElementById('",id,"');
                  var element = null;
                  for (var i = 0; i < doc.childNodes.length; i++) {
                      if (doc.childNodes[i].className == 'swiper-container swiper-container-horizontal') {
                        element = doc.childNodes[i];
                        break;
                      }        
                  }\n
                 element.swiper.slidePrev(",speed,");
                 "))
  
}

swiperSlideTo <- function(id = NA,index,speed = 1000){
  
  if(is.na(id))
     id <- swiperId
  
  shinyjs::hide(id = swiperUiList[swiperPosition])
  
  swiperPosition <<- index + 1
  
  shinyjs::show(id = swiperUiList[swiperPosition])

  shinyjs::runjs(paste0("
                  var doc     = document.getElementById('",id,"');
                  var element = null;
                  for (var i = 0; i < doc.childNodes.length; i++) {
                      if (doc.childNodes[i].className == 'swiper-container swiper-container-horizontal') {
                        element = doc.childNodes[i];
                        break;
                      }        
                  }\n
                  element.swiper.slideTo(",index,",",speed,");
                 "))
  
}

swiperDestroy <- function(id = NA){
  
  if(is.na(id))
    id <- swiperId

  
  if(swiperChildren > 0){
     sapply(1:swiperChildren, function(x) output[[paste0('slider',x)]] <- NULL)
  }
  
  shinyjs::runjs(paste0("
                  var doc     = document.getElementById('",id,"');
                  var element = null;
                  for (var i = 0; i < doc.childNodes.length; i++) {
                      if (doc.childNodes[i].className == 'swiper-container swiper-container-horizontal') {
                        element = doc.childNodes[i];
                        break;
                      }        
                  }\n
                 element.swiper.destroy();
                 "))

}

swiperDep <- function(){
  
  swiper_css <- "css/swiper.min.css"
  swiper_js <- "js/swiper.min.js"
  
  wiper_url <- "https://cdnjs.cloudflare.com/ajax/libs/Swiper/4.4.6/"
  
  htmltools::htmlDependency(
    name = "swiper",
    version = "4.4.6",
    c(href = wiper_url),
    script = swiper_js,
    stylesheet = swiper_css
  )
  
}
