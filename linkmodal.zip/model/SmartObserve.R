
newObserve <- function(){
  
  obj              <- new.env()
  obj$listobserves <- list()
  
  obj$add <- function(o){
    
    obj$listobserves <<- rlist::list.append(obj$listobserves,o)
  }
  
  obj$clear <- function(){
    
    sapply(obj$listobserves, function(x) x$destroy())
    obj$listobserves <<- list()
  }
  
  obj$destroy <- function(){
    
     sapply(obj$listobserves, function(x) x$destroy())
     rm(list = ls(all.names = T,envir = obj),envir = obj)
  }
  return(obj)
}


