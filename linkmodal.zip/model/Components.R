#Cria um dialog dinamico
messageAlerta <- function(input,title = 'Mensagem de Alerta!',message,callback.yes,callback.no) {
  
  insertUI(
    selector = "#root",
    ui = div(
      id    = 'notificationWarning',
      style = "position: fixed; top: 0; left: 0; bottom: 0; right: 0; background-color: rgba(45,55,65,0.6); z-index: 999999; color: black; font-size: 15px;",
      vov::slide_in_right(absolutePanel(
        top = 25,
        right = 25,
        class = 'dialogChip',
        width = 300,
        div(
          style = 'padding: 15px',
          div(
            style = 'padding: 5px; border-style : solid; border-color: gray; border-width: 1px; border-top: none;  border-left: none;  border-right: none;',
            title
          ),
          br(),
          div(message),
          br(),
          div(
            style = 'padding: 5px; border-style : solid; border-color: gray; border-width: 1px; border-bottom: none;  border-left: none;  border-right: none;',
            div(
              style = 'float: right; padding-bottom: 5px;',
              actionButton('btYesnotification','Sim'),
              actionButton('btNonotification','Não')
            )
          )
        )
      ),duration = 'faster')
    )
  )
  
  shinyjs::onclick('btYesnotification',{
    
       shinyjs::runjs("document.getElementById('notificationWarning').remove();")
       callback.yes()

  })
  shinyjs::onclick('btNonotification',{
    
    shinyjs::runjs("document.getElementById('notificationWarning').remove();")
    callback.no()
    
  })
}

tagAppendChildFind <- function(tag,target,child){
  
  tag$children[[target]]$children <- list.append(tag$children[[target]]$children,child)
  tag
}

tagAppendAttributesFind <- function(tag,target,...){
  
  tag$children[[target]]$attribs <- c(tag$children[[target]]$attribs,...)
  tag
}

tagAppendAttributesFindSub <- function(tag,target,...){
  
  if(length(target) == 2)
  {
    tag$children[[target[1]]]$children[[target[2]]]$attribs <- c(tag$children[[target[1]]]$children[[target[2]]]$attribs,...)
    tag
  }
  else if(length(target) == 3)
  {
    tag$children[[target[1]]]$children[[target[2]]]$children[[target[3]]]$attribs <- c(tag$children[[target[1]]]$children[[target[2]]]$children[[target[3]]]$attribs,...)
    tag
  }
}

dialogTitleClose <- function(title,callbackclose){
  
  container <- div(title,absolutePanel(id = 'btCloseModal',right = 15,top = 10,'x',style = 'cursor: pointer; font-weight: bold;'))
  shinyjs::onclick('btCloseModal',{callbackclose()})
  
  return(container)
  
}

MenuItem <- function (id,text, ..., icon = NULL, badgeLabel = NULL, badgeColor = "green", 
          tabName = NULL, href = NULL, newtab = TRUE, selected = NULL, 
          expandedName = as.character(gsub("[[:space:]]", "", text)), 
          startExpanded = FALSE) 
{
  subItems <- list(...)
  #if (!is.null(icon)) 
  #  tagAssert(icon, type = "i")
  if (!is.null(href) + !is.null(tabName) + (length(subItems) > 
                                            0) != 1) {
    stop("Must have either href, tabName, or sub-items (contained in ...).")
  }
  if (!is.null(badgeLabel) && length(subItems) != 0) {
    stop("Can't have both badge and subItems")
  }
  #validateColor(badgeColor)
  isTabItem <- FALSE
  target <- NULL
  if (!is.null(tabName)) {
    #validateTabName(tabName)
    isTabItem <- TRUE
    href <- paste0("#shiny-tab-", tabName)
  }
  else if (is.null(href)) {
    href <- "#"
  }
  else {
    if (newtab) 
      target <- "_blank"
  }
  if (!is.null(badgeLabel)) {
    badgeTag <- tags$small(class = paste0("badge pull-right bg-", 
                                          badgeColor), badgeLabel)
  }
  else {
    badgeTag <- NULL
  }
  if (length(subItems) == 0) {
    return(tags$li(a(href = href, `data-toggle` = if (isTabItem) "tab", 
                     `data-value` = if (!is.null(tabName)) tabName, `data-start-selected` = if (isTRUE(selected)) 1 else NULL, 
                     target = target, icon, span(id = id,text), badgeTag)))
  }
  default <- if (startExpanded) 
    expandedName
  else ""
  dataExpanded <- shiny::restoreInput(id = "sidebarItemExpanded", 
                                      default) %OR% ""
  isExpanded <- nzchar(dataExpanded) && (dataExpanded == expandedName)
  tags$li(class = "treeview", a(href = href, icon, span(text), 
                                shiny::icon("angle-left", class = "pull-right")), do.call(tags$ul, 
                                                                                          c(class = paste0("treeview-menu", if (isExpanded) " menu-open" else ""), 
                                                                                            style = paste0("display: ", if (isExpanded) "block;" else "none;"), 
                                                                                            `data-expanded` = expandedName, subItems)))
}


MenuSubItem  <- function(id = NULL,
                         text,
                         tabName = NULL,
                         href = NULL,
                         newtab = TRUE,
                         icon = shiny::icon("angle-double-right"),
                         selected = NULL) {
  
  component     <- shiny::div(
    id = id,
    style = 'margin-left: 8px; padding: 5px; height: 35px;',
    shiny::splitLayout(
      cellWidths = 'auto',
      shiny::tags$span(icon),
      div(style = 'margin-left: 5px;',
          shinydashboard::menuSubItem(
            text,
            tabName = tabName,
            href = href,
            newtab = newtab,
            icon = NULL,
            selected = selected
          )
      )
    )
  )
  return(component)
}

modelCustumizer <- function(){
  
  id <- 'dialogObj'
  cssStyle <- list()
  cssStyle[[paste0(' #parent',id,' .modal-dialog')]]  <- paste0('height: 80% !important;')
  cssStyle[[paste0(' #parent',id,' .modal-content')]] <- paste0('width: 100% !important; height: 100% !important;')
  cssStyle[[paste0(' #parent',id,' .modal-body')]]    <- paste0('width: 100% !important; height: calc(100% - 57px - 65px) !important; overflow-y: hidden;')
  
  dialog <- shiny::div(
    id = paste0('parent', id),
    style = paste0("height: 90%;"),
    shinyjs::inlineCSS(cssStyle),
    shiny::modalDialog(
      title = dialogTitleClose('Create Grafico',function(){
        
        removeModal()
        callback()
        
      }),
      size = 'l',
      div(style = 'position: relative; height: 100%;',stackPanel$render()),
      br(),
      footer = tagList(
        actionButton('btPreveius','Sair',icon = icon('arrow-left')),
        actionButton('btNext','Avançar',icon = icon('arrow-right')),
      )
      
    )
  )
  
}

removeProgressLoader <- function(timer = 1000,callback = NULL){
  
  if(timer > 0){
    
    shinyjs::delay(timer,{
      
      if(!is.null(callback))
        callback()
      #remove loader
      shinyjs::runjs("try{document.getElementById('progressoLoader').remove();}catch(e){}")
      assign('status.loader',value = FALSE,immediate = T,envir = .GlobalEnv)
    })
    
  }
  else{
    
    if(!is.null(callback))
       callback()
    
    #remove loader
    shinyjs::runjs("try{document.getElementById('progressoLoader').remove();}catch(e){}")
    assign('status.loader',value = FALSE,immediate = T,envir = .GlobalEnv)

  }

}



showProgressBar <- function(){
  
  insertUI(
    selector = '#root',
    ui = absolutePanel(id =  paste0('divprogressBarAsync'),
                       style = 'position: fixed; z-index: 99999999; width: 250px;',
                       class = "shiny-notification",
                       top = 50,
                       right = 25,
                       span( 'x', 
                            style = 'position: absolute; top: -1px; right: 5px; cursor: pointer;',
                            onclick = paste0('Shiny.setInputValue(\"btCloserProgressBar\","",{priority: "event"})'),
                            ),
                       progressBar(
                         id = 'progressBarAsync',
                         title = 'Inicializando ...',
                         value = 2,
                         total = 100,
                         display_pct = T
                       ),
                       shinyjs::inlineCSS(".progress-number{display: none;}")
    ),
    immediate = T
  )
  
}
removeProgressBar <- function(){
  
  shiny::removeUI(selector = paste0('#divprogressBarAsync'))
  
}

newProgressLoader <- function(){
  
  status <- get('status.loader',envir = .GlobalEnv)

  if(!status){
    
    insertUI(
      selector = '#root',
      where = 'afterBegin',
      ui =
        div(id = 'progressoLoader',class = "modalLoader",
            div(
              id = 'loadInit',
              class = "divLoader",
              div(class = "loaderBar")
            )),
      immediate = F
    )
    
    assign('status.loader',value = TRUE,immediate = T,envir = .GlobalEnv)
    
  }
  
}

#Panel com bordo
panelTitle <- function(id = '',
                       display = 'block',
                       title = '',
                       width = 'auto',
                       height = 'auto',
                       id.tooltip = '',
                       title.tooltip = '',
                       title.color   = 'gray',
                       background.color.title = 'white',
                       border.color = 'gray',
                       children) {
  
  if(!stringi::stri_isempty(id.tooltip))
    tooltipComponent <- div(
      id = id.tooltip,
      style = 'float: left; margin-left: 5px',
      icon('info-circle'),
      bsTooltip(
        id.tooltip,
        title.tooltip,
        "right",
        options = list(container = "body")
      )
    )
  else
    tooltipComponent <- NULL
  
  return(
    div(id = id,
        style = paste0('position: relative; ', 'display: ', display, '; height: ',height,'; width: ',width,';','border-color: ',border.color,'; border-style: solid; border-width: 1px;'),
        div(class = 'panelTitle',
            div(tags$span(style = 'float: left;',paste0(" ",title," ")),tooltipComponent,
                style = paste0(' position: absolute; top:-10px; left: 10px; background-color: ',background.color.title,'; color: ',title.color,';')),
            div(style = 'margin-top: 5px;',children))))
}


dialoMessageCondition <- function(title,message,callback.yes,callback.no) {
  
  showModal(modalDialog(
    title = title,
    message,
    easyClose = F,
    footer = tagList(
      actionButton('btDialogSair','Não'),
      actionButton('btDialogOk','Sim')
    )
  ))
  
  shinyjs::onclick('btDialogOk',{
    
    removeModal()
    callback.yes()
  })
  
  shinyjs::onclick('btDialogSair',{
    
    removeModal()
    callback.no()
    
  })
  
}

dialoMessageConditionModal <- function(title,message,callback.yes,callback.no) {
  
  obj     <- list()
  obj$id  <- address(obj)
  
  obj$open <- function(){
    
    toggleModal(getDefaultReactiveDomain(),obj$id, toggle = "open")
  }
  
  obj$close <- function(){
    
    toggleModal(getDefaultReactiveDomain(),obj$id, toggle = "close")
  }
  
  obj$dialog <- dialogDisplay(
    id = obj$id,
    title = title,
    message,
    easyClose = F,
    footer = tagList(
      actionButton(paste0('btSair',obj$id),'Não'),
      actionButton(paste0('btOk',obj$id),'Sim')
    )
  )
  
 delay(0,{
   
   shinyjs::onclick(paste0('btOk',obj$id),{
     
     callback.yes()
     
   })
   shinyjs::onclick(paste0('btSair',obj$id),{
    
     callback.no()
     
   })
   
 })
 
 return(obj)
}

tableComponent <- function(input,output,width = '100%',height = '350px') {
  
  obj      <- list()   
  id       <- address(obj)
  children <- list()
  
  obj$append <- function(row){
    
    cellWidth = (0.12 * (100 / length(row)))
    rows <- list()
    for (i in 1:length(row)) {
      
      rows[[i]] <-  column(width = cellWidth,style='padding:0px;',row[[i]])
    }
    
    children[[length(children) + 1]] <<- fluidRow(rows)
  }
  
  obj$render <- function(){
    
    body <- div(
      id = id, 
      style = paste0('border-style: solid; border-color: white; border-width: 1px; overflow-x: auto; overflow-y: auto; width: ',width,'; height: ',height,';'),
      children
    )
    return(body)
    
  }
  
  return(obj)
}

actionWebUser <- function(callback,auto.remove = FALSE,new.progess = TRUE,delay = 1000){
  
  if(new.progess)
  {
    newProgressLoader()
    
    shinyjs::delay(500,{
      callback()
      if(auto.remove)
        removeProgressLoader(delay)
    })
  }
  else{
    callback()
    if(auto.remove)
      removeProgressLoader(delay)
  }

}

comboEditable <- function(inputid,label,choices,selected = '',height = '28px', width = '100%'){
  
  script <- paste0('<div class="dropdown">
                    <input id  = "',inputid,'" type="text" style = "height: ',height,'; value = "',selected,'" "/>
                    <select id = "combo',inputid,'" onchange="this.previousElementSibling.value=this.value; this.previousElementSibling.focus(); change(this.value);" style = "height: ',height,';">')
  
  sapply(choices, function(item) script <<- paste0(script,paste0("<option>",item,"</option>\n")))
  script <- paste0(script,'</select></div>')
  
  div(
    tags$style(HTML(
      ".dropdown {
       position: relative;
       width: 200px;
   }
   .dropdown select
   {
       width: 100%;
   }
   .dropdown > * {
   
       box-sizing: border-box;
       height: 1.5em;
   }
   .dropdown select {
   
   }
   .dropdown input {
       position: absolute;
       width: calc(100% - 20px);
       
   }"
    )),
    tags$script(HTML(paste0('function change(x) {
   var obj = document.getElementById("',inputid,'");
   obj.value = x;
   Shiny.setInputValue("',inputid,'",x);
   
   var select_box = document.getElementById("combo',inputid,'");
   select_box.selectedIndex = -1;
   
  }'))),
    tags$label(
      label,
      class = 'control-label'),
    HTML(script))
}

updateComboEditable <- function(inputid,choices = ''){
  
  script <- ''
  sapply(choices, function(item) script <<- paste0(script,paste0('var option = document.createElement("option");\n option.text = "',item,'";\n comboBox.add(option);\n')))
  
  runjs(paste0('
  var comboBox = document.getElementById("',inputid,'");\n 
  $("#',inputid,'").empty();\n
 ',script,''))
  
}

bsModaCustumize <- function (id, title, trigger, ..., size = 'large',width = 'auto',height = 'auto',footer = NULL) 
{
  if (!missing(size)) {
    if (size == "large") {
      size = "modal-lg"
    }
    else if (size == "small") {
      size = "modal-sm"
    }
    size <- paste("modal-dialog", size)
  }
  else {
    size <- "modal-dialog"
  }
  bsTag <- shiny::tags$div(class = "modal sbs-modal fade", 
                           id = id, tabindex = "-1", `data-sbs-trigger` = trigger, 
                           `data-keyboard`="false" ,`data-backdrop`="static",
                            shiny::tags$div(class = size,
                                           style = paste0("width: ",width,'; height: ',height,';'),
                                           shiny::tags$div(class = "modal-content",
                                                           style = 'width: 100%; height: 100%',
                                                                         shiny::tags$div(class = "modal-header",shiny::tags$h4(class = "modal-title", title)), 
                                                                         shiny::tags$div(style = 'height: 100%; width: 100%; overflow-y: auto;',class = "modal-body", list(...)), 
                                                                         shiny::tags$div(class = "modal-footer", footer))))
  htmltools::attachDependencies(bsTag,shinyBS:::shinyBSDep)
}

callAttrubuteOfDocument <- function(input,name,attribute,callback){
  
  observeEvent(input$onCalltmp,{
    
    callback(input$onCalltmp)
    
  },once = TRUE)
  
  shinyjs::runjs(paste0("try{Shiny.setInputValue('onCalltmp',document.getElementById('",name,"').",attribute,");}catch(e){}"))
}
