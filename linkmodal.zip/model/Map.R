mapContainer <- function(id){
  
  script <-  htmltools::tags$script(
    paste0(
      "var $content = $('#",id,"');
              var intervalId = setInterval(function(){
                  if(!$content.is(':empty')){
                      //do stuff
                      loadTranslateMap();
                      clearInterval(intervalId);
                  }
              }, 1000);"))
  
  tagList(leaflet::leafletOutput(id),script)

}
