dynamic_require <- function(package){
  
  if(!eval(parse(text=paste("require(",package,")"))))
  {
    install.packages(package,dependencies = TRUE)
    eval(parse(text=paste("require(",package,")")))
  }
}

translateMap <- function(){
  
  shinyjs::runjs('
  
                 var changeTitle = function(classe,title){
                
                  try{
                     let drawPolygno = document.getElementsByClassName(classe);
                     drawPolygno[0].title = title;
                  }catch(e){}
                 
                 }
                
                changeTitle("leaflet-draw-draw-polygon","Desenha um novo polígno");
                changeTitle("leaflet-draw-draw-rectangle","Desenha um novo retangulo");
                changeTitle("leaflet-draw-draw-circlemarker","Desenha um novo circulo"); 
                changeTitle("leaflet-draw-draw-marker","Desenha um nova marca");
                changeTitle("leaflet-draw-edit-edit leaflet-disabled","Sem camadas para editar"); 
                changeTitle("leaflet-draw-edit-remove leaflet-disabled","Sem camadas para remover"); 
                
                try{L.drawLocal.draw.handlers.circle.tooltip.start   = "Clique e arraste para desenhar o círculo.";}catch(e){}
                try{L.drawLocal.draw.handlers.circle.radius          = "Raio";}catch(e){}
                
                try{L.drawLocal.draw.handlers.circlemarker.tooltip.start = "Clique e arraste para desenhar o círculo.";}catch(e){}
                try{L.drawLocal.draw.handlers.rectangle.tooltip.start    = "Clique e arraste para desenhar o retangulo.";}catch(e){}
                try{L.drawLocal.draw.handlers.marker.tooltip.start       = "Clique no mapa para colocar o marcador.";}catch(e){}
                
                try{L.drawLocal.draw.handlers.polygon.tooltip.start  = "Clique para começar a desenhar a forma.";}catch(e){}
                try{L.drawLocal.draw.handlers.polygon.tooltip.cont   = "Clique para continuar desenhando a forma.";}catch(e){}
                try{L.drawLocal.draw.handlers.polygon.tooltip.end    = "Clique no primeiro ponto para fechar esta forma.";}catch(e){}
                
                try{L.drawLocal.edit.handlers.edit.tooltip.text      = "Arraste alças ou marcadores para editar recursos.";}catch(e){}
                try{L.drawLocal.edit.handlers.edit.tooltip.subtext   = "Clique em cancelar para desfazer as alterações.";}catch(e){}
                try{L.drawLocal.edit.handlers.remove.tooltip         = "Clique em um recurso para remover.";}catch(e){}
                
                try{L.drawLocal.edit.toolbar.actions.cancel.title    = "Cancela a edição, descarta todas as alterações";}catch(e){}
                try{L.drawLocal.edit.toolbar.actions.cancel.text     = "Cancelar";}catch(e){}
                try{L.drawLocal.edit.toolbar.actions.clearAll.title  = "Limpar todas as camadas";}catch(e){}
                try{L.drawLocal.edit.toolbar.actions.clearAll.text   = "Limpar tudo";}catch(e){}
                try{L.drawLocal.edit.toolbar.actions.save.title      = "Salvar alterações";}catch(e){}
                try{L.drawLocal.edit.toolbar.actions.save.text       = "Salvar";}catch(e){}
                
                try{L.drawLocal.edit.toolbar.buttons.edit            = "Editar camadas";}catch(e){}
                try{L.drawLocal.edit.toolbar.buttons.editDisabled    = "Sem camadas para editar";}catch(e){}
                try{L.drawLocal.edit.toolbar.buttons.remove          = "Excluir camadas";}catch(e){}
                try{L.drawLocal.edit.toolbar.buttons.removeDisabled  = "Nenhuma camada para excluir";}catch(e){}
                
                try{L.drawLocal.draw.toolbar.finish.title            = "Terminar o desenho";}catch(e){}
                try{L.drawLocal.draw.toolbar.finish.text             = "Terminar";}catch(e){}
                try{L.drawLocal.draw.toolbar.undo.title              = "Excluir o último ponto desenhado ";}catch(e){}
                try{L.drawLocal.draw.toolbar.undo.text               = "Apagar o último ponto ";}catch(e){}
                 
               ')
  
}

dialogModalOutputSession <- function(input,output,title,size = 'm'){

  source('model/Dialog.R',encoding = 'UTF-8',local = TRUE)
  count  <- 11
  
  modal <- dialogModal(title = title,size = size,textOutput('textTimeleft') %>% tagAppendAttributes(style = 'font-size: 18px; font-style: bold;'),footer = NULL)
  
  output$textTimeleft <- renderText({
    
    invalidateLater(1000)
    
    count <<- count - 1
    
    if(count < 0){
      shinyjs::runjs("window.close();")
      getDefaultReactiveDomain()$close()
      return(NULL)
    }
    paste0('Sessão será encerrada em ',count," Segundos")
    
  })
  
  shinyjs::delay(1000,{
    shiny::removeModal()
    shinyWidgets::closeSweetAlert()
    shiny::showModal(modal)
  })
}


collapseInput <- function(inputId, boxId) {
  
  boxclose <- paste0(
    "$('#",boxId,"').closest('.box').on('hidden.bs.collapse', function () {Shiny.onInputChange('",inputId,"',",jsonlite::toJSON(list(box = boxId,status = TRUE),auto_unbox = TRUE),");});")
  
  boxshow <- paste0(
    "$('#",boxId,"').closest('.box').on('shown.bs.collapse', function () {Shiny.onInputChange('",inputId,"',",jsonlite::toJSON(list(box = boxId,status = FALSE),auto_unbox = TRUE),");});")
  
  paste(boxclose,'\n',boxshow)
}


detach_package <- function(pkg, character.only = FALSE)
{
  if(!character.only)
  {
    pkg <- deparse(substitute(pkg))
  }
  search_item <- paste("package", pkg, sep = ":")
  while(search_item %in% search())
  {
    detach(search_item, unload = TRUE, character.only = TRUE)
  }
}

convertWidthColunaToPercetagem <- function(x){
  
  return(x * 50 / 6)
}

checksumXor <- function(protocolo){
  
  hex <- charToRaw(protocolo)
  result <- binaryLogic::as.binary(0x00)
  for (i in seq_along(hex)) {
  
    x <- binaryLogic::as.binary(hex[i])
    result <- (xor(result,x)) & binaryLogic::as.binary(0xFF)
  }
  return(toupper(BMS::bin2hex(result)))
}

removeModalClear <- function(){
  
  removeModal()
  shinyjs::runjs('$(".modal-body").html("");')
}

changeAnotherNameSensorLogica <- function(text,vetor){
  
  text  <- unlist(stringr::str_split(text," "))
  text[sapply(text, function(x) ifelse(varhandle::check.numeric(x),FALSE,!(x %in% vetor)))]

}

transformWords <- function(x){
  
  x <- unlist(stringr::str_split(x," "))
  tokens     <- NULL
  aux.token  <- ''
  flag       <- FALSE
  
  sapply(x, function(token){
    
    if(stringr::str_starts(token,"'") && !stringr::str_ends(token,"'")){
      
      aux.token <<- token
      flag      <<- TRUE
    }
    else if(stringr::str_ends(token,"'") && flag){
      
      tokens    <<- c(tokens,paste(aux.token,token))
      flag      <<- FALSE
      aux.token <<- ''
      
    }
    else{
      tokens    <<- c(tokens,token)
    }
    
  })
  return(tokens)
  
}

replaceLogica <- function(vetorLogica,logicas,nameSensor){
  
  words <- NULL
  sapply(logicas, function(logica){
    
    namesLogica <- names(vetorLogica)
    dados       <- unlist(stringr::str_split(logica," "))
    
    tokens <- lapply(dados, function(token){
      
      is.logica <- FALSE
      for (i in 1:length(namesLogica)) {
        
        x  <- namesLogica[i]
        if(token == x){
           is.logica <- TRUE
           token <- stringr::str_replace(token,x,vetorLogica[which(namesLogica== x)])
        }
      }
      
      if(!is.logica && is.na(as.numeric(token))){
          token <- nameSensor
      }
      token
    })
    word <- do.call("paste",tokens)
    words <<- c(words,word)
    
  })
  
  words
}

isValidEmail <- function(x) {
  grepl("\\<[A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]{2,}\\>", as.character(x), 
        ignore.case=TRUE)
}

builderEmail <- function(sender,recipients,subject,body) {
  
  send.mail(
    from = sender,
    to = recipients,
    subject = subject,
    body = body,
    smtp = list(
      host.name = "smtp.gmail.com",
      port = 465,
      user.name = "salvocalfonseca@gmail.com",
      passwd = "ssbwar86",
      ssl = TRUE
    ),
    authenticate = TRUE,
    send = TRUE
  )
  
}

changetextPlaceHolder <- function(text = "Filtro ..."){
  
  delay(100,{
    shinyjs::runjs(paste0('
                          let lista = document.getElementsByClassName("search-input");\n
                          for(i = 0; i < lista.length; i++){ lista[i].placeholder = "',text,'"; }
                          '))
  })
}

gg_color_hue <- function(n) {
  hues = seq(15, 375, length = n + 1)
  hcl(h = hues, l = 65, c = 100)[1:n]
}

shinySetInputValue <- function(id,value = NULL){

  value <- ifelse(is.null(value),'null',value)
  value <- ifelse(stringi::stri_isempty(value),"''",value)
  
  if(is.vector(id))
  {
   js <- sapply(id, function(x)  paste0("Shiny.setInputValue('",x,"',",value,");"))
   shinyjs::runjs(paste0(js,collapse = '\n '))
    
  }else{
    shinyjs::runjs(paste0("Shiny.setInputValue('",id,"',",value,");"))
  }
}

printf <- function(...) {return(print(paste0(...)))}

graficos <- function(dataset,coluna){
  
  gg <- ggplot(data = dataset,aes(y = .data[[coluna]], x = DT_HR_LOCAL))
  gg <- gg + geom_line(colour = 'white')
  gg <- gg + geom_area(colour = 'white',fill = 'white',alpha = 0.4)
  gg <- gg + geom_point(colour = 'white')
  gg <- gg + scale_x_datetime(date_labels = "%H:%M")
  gg <- gg + ggplot2::labs(x = 'Timer',y = 'Temp')
  gg <- gg + themasPlotyGGplot()
  
  return(renderPlotly({ggplotly(gg) %>% plotly::config(displaylogo = FALSE,displayModeBar = FALSE) %>% layoutPloty()}))
}

configDataframe <- function(input,output,con,look,objs){
  
  dataset <- loadDataFrame(con,look)
  
  if(!is.null(dataset))
    for (i in 1:length(objs)) {
      
      obj <- objs[[i]]
      obj$update(input,output,dataset)
    } 
  
  return(dataset)
}

findObjectGrafico <- function(chip,graficos){
  
  if(length(graficos) > 0){
    
    for (i in 1:length(graficos)) {
      
      if(graficos[[i]]$id == chip)
        return(graficos[[i]])
    }
  }
  
  return(NULL)
}

updateDataframe <- function(input,output,dataset,look,objs){
  
  for (i in 1:length(objs)) {
    
    obj <- objs[[i]]
    obj$update(input,output,dataset)
  } 
  
}

loadMemorys <- function(df) {
  
  channels <- ncol(df) - 5
  #Prefix	Resolution	AmpOp1 (A0)	AmpOp2 (A1)	Voltage1 (A2)	Voltage2 (A3)	Temperature	Humidity	Time (micros)
  colunaNomes <- c('Prefix','Resolution')
  for (i in 1:channels) {
    
    colunaNomes[i+2] <- paste0('Channel_',(i))
  }
  colunaNomes <- c(colunaNomes,'Temperature','Humidity','Time')
  colnames(df) <- colunaNomes
  df <- df %>% filter(grepl('#ABS',Prefix))
  
  return(df)
}

encode <- function(data) {
  
  res   <- ""
  n <- as.integer(stringr::str_length(data) / 2)
  limite <- as.integer(stringr::str_length(data))
  datas <- data
  order <- "%123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"
  base  <- stringr::str_length(order)
  num   <- as.integer(data)
  
  while (num > 0)
  {
    pos  <- as.integer((num %% base)) + 1
    res  <- paste0(stringr::str_sub(order, pos, pos), res)
    num  <- as.integer(num / base)
  }
  
  return(res)
}

indexBox <- function(char) {
  
  order <-  "%123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"
  
  for (i in 1:stringr::str_length(order)) {
    if (char == stringr::str_sub(order, i + 1, i + 1)) {
      return(i)
    }
  }
  return(-1)
}


dencode <- function(data) {
  
  n <- as.integer(stringr::str_length(data) / 2)
  limite <- as.integer(stringr::str_length(data))
  datas  <- data
  order <-  "%123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"
  
  data <- stringr::str_replace_all(data,'0','')
  num   <- data
  base  <- stringr::str_length(order)
  reverse <- stringi::stri_reverse(data)
  sumBy <- as.double(0.0)
  
  for (i in 1:stringr::str_length(data)) {
    p <- `^`(as.double(base), as.double(i - 1))
    char <- indexBox(stringr::str_sub(reverse, i, i))
    sumBy <- as.integer(sumBy + (p * char))
  }
  return(as.character(sumBy))
  
}

matrixToModalEncapsolado <- function(x) {
  
  n <- nrow(x)
  if(n > 0)
   lapply(1:nrow(x), function(i) as.list(x[i,]))
  else
    NULL
}

listaToModalToMatrix <- function(x) {
  
  new   <- NULL
  rows  <- length(x)
  nomes <- NULL
  if (rows > 0)
  {
    for (i in 1:rows) {
      
      data  <- x[[i]]
      nomes <- names(data)
      new   <- rbind(new,matrix(data,nrow = 1))
    }
  }
  colnames(new) <- nomes
  return(data.frame(new,stringsAsFactors = F))
}

listaToModalToDataframe <- function(x) {
  
  new   <- NULL
  rows  <- length(x)
  nomes <- NULL
  if (rows > 0)
  {
    for (i in 1:rows) {
      
      data  <- x[[i]]
      nomes <- names(data)
      new   <- rbind(new,data.frame(data))
    }
  }
  colnames(new) <- nomes
  return(data.frame(new,stringsAsFactors = F))
}

getVetorLogico <- function(){
  
  c(
    '<'  = '<', 
    '>'  = '>' ,
    '<=' = '<=',
    '>=' = '>=',
    '==' = '==',
    '!=' = '!=',
    '&&' = '&&',
    '||' = '||',
    '!'  = '!',
    '('  = '(',
    ')'  = ')',
    '*'  = '*',
    '/'  = '/',
    '+'  = '+',
    '-'  = '-'
  )

}

debugFuture <- function(file = 'debug.txt',append = T,clear = F,data){
  
  if(clear){
    write(file = file,'',append = F)
  }else
  write(file = file,x = data,append = append)
  
}

statementCondiction <- function(atributo,valor){
  
  statement <- paste0(atributo$NAME_ATRIBUTO,' <- ',valor,'\n ')
  condicao  <- atributo$CONDICAO_QUALITATIVA
  n         <- nrow(condicao)
  
  if(n > 0)
  {
    for (i in 1:n) {
      logic     <- condicao[i,]
      st        <- ifelse(i == 1,'if','else if')
      statement <- paste0(statement,st,'(',logic$COMANDO_QUAT,'){ \n "',logic$CLASSE_QUAT,'"\n}')
    }
    
    statement <- paste0(statement,'else{ \n "',NA,'"\n}')
    statement <- stringr::str_replace_all(statement,atributo$NAME_ATRIBUTO,stringr::str_replace_all(atributo$NAME_ATRIBUTO," ","_"))
    
    return(eval(parse(text = statement)))
  }
  else
  {
    return(valor)
  }
}


typeOfData <- function(x) {
  
  if(is.Date(x) || is.POSIXct(x))
    return("Data")
  else if(is.numeric(x))
    return('Numerico')
  else if(is.character(x))
    return('Character')
  else
    return("Desconhecido")
}

removeProcess <- function(processos,setores){
  
  new.process <- list()
  for (i in 1:nrow(setores)) {
    
    setor <- setores[i,]
    p <- rlist::list.filter(processos,id == setor$CD_ID_SETOR)
     
    if(!is_empty(p)){
       new.process <- new.process %>% rlist::list.append(p[[1]])
    }

  }
  
  return(new.process)
}

callFunction <- function(expr, params = NULL) {
  f <- function() NULL
  formals(f) <- structure(replicate(length(params), NULL), names=params)
  body(f, envir=parent.frame()) <- substitute(expr)
  f()
}

debugLocal <- function(expr) {
  
   debug(expr)
   x <- expr()
   undebug(expr)
   return(x)
}

validacaoChipSensores <- function(input,tiposDados,listaTabelasLogicas,countSensores ){
  
  for (i in 1:countSensores) {
    
    #empty
    status <- input[[paste0('checkboxSensorAtivo_',i)]]
    
    if(!status) next
    
    sensor <- toupper(input[[paste0('sensor_',i)]])
    
    if(stringi::stri_isempty(stringr::str_trim(sensor))){
      showNotification("Não foi possivel savar o modelo, ha campos não preenchidos!", type = "warning")
      return(FALSE)
    }
    
    tipo <- tiposDados$CD_ID_DADO[which(sapply(tiposDados$NAME_DADO,function(x) x == input[[paste0('sensortipo_',i)]]) == TRUE)]
    
    #type data qualitative
    if(tipo == 2){
      
      #check se possui sensores qualitatiocs
      sensorQualitativo <- listaTabelasLogicas[[i]]
      sensorQualitativo <- sensorQualitativo() %>% drop_na()
      
      if(nrow(sensorQualitativo) == 0){
        showNotification("Não foi possivel savar o modelo, ha campos qualitativos sem construição de logica!", type = "warning")
        return(FALSE)
      }
      
    }
    
  }
  
  #check if all components are ok
  for (i in 1:countSensores) {
    
    status <- input[[paste0('checkboxSensorAtivo_',i)]]
    if(!status) next
    
    #name equals
    sensor1 <- toupper(stringr::str_trim(input[[paste0('sensor_', i)]]))
    
    for (k in 1:countSensores) {
      if (i == k)
        next
      
      status <- input[[paste0('checkboxSensorAtivo_',k)]]
      if(!status) next
      #name equals
      sensor2 <- toupper( stringr::str_trim(input[[paste0('sensor_', k)]]))
      if (sensor1 == sensor2) {
          showNotification("Não foi possivel savar o modelo, ha campos com nomes duplicados!",type = "warning")
          return(FALSE)
      }
      
    }
    
  }

  return(TRUE)
}

replaceString <- function(text,pattern,replace){
  
   if(length(pattern) != length(replace)) return(text)
  
    for (i in seq_along(pattern)) {
      
         if(any(unlist(stringr::str_split(text,' ')) %in% pattern[i]))
         {
           text <- stringr::str_replace_all(text,pattern[i],replace[i])
         }
    }
  return(text)
}

validacaoChipSensoresUpdate <- function(chip,input,tiposDados,listaTabelasLogicas,sensor){
  
  #empty
  index      <- sensor$POSITION_SENSOR
  sensorName <- toupper(input[[paste0('sensor_',index)]])
  
  if(stringi::stri_isempty(stringr::str_trim(sensorName))){
    showNotification("Não foi possivel savar, ha campos não preenchidos!", type = "warning")
    return(FALSE)
  }
  
  tipo <- tiposDados$CD_ID_DADO[which(sapply(tiposDados$NAME_DADO,function(x) x == input[[paste0('sensortipo_',index)]]) == TRUE)]
  
  #type data qualitative
  if(tipo == 2){
    
    for(i in seq_along(listaTabelasLogicas)){
      
      #check se possui sensores qualitatiocs
      sensorQualitativo <- listaTabelasLogicas[[i]]
      sensorQualitativo <- sensorQualitativo() %>% drop_na()
      
      if(nrow(sensorQualitativo) == 0){
        showNotification("Não foi possivel savar, ha campos qualitativos sem construição de logica!", type = "warning")
        return(FALSE)
      }
      
    }

    
  }
  
  if(any(rlist::list.is(chip$SENSORES,(NAME_SENSOR == sensorName && CD_ID_SENSOR != sensor$CD_ID_SENSOR)))){
     showNotification("Não foi possivel savar, ha campos com nomes duplicados!",type = "warning")
     return(FALSE)
    
  }

  return(TRUE)
}
