connectarDatabase <- function(driver,host,port,dbname, user,pass) {
  
  tryCatch({
    
    con <- NULL
    
    if(driver == 'ORACLE')
    {
      url <- paste0(host,':',port,'/',dbname)
      jdbcDriver = RJDBC::JDBC("oracle.jdbc.OracleDriver", classPath = "lib/driver/ojdbc6.jar")
      
      urlUser <- paste0("jdbc:oracle:thin:@", url)
      
      con <- DBI::dbConnect(jdbcDriver, urlUser, user, pass)
    }
    if(driver == 'FIREBIRD')
    {
      url <- paste0(host,':',port,'/',dbname)
      jdbcDriver = RJDBC::JDBC("org.firebirdsql.jdbc.FBDriver", classPath = "lib/driver/jaybird-4.0.2.java8.jar")
      
      urlUser <- paste0("jdbc:firebirdsql:",url)
      
      con <- DBI::dbConnect(jdbcDriver, urlUser, user, pass)
    }
    else if(driver == 'MYSQL'){
      
      con <-
        DBI::dbConnect(
          RMySQL::MySQL(),
          dbname   = dbname,
          user     =  user,
          password = pass,
          host     = host,
          port     = port
        )
      
    }
    else if(driver == 'MARIADB'){
      
      con <-
        DBI::dbConnect(
          RMariaDB::MariaDB(),
          dbname = dbname,
          username =  user,
          password = pass,
          host = host,
          port = port
        )
      
    }
    else if(driver == 'POSTGRES'){
      
      con <-
        DBI::dbConnect(
          RPostgres::Postgres(),
          dbname   = dbname,
          user     =  user,
          password = pass,
          host     = host,
          port     = port
        )
      
    }
    
    return(con)
    
  }, error = function(e) {
    
    print(e)
    return(NULL)
    
  })
  
}

