
selectAllDrivers <- function(con){
  
  DBI::dbGetQuery(con,'SELECT * FROM DATABASE_DRIVER')
  
}

checkifExistNameDatabase <- function(con,name){
  
  DBI::dbGetQuery(con,'SELECT COUNT(*) AS STATUS FROM DATABASE_STORE WHERE TITLE_DB = ?',params = list(name)) %>% pull() > 0
  
}


checkifExistNameDatabaseUpdate <- function(con,id,name){
  
  DBI::dbGetQuery(con,'SELECT COUNT(*) AS STATUS FROM DATABASE_STORE WHERE TITLE_DB = ? AND CD_ID_DB != ?',params = list(name,id)) %>% pull() > 0
  
}

selectAllServerWithDriver <- function(con){
  
   query <- "SELECT 
             DT.CD_ID_DB,
             DT.TITLE_DB,
             DT.HOST_DB,
             DT.PORT_DB,
             DT.NAME_DB,
             DT.USER_DB,
             DT.PASS_DB,
             DD.NAME_DRIVER
             FROM database_STORE DT 
             INNER JOIN database_driver DD ON DT.CD_ID_DRIVER = DD.CD_ID_DRIVER"
   
   DBI::dbGetQuery(con,query)
}
