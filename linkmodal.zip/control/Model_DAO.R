
checkifExistNameModel <- function(con,name){
  
  DBI::dbGetQuery(con,'SELECT COUNT(*) AS STATUS FROM OBJECT_STRUCT WHERE NAME_STRUCT = ?',params = name) %>% pull() > 0
  
}

checkifExistNameModelEdit <- function(con,id,name){
  
  DBI::dbGetQuery(con,'SELECT COUNT(*) AS STATUS FROM OBJECT_STRUCT WHERE NAME_STRUCT = ? AND CD_ID_STRUCT != ?',params = list(name,id)) %>% pull() > 0
  
}

selectAllEstruturas <- function(con){
  
   DBI::dbGetQuery(con,'SELECT 
                        o.CD_ID_STRUCT,
                        o.NAME_STRUCT,
                        o.ID_ATRIBUTO,
                        o.TIME_ATRIBUTO,
                        o.QUERY_STRUCT,
                        o.TIME_ZONE,
                        db.TITLE_DB,
                        d.NAME_DRIVER
                        FROM object_struct o 
                        INNER JOIN database_store db ON db.CD_ID_DB = o.CD_ID_DB
                        INNER JOIN database_driver d ON d.CD_ID_DRIVER = db.CD_ID_DRIVER')
}

selectAllAtributoOfStructName <- function(con,struct){
  
   atributos <- DBI::dbGetQuery(con,'
                         SELECT 
                         A.CD_ID_ATRIBUTO,
                         A.NAME_ATRIBUTO,
                         A.FG_ATIVO,
                         A.POSITION_ATRIBUTO,
                         TP.NAME_DATA,
                         TP.R_DATA,
                         F.BODY_FUNCTION
                         FROM atributo A
                         INNER JOIN type_datas TP ON TP.CD_ID_DATA = A.CD_ID_DATA
                         LEFT JOIN function_atributo F ON F.CD_ID_ATRIBUTO = A.CD_ID_ATRIBUTO
                         WHERE CD_ID_STRUCT = ? ORDER BY A.POSITION_ATRIBUTO',params = struct$CD_ID_STRUCT)
  
   atributos <-  matrixToModalEncapsolado(atributos)
   
   for (k in seq_along(atributos)) {
     
     atributo  <- atributos[[k]]
     atributos[[k]]$CONDICAO_QUALITATIVA <- selectCondicaoQualitativa(con,atributo)
   }
   
   return(atributos)
  
}

selectCondicaoQualitativa <- function(con,atributo){
  
  DBI::dbGetQuery(con,'SELECT CD_ID_QUAT,COMANDO_QUAT,CLASSE_QUAT FROM atributo_qualitativo WHERE CD_ID_ATRIBUTO = ?',params = atributo$CD_ID_ATRIBUTO)

}

selectAllCondicaoQualitativa <- function(con){
  
  DBI::dbGetQuery(con,'SELECT CD_ID_QUAT,COMANDO_QUAT,CLASSE_QUAT FROM atributo_qualitativo')
  
}

selectAllAtributoOfStruct <- function(con,struct,flag.active = FALSE){
  
  if(!flag.active)
  {
    DBI::dbGetQuery(con,'SELECT 
                         A.CD_ID_ATRIBUTO,
                         A.NAME_ATRIBUTO,
                         A.FG_ATIVO,
                         A.POSITION_ATRIBUTO,
                         AQ.CD_ID_QUAT,
                         AQ.COMANDO_QUAT,
                         AQ.CLASSE_QUAT,
                         TP.NAME_DATA,
                         TP.R_DATA
                         FROM atributo A
                         LEFT JOIN atributo_qualitativo AQ ON AQ.CD_ID_ATRIBUTO = A.CD_ID_ATRIBUTO
                         INNER JOIN type_datas TP ON TP.CD_ID_DATA = A.CD_ID_DATA
                         WHERE CD_ID_STRUCT = ? ORDER BY POSITION_ATRIBUTO',params = struct$CD_ID_STRUCT)
  }else{
    DBI::dbGetQuery(con,'SELECT 
                         A.CD_ID_ATRIBUTO,
                         A.NAME_ATRIBUTO,
                         A.FG_ATIVO,
                         A.POSITION_ATRIBUTO,
                         AQ.CD_ID_QUAT,
                         AQ.COMANDO_QUAT,
                         AQ.CLASSE_QUAT,
                         TP.NAME_DATA,
                         TP.R_DATA
                         FROM atributo A
                         LEFT JOIN atributo_qualitativo AQ ON AQ.CD_ID_ATRIBUTO = A.CD_ID_ATRIBUTO
                         INNER JOIN type_datas TP ON TP.CD_ID_DATA = A.CD_ID_DATA
                         WHERE CD_ID_STRUCT = ? AND FG_ATIVO = 1 ORDER BY POSITION_ATRIBUTO',params = struct$CD_ID_STRUCT)
  }
}

selectAllAtributoOfStructFunction <- function(con,struct){
  
  DBI::dbGetQuery(con,'SELECT 
                         A.CD_ID_ATRIBUTO,
                         A.NAME_ATRIBUTO,
                         A.FG_ATIVO,
                         A.POSITION_ATRIBUTO,
                         A.CD_ID_STRUCT
                         FROM atributo A
                         WHERE CD_ID_STRUCT = ? AND FG_ATIVO = 1 ORDER BY POSITION_ATRIBUTO',params = struct$CD_ID_STRUCT)
}

selectSctructWithServer <- function(con,id.struct){
  
  query <- 'SELECT     
             S.CD_ID_STRUCT,
             S.NAME_STRUCT,
             S.IMAGE_STRUCT,
             S.QUERY_STRUCT,
             S.TIME_ZONE,
             S.ID_ATRIBUTO,
             S.TIME_ATRIBUTO,
             DT.CD_ID_DB,
             DT.TITLE_DB,
             DT.HOST_DB,
             DT.PORT_DB,
             DT.NAME_DB,
             DT.USER_DB,
             DT.PASS_DB,
             DD.NAME_DRIVER
             FROM  object_struct S
				     INNER JOIN database_STORE DT ON DT.CD_ID_DB = S.CD_ID_DB 
             INNER JOIN database_driver DD ON DT.CD_ID_DRIVER = DD.CD_ID_DRIVER
             WHERE S.CD_ID_STRUCT = ?'
  
  DBI::dbGetQuery(con,query,params = id.struct)
}

selectAllTypeDatas <- function(con){
  
  DBI::dbGetQuery(con,'SELECT * FROM type_datas')
}


selectAllTimezones <- function(con){
  
  DBI::dbGetQuery(con,'SELECT * FROM TIMEZONES ORDER BY CD_ID_ZONE')
}