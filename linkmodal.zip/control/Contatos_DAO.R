selectContatosDao <- function(con,user){
  
  contatos <- DBI::dbGetQuery(con,"SELECT 
                         C.CD_ID_CONTATO,
                         C.NAME_CONTATO,
                         E.CD_ID_EMAIL,
                         E.ADDRESS_EMAIL,
                         P.CD_ID_PHONE,
                         P.NUMBER_PHONE
                         FROM contatos_user C 
                         LEFT JOIN emails E ON E.CD_ID_CONTATO = C.CD_ID_CONTATO 
                         LEFT JOIN  phones P ON P.CD_ID_CONTATO = C.CD_ID_CONTATO WHERE CD_ID_USER = ?",params = user$CD_ID_USER)
  
  return(contatos)
}


selectEmails <- function(con,contato){
  
  DBI::dbGetQuery(con,"SELECT * FROM EMAILS WHERE CD_ID_CONTATO = ? ",params = contato$CD_ID_CONTATO)
}

selectPhones <- function(con,contato){
  
  DBI::dbGetQuery(con,"SELECT * FROM PHONES WHERE CD_ID_CONTATO = ? ",params = contato$CD_ID_CONTATO)
}