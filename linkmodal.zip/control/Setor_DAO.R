
selectSetorDao <- function(con,user){
  
  setores    <-
    DBI::dbGetQuery(
      con,
      'SELECT se.*,(SELECT COUNT(*) AS COUNT FROM plot WHERE CD_ID_SETOR = se.CD_ID_SETOR) AS COUNT_PLOT FROM SETOR se WHERE se.CD_ID_USER = ?',
      params = list(user$CD_ID_USER)
    )
  return(setores)
}

#Init para todos Setores
uiTabSetores <- function(input,output,setores){

  source('control/control.R',encoding = "UTF-8",local = T)
  
  if(nrow(setores) == 0) return(NULL)
  
  processos <- lapply(1:nrow(setores), function(i){
    
    setor <- setores[i,]
    appendTab(inputId = 'tabsetSetor',
              select = FALSE,
              tabPanel(
                title =  uiOutput(paste0('titleTabSetor_',setor$CD_ID_SETOR)),
                value  = setor$CD_ID_SETOR,
                div(
                  style = 'padding: 5px; padding-top: 25px;',
                  div(
                    uiOutput(
                      outputId =  paste0('painelNotificacao',setor$CD_ID_SETOR)
                    ),
                    uiOutput(outputId = paste0('painelMonitoramento',setor$CD_ID_SETOR),
                             style = 'border-top-style: solid; border-top-width: 1px; border-top-color: lightgray; padding-top: 10px;',
                             class = 'row'),
                    uiOutput(
                        outputId  = paste0('painelAnalise',setor$CD_ID_SETOR),
                        style = 'border-top-style: solid; border-top-width: 1px; border-top-color: lightgray; padding-top: 10px;',
                        class = 'row')
                  )
                )
              )
    )
    
    processo <- processSetor(input,output,setor)
    processo
  })
  
  return(processos)
  
}

uiTabSetor <- function(input,output,setor){
  
  source('control/control.R',encoding = "UTF-8")
  
  appendTab(inputId = 'tabsetSetor',
            select = FALSE,
            tabPanel(
              title =  uiOutput(paste0('titleTabSetor_',setor$CD_ID_SETOR)),
              value  = setor$CD_ID_SETOR,
              div(
                style = 'padding: 5px; padding-top: 25px;',
                div(
                  uiOutput(
                    outputId =  paste0('painelNotificacao',setor$CD_ID_SETOR)
                  ),
                  uiOutput(outputId = paste0('painelMonitoramento',setor$CD_ID_SETOR),
                           style = 'border-top-style: solid; border-top-width: 1px; border-top-color: lightgray; padding-top: 10px;',
                           class = 'row'),
                  uiOutput(
                    outputId  = paste0('painelAnalise',setor$CD_ID_SETOR),
                    style = 'border-top-style: solid; border-top-width: 1px; border-top-color: lightgray; padding-top: 10px;',
                    class = 'row')
                )
              )
            )
  )
  
  processo <- processSetor(input,output,setor)
  return(processo)
}

selectSetoresOnly <- function(con,user){
  
  
  query <- paste0("SELECT 
                     se.CD_ID_SETOR,
                     se.NAME_SETOR,
                     se.TEMPO_REATIVAR_SETOR,
                     se.TEMPO_REATIVAR_UNIDADE_SETOR,
                     se.TEMPO_PASSADO_SETOR,
                     se.TEMPO_PASSADO_UNIDADE_SETOR,
                     se.CD_ID_USER,
                     (SELECT COUNT(*) FROM plot WHERE CD_ID_SETOR = se.CD_ID_SETOR) AS COUNT_PLOTS
                     FROM 
                     setor se
                     WHERE se.CD_ID_USER = ?")
  
  DBI::dbGetQuery(con,query,params = user$CD_ID_USER)
  
}

selectSetor <- function(con,id){
  
  source('control/Object_DAO.R',local = TRUE)
  
  setor <- NULL
  tryCatch({
    
    query <- paste0("SELECT 
                     se.CD_ID_SETOR,
                     se.NAME_SETOR,
                     se.TEMPO_REATIVAR_SETOR,
                     se.TEMPO_REATIVAR_UNIDADE_SETOR,
                     se.TEMPO_PASSADO_SETOR,
                     se.TEMPO_PASSADO_UNIDADE_SETOR,
                     se.CD_ID_USER,
                     (SELECT COUNT(*) AS COUNT FROM plot WHERE CD_ID_SETOR = se.CD_ID_SETOR) AS COUNT_PLOT
                     FROM 
                     setor se
                     WHERE se.CD_ID_SETOR = ?")
    
    setor        <-  DBI::dbGetQuery(con,query,params = id)
    setor        <-  matrixToModalEncapsolado(setor)
    setor        <-  selectObject(con,user,setor[[1]],flag.online = TRUE)
  })
  
  return(setor)
}

selectSetores <- function(con,user){
  
  source('control/Object_DAO.R',local = TRUE)
  setores <- NULL
  
  tryCatch({
    
    query <- NULL
    
    #acesso apenas para master e administrador
    if(user$CD_ID_TIPO != 3)
    {
      
      query <- paste0("SELECT 
                     se.CD_ID_SETOR,
                     se.NAME_SETOR,
                     se.TEMPO_REATIVAR_SETOR,
                     se.TEMPO_REATIVAR_UNIDADE_SETOR,
                     se.TEMPO_PASSADO_SETOR,
                     se.TEMPO_PASSADO_UNIDADE_SETOR,
                     se.CD_ID_USER,
                     (SELECT COUNT(*) AS COUNT FROM plot WHERE CD_ID_SETOR = se.CD_ID_SETOR) AS COUNT_PLOT
                     FROM 
                     setor se
                     WHERE se.CD_ID_USER = ",user$CD_ID_USER)
      
    }else{  # acesso apenas para analista
      
      query <- paste0("SELECT 
                     se.CD_ID_SETOR,
                     se.NAME_SETOR,
                     se.TEMPO_REATIVAR_SETOR,
                     se.TEMPO_REATIVAR_UNIDADE_SETOR,
                     se.TEMPO_PASSADO_SETOR,
                     se.TEMPO_PASSADO_UNIDADE_SETOR,
                     se.CD_ID_USER,
                     (SELECT COUNT(*) AS COUNT FROM plot WHERE CD_ID_SETOR = se.CD_ID_SETOR) AS COUNT_PLOT
                     FROM 
                     setor se
                     WHERE se.CD_ID_USER = ",user$CD_ID_PARENT)
      
    }
    
    setores <- DBI::dbGetQuery(con,query)
    
    if(!is.na(user$SETORES_ACESSO)){
      setores <- setores %>% filter(CD_ID_SETOR %in% jsonlite::fromJSON(user$SETORES_ACESSO))
    }
    
    setores <- matrixToModalEncapsolado(setores)
    setores <- selectObjects(con,user,setores)
    
  })
  
  return(setores)
}

checkIfexistSetor <- function(con,user,name){
  
  status <- FALSE
  tryCatch({
    
    query  <- paste0("SELECT COUNT(1) AS RESULT FROM SETOR WHERE UPPER(NAME_SETOR) = '",toupper(name),"' AND CD_ID_USER = ",user$CD_ID_USER)
    status <-  DBI::dbGetQuery(con,query)$RESULT == 1
    
  })
  
  return(status)
}

insertNewSetor <- function(con,user,setor){
  
  id <- -1
  tryCatch({
    
    id <- nextSequenciaID(con,'SETOR')
    query <- 'INSERT INTO SETOR (CD_ID_SETOR,NAME_SETOR,CD_ID_USER,TEMPO_REATIVAR_SETOR,TEMPO_REATIVAR_UNIDADE_SETOR,TEMPO_PASSADO_SETOR,TEMPO_PASSADO_UNIDADE_SETOR) VALUES (?,?,?,?,?,?,?)'
    result <-  DBI::dbSendStatement(con,query)
    DBI::dbBind(result, c(
      as.integer(id),
      setor$NAME_SETOR,
      setor$CD_ID_USER,
      setor$TEMPO_REATIVAR_SETOR,
      setor$TEMPO_REATIVAR_UNIDADE_SETOR,
      setor$TEMPO_PASSADO_SETOR,
      setor$TEMPO_PASSADO_UNIDADE_SETOR
    ))
    DBI::dbClearResult(result)
    
  })
  
  return(as.integer(id))
}

updateSetor <- function(con,setor){
  
  tryCatch({
    
    query <- 'UPDATE SETOR SET NAME_SETOR = ?,
                              TEMPO_REATIVAR_SETOR = ?,
                              TEMPO_REATIVAR_UNIDADE_SETOR = ?,
                              TEMPO_PASSADO_SETOR = ?,
                              TEMPO_PASSADO_UNIDADE_SETOR = ? 
                              WHERE CD_ID_SETOR = ?'
    result <-  DBI::dbSendStatement(con,query)
    DBI::dbBind(result, c(
      setor$NAME_SETOR,
      setor$TEMPO_REATIVAR_SETOR,
      setor$TEMPO_REATIVAR_UNIDADE_SETOR,
      setor$TEMPO_PASSADO_SETOR,
      setor$TEMPO_PASSADO_UNIDADE_SETOR,
      setor$CD_ID_SETOR
    ))
    DBI::dbClearResult(result)
    
  })
}