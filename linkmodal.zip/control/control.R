
source('model/Renderplot.R',encoding = "UTF-8",local = TRUE)

processSetor <- function(input,output,setor){
  
  this               <- environment()
  obj                <- list()
  setor              <- setor
  id                 <- paste0('setor', setor$CD_ID_SETOR)
  plotsID            <- NULL
  is.running         <- FALSE
  observeTimer       <- NULL
  obj$id             <- as.character(setor$CD_ID_SETOR)
  obj$name           <- setor$NAME_SETOR
  interroptor        <- NULL
  runnable           <- NULL
  flag.removeLoader  <- TRUE
  listcomponentPlot  <- list()
  updatepositionPlot <- FALSE
  is.init            <- TRUE
  eventStopMonitor   <- reactiveVal(FALSE)
  event.monitor          <- NULL
  event.tableAlarme      <- NULL
  init.tableNotification <- TRUE
  plotsobjects       <- cachem::cache_mem(max_size = Inf,missing = NULL)
  queueProgress      <- NULL
  callback.progress  <- NULL
  obs.call           <- NULL
  callback.progress  <- reactiveVal(0)
  cancel.progress    <- NULL
  
  stopFuture <- function(pid){
    
    if(!is.null(pid))
    { 
      try({
        tools::pskill(pid,signal = tools::SIGTERM)
        tools::pskill(pid,signal = tools::SIGKILL)
      })
    }
  }

  
  obj$plotUpdate <- function(plots){
    
    plots.aux         <- paste0('plot',plots)
    keys              <- plotsobjects$keys()
    listcomponentPlot <<- rlist::list.filter(listcomponentPlot,!(plot %in% plots))
    
    sapply(plots.aux, function(x) {
      
      plotsobjects$get(x)$destroy()
      plotsobjects$remove(x)
    })
    
    output[[paste0('painelAnalise',setor$CD_ID_SETOR)]] <- renderUI({tagList(lapply(listcomponentPlot,function(x) x$component))})
    
  }
  
  obj$updatePlots <- function(plots){
    
    ordem <- lapply(plots$plot, function(p){
      
      x <-  which(sapply(listcomponentPlot, function(x) x$plot == p))
      listcomponentPlot[[x]]$component
      
    })
    
    output[[paste0('painelAnalise',setor$CD_ID_SETOR)]] <- renderUI({tagList(ordem)})
  }
  
  finished <- function(x){ return(x)}
  
  #atualiza o setor
  setorUpdate   <- reactiveVal(setor)
  
  obj$update <- function(newSetor){
    
    setor     <<- newSetor
    obj$name  <<- setor$NAME_SETOR
    
    #remove todos plot cache
    keys <- systemCache$keys()
    keys <- keys[stringr::str_starts(systemCache$keys(),paste0('dataplotcache',setor$CD_ID_SETOR))]
    sapply(keys, function(x) systemCache$remove(x))
    
    setorUpdate(setor)
  }
  
  obj$start <- function(inserir = FALSE,manual = FALSE) {
    
    if (!is.running) {
      
      
      interroptor  <<- ipc::AsyncInterruptor$new()
      
      removeTooltip(getDefaultReactiveDomain(),'btStatusProcesso')
      
      activePlayMonitor <- input$checkBoxActiveRealTimer
      
      queueProgress      <<- shinyQueue()
      #quee
      queueProgress$consumer$start(100) # Execute signals every 100 milliseconds
      
      obs.call           <<- observeEvent(callback.progress(),{
                              
                              obj     <- callback.progress()
                              message <- obj$message
                              value   <- obj$value
                              
                              updateProgressBar(session = getDefaultReactiveDomain(),id = paste0('progressBarAsync'),title = message,value = value)  
                              
                            },ignoreInit = T)


      if(inserir)
      {
        obj$render()
        activePlayMonitor <- TRUE
      }
      else if(manual){
        
        activePlayMonitor <- TRUE
      }
      
      flag.removeLoader <<- TRUE
      
      if(activePlayMonitor){
        
        showProgressBar()
        
        cancel.progress   <<- observeEvent(input$btCloserProgressBar,{

          removeProgressLoader()
          flag.removeLoader <<- FALSE
          removeProgressBar()
          obj$stop()
          
        },ignoreInit = TRUE)
        
 
        shinyjs::runjs("Shiny.setInputValue('statusProcesso',true);")
        
        actionWebUser(function(){
          
          timer      <- as.integer(setor$TEMPO_REATIVAR_SETOR) * 1000
          timer      <- switch (
            toupper(setor$TEMPO_REATIVAR_UNIDADE_SETOR),
            'SEGUNDO' = timer,
            'MINUTO'  = timer  * 60,
            'HORA'    = timer  * 60 * 60
          )
          
          
         event.tableAlarme <<- observeEvent(input$onTableRowAlarme,{
            
           row     <- input$onTableRowAlarme
           alarmes <- systemCache$get(key = paste0('tablealarmedata',setor$CD_ID_SETOR))
           
           if(is.null(alarmes)) return(NULL)
          
           alarme <- alarmes[row$row + 1,]
           print(alarme)
        
            
          },ignoreInit = TRUE,ignoreNULL = TRUE)
          
          event.monitor <<- observeEvent(timeReactive(),{

            readAllAlaremsAnalise(setor,function(x){

              if(!is.null(x))
              {
                alarmes       <- x$alarmes
                notifications <- x$notification

                #rendern notification
                output[[paste0('notificacaoValueBox',setor$CD_ID_SETOR)]]<- renderUI({

                  tags$p(paste0(notifications,' Notificação'),style = 'font-size: 25px; word-break: break-word;')

                })

                #render table
                if(init.tableNotification)
                {
                  output[[paste0('tableMonitorAlarmes',setor$CD_ID_SETOR)]] <- creatTableAnalise(alarmes)

                  if(nrow(alarmes) > 0)
                  {
                    systemCache$set(key = paste0('tablealarmedata',setor$CD_ID_SETOR),value = alarmes)
                    init.tableNotification <<- FALSE
                    
                  }
                }
                else
                {
                  DT::replaceData(DT::dataTableProxy(paste0('tableMonitorAlarmes',setor$CD_ID_SETOR)), data =  alarmes  %>% mutate(PORCENTUAL = paste0(PORCENTUAL,'%')))
                }

                #render frequencia plot
                output[[paste0('freqMonitorAlarmes',setor$CD_ID_SETOR)]] <- plotly::renderPlotly({

                  validate(
                    need(nrow(alarmes) > 0, "Nenhum registro encontrado")
                  )

                  gg <- ggplot2::ggplot(data = alarmes,ggplot2::aes(y = FREQUENCIA,x = ALVO,fill = ALARME))
                  gg <- gg + ggplot2::geom_bar(stat="identity", position = ggplot2::position_dodge())
                  gg <- gg + ggplot2::geom_text(ggplot2::aes(label = FREQUENCIA),position = ggplot2::position_dodge(width = 0.9),size = 3)
                  gg <- gg + themasPlotyGGplot()
                  plotly::ggplotly(gg) %>% plotly::config(displaylogo = FALSE,displayModeBar = F) %>% layoutPloty(legend.text = 'ALARME')
                })

                #render per plot
                output[[paste0('perMonitorAlarmes',setor$CD_ID_SETOR)]]<- plotly::renderPlotly({

                  validate(
                    need(nrow(alarmes) > 0, "Nenhum registro encontrado")
                  )

                  alarmes$COLOR <- gg_color_hue(nrow(alarmes))

                  plotly::plot_ly(
                    data = alarmes,
                    type = 'pie',
                    labels = ~ALARME,
                    values = ~PORCENTUAL,
                    textposition = 'inside',
                    textinfo = 'percent',
                    insidetextfont = list(color = '#333333'),
                    hoverinfo = 'text',
                    text = ~paste(ALVO,' ',PORCENTUAL, '%'),
                    hole = 0,
                    marker = list(colors =  ~COLOR)
                  ) %>% plotly::config(displaylogo = FALSE,displayModeBar = F)  %>% layoutPloty(legend.text = 'ALARME')

                })

              }

            })

            readAllCommunicationObject(setor,function(x){
              
              #rendern notification
              output[[paste0('communicationValueBox',setor$CD_ID_SETOR)]]<- renderUI({

                tags$p(paste0(ifelse(is.null(x$COUNT),0,x$COUNT),' Servidores'),style = 'font-size: 25px; word-break: break-word;')

              })

            })

            return(NULL)

          },ignoreInit = FALSE)

          timer <<- reactiveTimer(as.integer(timer))
          buildProcessofSetor()
          is.running <<- TRUE
          
          eventStopMonitor(FALSE) 
          
        },auto.remove = FALSE,new.progess = !inserir)
        
      }
      else{
        eventStopMonitor(TRUE)  
      }  
      
    }
    
  }
  
  timeout <- function(){
    
    if(is.running)
    { 
      observeTimer <<- observeEvent(timer(),{
        
        
        if(is.running)
        {
          buildProcessofSetor()
          
        }
        return(NULL)
        
      },once = T,ignoreInit = T)
    }
    
  }
  
  buildProcessofSetor <- function(){

    future.callr::callr({

      source('control/Database.R',local   = TRUE)
      source('control/Setor_DAO.R',local  = TRUE)
      source('control/Plot_DAO.R',local   = TRUE)
      source('control/Driver_DAO.R',local = TRUE)
      source('control/Model_DAO.R',local  = TRUE)
      source('global.R',local = TRUE)

      con   <- newConnection()
      data  <- NULL
 
      tryCatch({

        if(!is.null(con)){
          
          setor     <- selectSetor(con,setor$CD_ID_SETOR)
          struturas <- unique(unlist(rlist::list.select(setor$OBJETOS,CD_ID_STRUCT)))
          
          if(flag.removeLoader)
           queueProgress$producer$fireAssignReactive("callback.progress",list(value = as.integer((2 / 10) * 100),message = 'Conectando com o(s) servidore(s)'))
                        #future.apply::future_
          dataframes <- lapply(struturas,function(id.struct){
           
            message <- NA
            #start connection
            #con  <- newConnection()
            
           # if(is.null(con)) return(NULL)
            if(!DBI::dbIsValid(con)) return(NULL)
            
            strutura       <- selectSctructWithServer(con,id.struct)
            objetos        <- rlist::list.filter(setor$OBJETOS,CD_ID_STRUCT == id.struct)
            objetos.filter <- lapply(objetos, function(x) list(id = x$ID_OBJECT))
            
            #connect with server
            con.server <- connectarDatabase(
              driver = strutura$NAME_DRIVER,
              host   = strutura$HOST_DB,
              port   = strutura$PORT_DB,
              dbname = strutura$NAME_DB,
              user   = strutura$USER_DB,
              pass   = strutura$PASS_DB
            )
            
            if(is.null(con.server)){
              
               insertTable(con,'CONNECTION_MONITOR',list(
                 FG_PROCESSED = 0,
                 CD_ID_SETOR  = setor$CD_ID_SETOR,
                 CD_ID_DB     = strutura$CD_ID_DB
               ))
               DBI::dbDisconnect(con)
               return(NULL)
            }
            else{
              
              insertTable(con,'CONNECTION_MONITOR',list(
                FG_PROCESSED = 1,
                CD_ID_SETOR  = setor$CD_ID_SETOR,
                CD_ID_DB     = strutura$CD_ID_DB
              ))
            }
            
            #search dataframe
            df.tmp   <- NULL
            timeline <- strutura$TIME_ATRIBUTO
            # Fetch
            rs  <- DBI::dbSendQuery(con.server,strutura$QUERY_STRUCT)
            
            tryCatch({

              time     <- (as.POSIXlt(Sys.time(),tz = strutura$TIME_ZONE) - timerCached(setor))
              size     <- length(objetos.filter)
              
              while (!DBI::dbHasCompleted(rs) && !all(is.na(objetos.filter))){
               
                interroptor$execInterrupts()
                
                df   <- DBI::dbFetch(rs,n = 1000) %>% mutate(!!timeline := as.POSIXct(as.POSIXlt(.data[[timeline]],tz = strutura$TIME_ZONE)))
                 
                if(size > 0 && nrow(df) > 0)
                {
                  for (i in 1:size) {
                    
                    object <- objetos.filter[[i]]
                    
                    if(is.na(object)) next
                    
                    df.aux <- df %>% filter(.data[[strutura$ID_ATRIBUTO]] ==  object$id)
                    
                    if(nrow(df.aux) == 0) next
                    
                    if(max(df.aux[[timeline]]) >= time)
                    { 
                      df.tmp <- rbind(df.tmp,df.aux)
                    }
                    else
                    {
                      objetos.filter[i] <- NA
                    }
                  }
                }
                else{
                  break
                }
                
              }
              
              #order by date
              if(!is.null(df.tmp)){
                  df.tmp <- df.tmp %>% filter(.data[[timeline]] >= time) %>% arrange(.data[[timeline]])
               }
              
            },error = function(e){
            
              message  <- e
              
            },finally = {
              
              #disconnect
              DBI::dbClearResult(rs)
              DBI::dbDisconnect(con.server)
              #DBI::dbDisconnect(con)
              
            })

            return(list(CD_ID_STRUCT = id.struct,dataframe = df.tmp,message = message,timeline = timeline,atributo = strutura$ID_ATRIBUTO))
          })

          plots     <- NULL
          dataplots <- NULL
     
          if(length(dataframes) > 0){
            
            interroptor$execInterrupts()
            
            if(flag.removeLoader)
             queueProgress$producer$fireAssignReactive("callback.progress",list(value = as.integer((5 / 10) * 100),message = 'Buscando o(s) grafico(s)'))
            
            plots <- readAllPlotsOfSetor(con,setor)
            
            if(length(plots) == 0) return(NULL) 
            
            if(flag.removeLoader)
             queueProgress$producer$fireAssignReactive("callback.progress",list(value = as.integer((8 / 10) * 100),message = 'Construindo o(s) dado(s)'))
            
            dataplots  <- lapply(seq_along(plots),function(i){

              interroptor$execInterrupts()

              plot           <- plots[[i]]
              dataplot       <- plot$dataplots
              dataframes.tmp <- dataframes
              data.cache     <- systemCache$get(paste0('dataplotcache',setor$CD_ID_SETOR,plot$CD_ID_PLOT))
              status.cache   <- !is.null(data.cache)
              if(status.cache){

                dataframes.tmp  <- lapply(dataframes.tmp,
                                   function(x){
                                        if(!is.null(x$dataframe)){
                                           x$dataframe <- x$dataframe %>% filter(.data[[x$timeline]] > max(data.cache$TIME))

                                           if(nrow(x$dataframe) == 0){
                                             x$dataframe <- NULL
                                           }
                                        }
                                      return(x)
                                    })
              }

              dataset <- foreach(
                index    = 1:nrow(dataplot),
                .combine = rbind,
                .inorder = FALSE
              ) %do%{

                interroptor$execInterrupts()

                data <- dataplot[index,]
                Y       <- NA
                X       <- NA
                LEGEND  <- NA
                MESSAGE <- NA
                TIME    <- NA
                #statementCondiction
                tryCatch({

                  if(is.na(data$CD_ID_OBJECT_Y)){

                    object.x   <- (setor$OBJETOS %>% rlist::list.filter(CD_ID_OBJECT == data$CD_ID_OBJECT_X))
                    
                    if(purrr::is_empty(object.x)) return(NULL)
                      
                    object.x   <- object.x[[1]]
                    atributo.x <- (object.x$ATRIBUTOS %>% rlist::list.filter(CD_ID_ATRIBUTO == data$CD_ID_ATRIBUTO_X))[[1]]

                    x.value    <- rlist::list.filter(dataframes.tmp,CD_ID_STRUCT == object.x$CD_ID_STRUCT)[[1]]

                    if(!is.null(x.value$dataframe)){

                       #filter only object
                       x.value$dataframe <- x.value$dataframe %>% filter(.data[[x.value$atributo]] == object.x$ID_OBJECT)
                       
                       if(!is.na(atributo.x$BODY_FUNCTION)){
                         #apply function
                         x.value$dataframe[[atributo.x$NAME_ATRIBUTO]] <-
                                                callFunctionAtributo(dataframe = x.value$dataframe[[atributo.x$NAME_ATRIBUTO]],
                                                variavel  = tolower(atributo.x$NAME_ATRIBUTO),
                                                body      = atributo.x$BODY_FUNCTION
                                                )
                       }
                       
                       X <- formatDataType(x.value$dataframe[[atributo.x$NAME_ATRIBUTO]],atributo.x$NAME_DATA)
                     
                      if(nrow(atributo.x$CONDICAO_QUALITATIVA) > 0 && plot$TIPO_X_DATA == 'text'){
                        X <- sapply(X, function(x) statementCondiction(atributo = atributo.x,valor = x))
                      }

                      TIME   <- x.value$dataframe[[x.value$timeline]]
                      LEGEND <- object.x$NAME_OBJECT
                    }

                  }else{

                    object.y   <- (setor$OBJETOS %>% rlist::list.filter(CD_ID_OBJECT == data$CD_ID_OBJECT_Y))
                    object.x   <- (setor$OBJETOS %>% rlist::list.filter(CD_ID_OBJECT == data$CD_ID_OBJECT_X))
                    
                    if(purrr::is_empty(object.y) || purrr::is_empty(object.x)) return(NULL)
                    
                    object.y   <- object.y[[1]]
                    object.x   <- object.x[[1]]
                    
                    atributo.y <- (object.y$ATRIBUTOS %>% rlist::list.filter(CD_ID_ATRIBUTO == data$CD_ID_ATRIBUTO_Y))[[1]]
                    atributo.x <- (object.x$ATRIBUTOS %>% rlist::list.filter(CD_ID_ATRIBUTO == data$CD_ID_ATRIBUTO_X))[[1]]

                    y.value <- rlist::list.filter(dataframes.tmp,CD_ID_STRUCT == object.y$CD_ID_STRUCT)[[1]]
                    x.value <- rlist::list.filter(dataframes.tmp,CD_ID_STRUCT == object.x$CD_ID_STRUCT)[[1]]

                    if(!is.null(y.value$dataframe) && !is.null(x.value$dataframe)){

                      #filter only object
                      y.value$dataframe <- y.value$dataframe %>% filter(.data[[y.value$atributo]] == object.y$ID_OBJECT)
                      x.value$dataframe <- x.value$dataframe %>% filter(.data[[x.value$atributo]] == object.x$ID_OBJECT)
                      
                      if(!is.na(atributo.y$BODY_FUNCTION)){
                        #apply function
                        y.value$dataframe[[atributo.y$NAME_ATRIBUTO]] <-
                          callFunctionAtributo(dataframe = y.value$dataframe[[atributo.y$NAME_ATRIBUTO]],
                                               variavel  = tolower(atributo.y$NAME_ATRIBUTO),
                                               body      = atributo.y$BODY_FUNCTION
                          )
                      }
                      
                      if(!is.na(atributo.x$BODY_FUNCTION)){
                        #apply function
                        x.value$dataframe[[atributo.x$NAME_ATRIBUTO]] <-
                          callFunctionAtributo(dataframe = x.value$dataframe[[atributo.x$NAME_ATRIBUTO]],
                                               variavel  = tolower(atributo.x$NAME_ATRIBUTO),
                                               body      = atributo.x$BODY_FUNCTION
                          )
                      }
                      
                      Y <- formatDataType(y.value$dataframe[[atributo.y$NAME_ATRIBUTO]],atributo.y$NAME_DATA)
                      X <- formatDataType(x.value$dataframe[[atributo.x$NAME_ATRIBUTO]],atributo.x$NAME_DATA)

                      #statemente logic Y
                      if(nrow(atributo.y$CONDICAO_QUALITATIVA) > 0 && plot$TIPO_Y_DATA == 'text'){
                       Y <- sapply(Y, function(y) statementCondiction(atributo = atributo.y,valor = y))
                      }
                      #statemente logic X
                      if(nrow(atributo.x$CONDICAO_QUALITATIVA) > 0 && plot$TIPO_X_DATA == 'text'){
                       X <- sapply(X, function(x) statementCondiction(atributo = atributo.x,valor = x))
                      }

                       if(object.y$NAME_OBJECT == object.x$NAME_OBJECT)
                          LEGEND  <- paste0(object.y$NAME_OBJECT)
                       else
                          LEGEND  <- paste0(object.y$NAME_OBJECT,' - ',object.x$NAME_OBJECT)


                       if(length(y.value$dataframe[[y.value$timeline]]) > length(x.value$dataframe[[x.value$timeline]]))
                           TIME    <- y.value$dataframe[[y.value$timeline]]
                       else
                           TIME    <- x.value$dataframe[[x.value$timeline]]
                    }

                  }

                },error = function(e){
                  MESSAGE <- e
                })

                #data.frame(Y = setNames(Y,NULL),X = setNames(X,NULL),LEGEND = LEGEND,MESSAGE = MESSAGE,TIME = TIME)
                cbind(
                  gdata::cbindX(data.frame(Y = setNames(Y, NULL)), X = data.frame(X = setNames(X, NULL))),
                  data.frame(LEGEND = LEGEND, MESSAGE = MESSAGE,TIME = TIME)
                )
              } # end foreach

              status.df <- all(is.na(dataset))
              
              if(status.cache){
                
                if(!status.df)
                  dataset <- rbind(data.cache,dataset)
                else
                  dataset <- data.cache
              }

              if(!status.df)
                systemCache$set(paste0('dataplotcache',setor$CD_ID_SETOR,plot$CD_ID_PLOT),dataset)

              return(buildDataframeToPlot(plot,dataset))
            })
            
            data <- list(setor = setor,plots = plots,dataplots = dataplots)
            
            #salva os dados como backup
            systemCache$set('backupdataplots',data)

          }
        }
        if(flag.removeLoader)
          queueProgress$producer$fireAssignReactive("callback.progress",list(value = 95,message = 'Construindo o(s) grafico(s)'))

        return(data)
      },
      error = function(e){
        print(e)
        NULL
      },finally = {

        if(!is.null(con))
          DBI::dbDisconnect(con)

      })
      
    })%...>%(onFutureData)
    
  }
  
  onFutureData <- function(data){
 
    if(!is.running) return()

    if(!is.null(data)){

      #atualiza os dados do setor
      setor <<- data$setor

      #remove todos os plots que estao desativados ou deletados
      sapply(plotsobjects$keys(), function(id) {
        
        if (!rlist::list.any(data$plots, paste0("plot", CD_ID_PLOT) == id)) {
          removeUI(selector = paste0('#child-', id), immediate = T)
          #remove key
          plotsobjects$get(id)$destroy()
          plotsobjects$remove(id)
          listcomponentPlot <<- rlist::list.filter(listcomponentPlot,paste0("plot",plot) != id)
        }
        
      })
     
      if(length(data$plots) > 0){
        
        sapply(seq_along(data$plots),function(index){
       
          plot       <- data$plots[[index]]
          dataplot   <- data$dataplots[[index]]
          child      <- paste0('plot', plot$CD_ID_PLOT)
          plotobject <- plotsobjects$get(key = child)
   
          if(all(is.na(dataplot))) return(invisible(NULL))
          
          # #check se o plot nao foi renderizado
          if(is.null(plotobject)){
            
            #id    = paste0('child-',setor$CD_ID_SETOR),
            plotobject    <- newObjectPlot(input,output,child,plot)
            componentPlot <- insertNewPlotComponent(plot,plotobject$plotOutput())
            listcomponentPlot[[length(listcomponentPlot) + 1]] <<- list(plot = plot$CD_ID_PLOT,component = componentPlot)
            
            if(is.init)
            {
              insertUI(
                selector = paste0('#painelAnalise',setor$CD_ID_SETOR),
                ui = componentPlot
              )# end insert
              
            }else{
              
              index.next <- index - 1
              
              if(index.next > 0){
                
                nextplot  <- data$plots[[index.next]]
                
                insertUI(
                  selector =  paste0('#child-plot', nextplot$CD_ID_PLOT),
                  where = 'afterEnd',
                  ui = componentPlot
                )# end insert
                
              }else{
                
                insertUI(
                  selector = paste0('#painelAnalise',setor$CD_ID_SETOR),
                  where    = 'afterBegin',
                  ui       = componentPlot
                )# end insert
                
              }
              
            }
            
            # #events listeners buttons
            shinyjs::onclick(paste0('btEraser', plot$CD_ID_PLOT),{

              plotobject <- plotsobjects$get(child)
              data       <- systemCache$get('backupdataplots')

              plotobject$plotRender({

                status <- isolate({eventStopMonitor()})

                if(!status)
                {
                  plotobject$plot(setor,data$plots[[index]],data$dataplots[[index]])
                }
                else{

                  plotobject$plot(setor,data$plots[[index]],data$dataplots[[index]],TRUE)
                }

              })

            })

            shinyjs::onclick(paste0('bteye', plot$CD_ID_PLOT),{

              obj$stop()

              actionWebUser(function(){

                #show dialog
                uiShowPlot(
                  input = input,
                  output = output,
                  setor  = setor,
                  index  = index,
                  plot   =  plot,
                  callback = function() {
                    obj$start()
                  }
                )

              },auto.remove = T)

            })

            plotobject$actionListener(observeEvent(eventStopMonitor(),{

              shinyjs::delay(500,{

                status     <- eventStopMonitor()

                if(!status)
                {
                  #esconde bt clear
                  shinyjs::hide(paste0('btEraser', plot$CD_ID_PLOT))
                  shinyjs::hide(paste0('btgears', plot$CD_ID_PLOT))
                }
                else{
                  #mostra bt clear
                  shinyjs::show(paste0('btEraser', plot$CD_ID_PLOT))
                  shinyjs::show(paste0('btgears', plot$CD_ID_PLOT))

                }
              })

            }))
            
            plotobject$plotRender({
              
              plotobject$plot(setor,plot,dataplot)
              
            })
            
            tryCatch({
              plotsobjects$set(key = child,value = plotobject)
            },error = function(e){})
            
          }# end if
          else{
            
            #update datas
            plotobject$plotRender({
              
              plotobject$plot(setor,plot,dataplot,proxy = TRUE)
              
            },proxy = TRUE)
            
          }
          
        })
        
        if(is.init){
          is.init <<- FALSE
        }
        
      }else{
        
        # showNotification("Aviso nenhum dado foi enctrado!", type = "warning")
      }
      
      if(flag.removeLoader)
        queueProgress$producer$fireAssignReactive("callback.progress",list(value = 100,message = 'Finalizando processos'))
      
    }
    else{
      # showNotification("Aviso a conexão com banco de dados foi perdida!", type = "warning")
    }
    
    
    if(flag.removeLoader)
    {
      removeProgressLoader(2000)
      flag.removeLoader <<- FALSE
      removeProgressBar()
      queueProgress$consumer$stop()
      queueProgress$destroy()
    }
    
    # Reset timer
    timeout()
    #force gc
    gc(verbose = F)
    
  }
  
  obj$destroy <- function(default = FALSE){
    
    obj$remove()
    obj$stop(remover = TRUE)
    
    if(default)
    {
      #destroy this object
      rm(list = ls(all.names = T,envir = this),envir = this)
    }
  }
  
  obj$stop <- function(force = FALSE,remover = FALSE,manual = FALSE) {
    
    if (is.running)
    {
      removeTooltip(getDefaultReactiveDomain(),'btStatusProcesso')
      shinyjs::runjs("Shiny.setInputValue('statusProcesso',false);")
      #stop
      is.running <<- FALSE
      runnable   <<- NULL
      
      interroptor$interrupt("Stop process!")
      interroptor$destroy()
      obs.call$destroy()          
      cancel.progress$destroy()
      queueProgress$consumer$stop()
      queueProgress$destroy()
      
      #destroy event monitor
      if(!is.null(event.monitor))
      {
        event.monitor$destroy()
        event.monitor <<- NULL
      }
      
      if(!is.null(event.tableAlarme)){
        event.tableAlarme$destroy()
        event.tableAlarme <<- NULL
      }
      
      if(manual){
        eventStopMonitor(TRUE)  
      }
      
      if(!is.null(observeTimer)){
        observeTimer$destroy()
        observeTimer <<- NULL
      }
      
      if(remover)
      {
        obj$remove()
        listcomponentPlot <<- list()
        sapply(plotsobjects$keys(),function(x) plotsobjects$get(x)$destroy())
        plotsobjects$reset()
        gc()
        
      }
    }
    
  }
  
  obj$render <- function(){
    
    is.init  <<- TRUE
    
    output[[paste0('painelNotificacao',setor$CD_ID_SETOR)]]    <- renderUI({
      
      setor <-  setorUpdate()
      
      fluidRow(
        column(3,
               shinydashboard::valueBox(
                 width = '100%',
                 value = span(paste0(
                   setor$TEMPO_REATIVAR_SETOR,
                   ' ',
                   setor$TEMPO_REATIVAR_UNIDADE_SETOR,'(s)'
                 ),style = 'font-size: 25px;'),
                 subtitle = 'Real Time',
                 icon = icon('clock'),
                 color = "light-blue"
               )  %>% tagAppendAttributesFind(target = 1,style = 'min-height: 102px')
        ),
        column(3,
               shinydashboard::valueBox(
                 width = '100%',
                 value = span(paste0(
                   setor$TEMPO_PASSADO_SETOR,
                   ' ',
                   setor$TEMPO_PASSADO_UNIDADE_SETOR,'(s)'
                 ),style = 'font-size: 25px;'),
                 subtitle = 'Olhar para atrás',
                 icon = icon('eye'),
                 color = "orange"
               )  %>% tagAppendAttributesFind(target = 1,style = 'min-height: 102px')
        ),
        column(3,
               shinydashboard::valueBox(
                 width = '100%',
                 value = uiOutput(paste0('notificacaoValueBox',setor$CD_ID_SETOR)),
                 subtitle = paste0(
                   'Nos ultimos ',setor$TEMPO_PASSADO_SETOR,
                   ' ',
                   setor$TEMPO_PASSADO_UNIDADE_SETOR,'(s)'
                 ),
                 icon = icon('bell'),
                 color = "red"
               ) %>% tagAppendAttributesFind(target = 1,style = 'min-height: 102px')
        ),
        column(3,
               shinydashboard::valueBox(
                 width = '100%',
                 value = uiOutput(paste0('communicationValueBox',setor$CD_ID_SETOR)),
                 subtitle = paste0(
                   'Falha de conexão nos ultimos ',setor$TEMPO_PASSADO_SETOR,
                   ' ',
                   setor$TEMPO_PASSADO_UNIDADE_SETOR,'(s)'
                 ),
                 icon = icon('satellite-dish'),
                 color = "yellow"
               ) %>% tagAppendAttributesFind(target = 1,style = 'min-height: 102px')
        )
      )
    })
    
    output[[paste0('painelMonitoramento',setor$CD_ID_SETOR)]]  <- renderUI({
      
      box(
        solidHeader = T,
        collapsible = T,
        width = 12,
        title = 'Ocorrência de alarmes nas ultimas 24 horas',
        tabsetPanel(
          tabPanel(
            'Tabela de Analise',
            DT::dataTableOutput(paste0("tableMonitorAlarmes",setor$CD_ID_SETOR),height = '450px')
          ),
          tabPanel('Graficos de Analise',
                   fluidRow(
                     column(
                       width = 6,
                       plotly::plotlyOutput(paste0("freqMonitorAlarmes",setor$CD_ID_SETOR),height = '450px')
                     ),
                     column(
                       width = 6,
                       plotly::plotlyOutput(paste0("perMonitorAlarmes",setor$CD_ID_SETOR),height = '450px')
                     )
                   )
          )
        )
      )
      
    })  
    
  }
  
  obj$remove <- function(){
    
    listcomponentPlot <<- list()
    output[[paste0('painelAnalise',setor$CD_ID_SETOR)]] <- NULL
    
  }
  
  output[[paste0('titleTabSetor_',setor$CD_ID_SETOR)]] <- renderText({
    
    setor <-  setorUpdate()
    setor$NAME_SETOR
  })
  
  return(obj)
}


readAllCommunicationObject <- function(setor,callback){
  
  future.callr::callr({
    
    source('control/Database.R',local = T)
    
    con <- newConnection()
    
    if(!DBI::dbIsValid(con)) return(NULL)

    sql <- "SELECT 
             *
             FROM connection_monitor 
             WHERE DT_HR_LOCAL >= (CURRENT_TIMESTAMP() - INTERVAL 24 HOUR) AND CD_ID_SETOR = ? AND FG_PROCESSED = 0"
  
     comunicacao <- DBI::dbGetQuery(con,sql,params = setor$CD_ID_SETOR) %>% 
                    mutate(DT_HR_LOCAL = as.POSIXct(as.POSIXlt(DT_HR_LOCAL,tz = Sys.timezone())))
    
     if(nrow(comunicacao) > 0)
       comunicacao <- comunicacao %>% group_by(CD_ID_DB) %>% summarise(COUNT = n(),.groups = 'drop')
    
     #disconect
     DBI::dbDisconnect(con)
     
     comunicacao
     
  })%...>%(callback)
}

readAllAlaremsAnalise <- function(setor,callback){
  
  future.callr::callr({
    
    source('control/Database.R',local = T)
    
    obj <- NULL
    con <- newConnection()
    
    if(!DBI::dbIsValid(con)) return(NULL)
    
    sql <- "SELECT *
          FROM alarme_online a
          INNER JOIN alarme al ON al.CD_ID_ALARME = a.CD_ID_ALARME
          INNER JOIN object ch ON ch.CD_ID_OBJECT = al.CD_ID_OBJECT
          WHERE CD_ID_SETOR = ?
          AND DT_HR_LOCAL_BEGIN  >= CURRENT_TIMESTAMP() - INTERVAL 24 HOUR"
    
    alarmes <- DBI::dbGetQuery(con,sql,params = setor$CD_ID_SETOR) %>% 
               mutate(DT_HR_LOCAL_BEGIN  = as.POSIXct(as.POSIXlt(DT_HR_LOCAL_BEGIN,tz = Sys.timezone())),
                      DT_HR_LOCAL_END  = as.POSIXct(as.POSIXlt(DT_HR_LOCAL_END,tz = Sys.timezone()))
                      )
    
    if(nrow(alarmes) > 0){
      
      quantidadeNotificao <- nrow(alarmes %>%
                                    group_by(.data$CD_ID_ALARME,.data$DT_HR_LOCAL_BEGIN) %>%
                                    filter(DT_HR_LOCAL_BEGIN >= (Sys.time() - timerCached(setor))))
      
      
      old.alarme <- systemCache$get(paste0('alarm',setor$CD_ID_SETOR))
      
      alarmes <- alarmes %>%
        mutate(ALARME = NAME_ALARME,ALVO = NAME_OBJECT) %>%
        group_by(.data$CD_ID_ALARME,.data$ALARME,.data$ALVO) %>%
        summarise(FREQUENCIA = n(),
                  'DATA INICIO'    = format(last(DT_HR_LOCAL_BEGIN),'%d/%m/%Y %H:%M:%S'),
                  'DATA TERMINO'    = ifelse(is.na(last(DT_HR_LOCAL_END)),'...',format(last(DT_HR_LOCAL_END),'%d/%m/%Y %H:%M:%S')),
                  'DURAÇÃO'   = ifelse(is.na(last(DT_HR_LOCAL_END)),'...',paste0(round(as.numeric(last(DT_HR_LOCAL_END) - last(DT_HR_LOCAL_BEGIN),unit = 'mins'),digits = 2),' minutos')),
                  STATUS            = last(FG_ONLINE),
                  .groups = 'drop'
        ) %>% 
        mutate(
          PORCENTUAL = round((FREQUENCIA / sum(FREQUENCIA)), 2) * 100,
          RANK  = rank(-FREQUENCIA),
          NIVEL = sapply(STATUS, function(x){
            as.character(span(icon('grip-lines'),style = paste0('font-size: 25px;')))
          }),
          STATUS  = sapply(STATUS, function(x){
            as.character(span(icon('flag'),style = paste0('color: ',ifelse(x,'red','green'),'; font-size: 18px;')))
          })) %>% dplyr::arrange(desc(FREQUENCIA))
      
      if(!is.null(old.alarme)){
        
        #check se o rank foi alterado
        for (i in 1:nrow(alarmes)) {
          
          alarm  <- alarmes[i,]
          old    <- old.alarme %>% filter(CD_ID_ALARME == alarm$CD_ID_ALARME)
          
          if(nrow(old) == 0) next
          
          if(alarm$RANK > old$RANK){
            
            alarm$NIVEL <-  as.character(span(icon('caret-down'),style = paste0('color: green; font-size: 25px;')))
            
          }else if(alarm$RANK < old$RANK){
            
            alarm$NIVEL <-  as.character(span(icon('caret-up'),style = paste0('color: red; font-size: 25px;')))
            
          }else{
            alarm$NIVEL  <- old$NIVEL 
          }
          
          alarmes[i,] <- alarm
        }
      }
      
      #save alarme tmp
      systemCache$set(paste0('alarm',setor$CD_ID_SETOR),alarmes %>% select(CD_ID_ALARME,FREQUENCIA,RANK,NIVEL))
      
      obj <- list(
        alarmes = alarmes %>% select(
          ALARME,
          ALVO,
          FREQUENCIA,
          PORCENTUAL,
          'DATA INICIO',
          'DATA TERMINO',
          'DURAÇÃO',
          NIVEL,
          STATUS
        ),
        notification = quantidadeNotificao
      )
      
    }# end if n > 0
    else{
      
      aux <- matrix(nrow = 0,ncol = 8)
      colnames(aux) <- c('ALARME','ALVO','FREQUENCIA','PORCENTUAL','DATA INICIO','DATA TERMINO','DURAÇÃO','NIVEL')
      
      obj <- list(
        alarmes = as.data.frame(aux),
        notification = 0
      ) 
      
    }
    
    #disconect
    DBI::dbDisconnect(con)
    
    #return
    obj
    
  })%...>%(callback)
  
}

calculoTimerReactive <- function(setor){
  
  timer      <- as.integer(setor$TEMPO_REATIVAR_SETOR) * 1000
  timer      <- switch (
    toupper(setor$TEMPO_REATIVAR_UNIDADE_SETOR),
    'SEGUNDO' = timer,
    'MINUTO'  = timer  * 60,
    'HORA'    = timer  * 60 * 60
  )
  
  return(timer)
}

timerCached <- function(setor){
  
  timer      <- setor$TEMPO_PASSADO_SETOR
  timer      <- switch (
    toupper(setor$TEMPO_PASSADO_UNIDADE_SETOR),
    'SEGUNDO' = lubridate::seconds(timer),
    'MINUTO'  = lubridate::minutes(timer),
    'HORA'    = lubridate::hours(timer),
    'DIA'     = lubridate::days(timer)
  )
  return(timer)
}

removeLegendDuplicated <- function(x){
  
  xlinha <- unlist(stringr::str_split(x,' - '))
  
  if(any(stringi::stri_duplicated(xlinha))){
    x <- xlinha[!stri_duplicated(xlinha)]
  }
  x
}

creatTableAnalise <- function(dataset,height = 400){
  
  DT::renderDataTable({
    
    DT::datatable({dataset %>% mutate(PORCENTUAL = paste0(PORCENTUAL,'%'))},
                  callback = JS("table.on('click.dt', 'td', function() {
                   var row_=table.cell(this).index().row;
                   var col=table.cell(this).index().column;
                   Shiny.setInputValue('onTableRowAlarme',{'row':row_,'date':new Date()},{priority: 'event'});
                   });"),
                  class = 'cell-border stripe',
                  extensions = 'Scroller',
                  options = list(
                    language = list(url = 'js/table/translate.json'),
                    dom = 't',
                    bSort=FALSE,
                    columnDefs = list(list(visible=FALSE, targets=c(0)),list(className = 'dt-center', targets = "_all"),list(width = 'auto',targets = "_all")),
                    deferRender = TRUE,
                    scroller = TRUE,
                    fixedHeader = TRUE,
                    scrollX = TRUE,
                    scrollY = paste0(height,'px')
                  ),
                  escape = F,
                  selection = 'none',
    )  %>% DT::formatStyle(colnames(dataset), cursor = 'pointer')
    
  })
  
}

uiShowPlot <- function(input,output,setor,index,plot,callback){
  
  list.events   <- list()
  componentPlot <- NULL
  
  plotobject    <- newObjectPlot(input,output,'plotOutput',plot)
  data          <- systemCache$get('backupdataplots')
  
  plotobject$plotRender({
    
    input$btResetPlot
    
    plotobject$plot(setor,data$plots[[index]],data$dataplots[[index]],displayModeBar = TRUE)
  }) 
  
  
  #Modal para Dialog
  showModal(modalDialog(
    title = dialogTitleClose(plot$TITLE_PLOT,function(){
      
      output$plotOutput <- NULL
      plotobject$destroy()
      removeModal()
      callback()
      
    }),
    size = 'l',
    div(
      style = 'padding: 15px;', 
      actionButton('btResetPlot','',icon = icon('eraser'),style = 'float: right;'),
      div(style = 'margin-top: 50px;',plotobject$plotOutput())
      
    ), 
    footer = list(actionButton('btSair',label = 'Sair'))
  ))
  
  observeEvent(input$btSair,{
    
    output$plotOutput <- NULL
    plotobject$destroy()
    removeModal()
    callback()
    
  },once = T,ignoreInit = T)
  
  
}

insertNewPlotComponent <- function(plot,componentPlot){
  
  child         <- paste0('plot', plot$CD_ID_PLOT)
  boxid         <- paste0('plotbox-',plot$CD_ID_PLOT)
  
  div(
    id = paste0('child-',child),
    box(
      id = boxid,
      solidHeader = T,
      collapsible = T,
      title = tags$span(plot$TITLE_PLOT),
      width = plot$WIDTH_PLOT,
      absolutePanel(
        height = 45,
        width = 'auto',
        top   = 5,
        right = 35,
        div(
          actionButton(inputId = paste0('btEraser', plot$CD_ID_PLOT),
                       label = '',
                       icon = icon('eraser')
          ),
          actionButton(inputId = paste0('bteye', plot$CD_ID_PLOT),
                       label = '',
                       icon = icon('window-maximize')
          ),
          shinyWidgets::dropdownButton(
            inputId = paste0('btgears', plot$CD_ID_PLOT),
            tags$h2("List of Input"),
            selectInput(inputId = 'xcol', label = 'X Variable', choices = names(iris)),
            selectInput(inputId = 'ycol', label = 'Y Variable', choices = names(iris), selected = names(iris)[[2]]),
            sliderInput(inputId = 'clusters', label = 'Cluster count', value = 3, min = 1, max = 9),
            circle = FALSE,
            icon = icon("gear"), 
            width = "300px",
            tooltip = tooltipOptions(title = "Configuração extras")) %>% 
            tagAppendAttributes( style = 'float: right; margin-left: 5px;') %>% 
            tagAppendAttributesFind(2,style = 'margin-left: -250px; border-color: gray;')
        )
      ),
      div(style = 'padding: 15px; height: auto; width: 100%;',componentPlot)
    ))
  
}

themasPlotyGGplot <- function(args = NULL,text.x.angle = 0){
  
  return(
    ggplot2::theme(args,
                   axis.text.x = ggplot2::element_text(angle = text.x.angle),
                   #legend.background = element_rect(fill = 'transparent'),
                   legend.title = ggplot2::element_blank(),
                   #legend.text  = element_text(colour = 'white'),
                   #axis.text = element_text(colour = 'white'),
                   #axis.title = element_text(colour = 'white',size = 10),
                   axis.line = ggplot2::element_line(colour = 'gray'),
                   panel.grid.major = ggplot2::element_line(size = 0.5, linetype  = 'solid', colour = "lightgray")
    )
    
  )
}

layoutPloty <- function(x,legend.text = ''){
  
  return(plotly::layout(
    x,
    plot_bgcolor = 'transparent',
    paper_bgcolor = 'transparent',
    modebar = list(
      bgcolor = 'transparent',
      color = 'transparent',
      activecolor = 'transparent'
    ),
    showlegend = TRUE,
    legend  = list(title= list(text=legend.text,font = list(color = 'black',size = 12)),font = list(color = 'black',size = 10)),
    xaxis=list(fixedrange=TRUE),
    yaxis=list(fixedrange=TRUE)
  ) %>%  htmlwidgets::onRender("function(el,x){
                               el.on('plotly_legendclick', function(){ return false; })
                               }"))
}

layoutPlotyDefault <- function(x,legend.text = ''){
  
  plotly::layout(
    x,
    plot_bgcolor = 'transparent',
    paper_bgcolor = 'transparent',
    showlegend = TRUE,
    modebar = list(
      bgcolor = 'transparent',
      color = 'lightgray',
      activecolor = 'darkgray'
    ),
    legend  = list(title= list(text=legend.text,font = list(color = 'black',size = 12)),font = list(color = 'black',size = 10))
  )
}

apllyFunction <- function(sensor,valores){
  
  sapply(valores,function(valor){
    
    if(!is.null(sensor$CD_ID_FUNCTION) && !is.na(sensor$CD_ID_FUNCTION)){
      
      statement <- paste0('X <- ',valor,'\n ',sensor$BODY_FUNCTION)
      
      return(eval(parse(text = statement)))
    }
    else
    {
      return(valor)
    }
    
  })
  
}

hoverTextReplace <- function(gg,targets,replace){
  
  for (i in seq_along(gg$x$data)){
    
    for(k in seq_along(targets))
      gg$x$data[[i]]$text <- stringr::str_replace(gg$x$data[[i]]$text,targets[k],replace[k])  
  }
  gg 
}

callFunctionAtributo <- function(dataframe,variavel,body){
  
  sapply(dataframe, function(x){
    
    tryCatch({
      varx  <- paste0("var ",tolower(variavel)," = ",x,";\n")
      js::js_eval(paste0(varx,body))
    },error = function(e){
      x
    })
  })

}

clusterCoresProcess <- function(){
  
  #Register the Cluster
  # cl <- makeCluster(detectCores() - 1)
  # registerDoParallel(cl)
  # clusterExport(cl,list('statementCondiction','interroptor','systemCache'))
  # 
  # dataplots  <-  foreach(
  #                  i             = seq_along(plots),
  #                  .combine      = list,
  #                  .multicombine = TRUE,
  #                  .inorder      = FALSE,
  #                  .packages = c("stringr", "dplyr","stringi","foreach")
  #                )%dopar%{
  # 
  #   plot           <- plots[[i]]
  #   dataplot       <- plot$dataplots
  #   dataframes.tmp <- dataframes
  #   data.cache     <- systemCache$get(paste0('dataplotcache',setor$CD_ID_SETOR,plot$CD_ID_PLOT))
  #   status.cache   <- !is.null(data.cache)
  #   if(status.cache){
  #     
  #     dataframes.tmp  <- lapply(dataframes.tmp, 
  #                               function(x){
  #                                 if(!is.null(x$dataframe)){
  #                                   x$dataframe <- x$dataframe %>% filter(.data[[x$timeline]] > max(data.cache$TIME))
  #                                   
  #                                   if(nrow(x$dataframe) == 0){
  #                                     x$dataframe <- NULL
  #                                   }
  #                                 }
  #                                 return(x)
  #                               }) 
  #   }
  #   
  #   dataset <- foreach(
  #     index    = 1:nrow(dataplot),
  #     .combine = rbind,
  #     .inorder = FALSE
  #   ) %do%{
  #     
  #     interroptor$execInterrupts()
  #     
  #     data <- dataplot[index,]
  #     Y       <- NA
  #     X       <- NA
  #     LEGEND  <- NA
  #     MESSAGE <- NA
  #     TIME    <- NA
  #     #statementCondiction
  #     tryCatch({
  #       
  #       if(is.na(data$CD_ID_OBJECT_Y)){
  #         
  #         object.x   <- (setor$OBJETOS %>% rlist::list.filter(CD_ID_OBJECT == data$CD_ID_OBJECT_X))[[1]]
  #         atributo.x <- (object.x$ATRIBUTOS %>% rlist::list.filter(CD_ID_ATRIBUTO == data$CD_ID_ATRIBUTO_X))[[1]]
  #         
  #         x.value    <- rlist::list.filter(dataframes.tmp,CD_ID_STRUCT == object.x$CD_ID_STRUCT)[[1]]
  #         
  #         if(!is.null(x.value$dataframe)){
  #           
  #           X <- formatDataType(x.value$dataframe[[atributo.x$NAME_ATRIBUTO]],atributo.x$NAME_DATA)
  #           
  #           if(nrow(atributo.x$CONDICAO_QUALITATIVA) > 0 && plot$TIPO_X_DATA == 'text'){
  #             X <- sapply(X, function(x) statementCondiction(atributo = atributo.x,valor = x))
  #           }
  #           
  #           TIME   <- x.value$dataframe[[x.value$timeline]]
  #           LEGEND <- object.x$NAME_OBJECT
  #         }
  #         
  #       }else{
  #         
  #         object.y   <- (setor$OBJETOS %>% rlist::list.filter(CD_ID_OBJECT == data$CD_ID_OBJECT_Y))[[1]]
  #         object.x   <- (setor$OBJETOS %>% rlist::list.filter(CD_ID_OBJECT == data$CD_ID_OBJECT_X))[[1]]
  #         atributo.y <- (object.y$ATRIBUTOS %>% rlist::list.filter(CD_ID_ATRIBUTO == data$CD_ID_ATRIBUTO_Y))[[1]]
  #         atributo.x <- (object.x$ATRIBUTOS %>% rlist::list.filter(CD_ID_ATRIBUTO == data$CD_ID_ATRIBUTO_X))[[1]]
  #         
  #         y.value <- rlist::list.filter(dataframes.tmp,CD_ID_STRUCT == object.y$CD_ID_STRUCT)[[1]]
  #         x.value <- rlist::list.filter(dataframes.tmp,CD_ID_STRUCT == object.x$CD_ID_STRUCT)[[1]]
  #         
  #         if(!is.null(y.value$dataframe) && !is.null(x.value$dataframe)){
  #           
  #           Y <- formatDataType(y.value$dataframe[[atributo.y$NAME_ATRIBUTO]],atributo.y$NAME_DATA)
  #           X <- formatDataType(x.value$dataframe[[atributo.x$NAME_ATRIBUTO]],atributo.x$NAME_DATA)
  #           
  #           #statemente logic Y
  #           if(nrow(atributo.y$CONDICAO_QUALITATIVA) > 0 && plot$TIPO_Y_DATA == 'text'){
  #             Y <- sapply(Y, function(y) statementCondiction(atributo = atributo.y,valor = y))
  #           }
  #           #statemente logic X
  #           if(nrow(atributo.x$CONDICAO_QUALITATIVA) > 0 && plot$TIPO_X_DATA == 'text'){
  #             X <- sapply(X, function(x) statementCondiction(atributo = atributo.x,valor = x))
  #           }
  #           
  #           if(object.y$NAME_OBJECT == object.x$NAME_OBJECT)
  #             LEGEND  <- paste0(object.y$NAME_OBJECT)
  #           else
  #             LEGEND  <- paste0(object.y$NAME_OBJECT,' - ',object.x$NAME_OBJECT)
  #           
  #           
  #           if(length(y.value$dataframe[[y.value$timeline]]) > length(x.value$dataframe[[x.value$timeline]]))
  #             TIME    <- y.value$dataframe[[y.value$timeline]]
  #           else
  #             TIME    <- x.value$dataframe[[x.value$timeline]]
  #         }
  #         
  #       }
  #       
  #     },error = function(e){
  #       MESSAGE <- e
  #     })
  #     
  #     #data.frame(Y = setNames(Y,NULL),X = setNames(X,NULL),LEGEND = LEGEND,MESSAGE = message)
  #     cbind(
  #       gdata::cbindX(data.frame(Y = setNames(Y, NULL)), X = data.frame(X = setNames(X, NULL))),
  #       data.frame(LEGEND = LEGEND, MESSAGE = MESSAGE,TIME = TIME)
  #     )
  #   } # end foreach
  #   
  #   if(status.cache){
  #     if(!all(is.na(dataset)))
  #       dataset <- rbind(data.cache,dataset)
  #     else
  #       dataset <- data.cache
  #   }
  #   
  #   systemCache$set(paste0('dataplotcache',setor$CD_ID_SETOR,plot$CD_ID_PLOT),dataset)
  #   
  #   return(dataset)
  #   
  # }
  # 
  # #Stopping cluster
  # stopCluster(cl)
  # stopImplicitCluster()
  
}

buildDataframeToPlot <- function(plot,df){

  if('Line' == plot$NAME_TIPO)
  {
   
  }
  else if('Area' == plot$NAME_TIPO)
  {
  
  }
  else if('Box' == plot$NAME_TIPO)
  {
    if(plot$TIPO_X_DATA == "time"){
  
      if(all(is.na(df$X))) return(df)
      
      status.mounths <- as.numeric(max(df$X) - min(df$X),units = 'weeks') >= 1
      status.dias    <- as.numeric(max(df$X) - min(df$X),units = 'days')  >= 1
      status.hours   <- as.numeric(max(df$X) - min(df$X),units = 'hours') >= 1
      
      if(status.mounths){
        df <- df %>% mutate(X = paste0(format(X,"%m/%y"),' semana'))
      }
      else if(status.dias){
        df <- df %>% mutate(X = paste0(format(X,"%d"),' dia'))
      }
      else if(status.hours){
        df <- df %>% mutate(X = paste0(format(X,"%H"),' hora'))
      }else{
        df <- df %>% mutate(X = format(X,"%H:%M"))
      }
      
    }
    else{
      df <- df %>% mutate(X = as.character(X))
    }
  }
  else if('Scatter' == plot$NAME_TIPO)
  {
    if(all(is.na(df$Y)) && all(is.na(df$X))) return(df)
  }
  else if('Histogram' == plot$NAME_TIPO)
  {

    
  }
  else if('Density' == plot$NAME_TIPO)
  {

   
  }
  else if('Bar' == plot$NAME_TIPO)
  {
    if(all(is.na(df$X))) return(df)
    
    df <- foreach(
      legenda = unique(df$LEGEND),
      .combine = rbind
    ) %do%{
      
      df %>% filter(.data$LEGEND == legenda) %>% 
        group_by(.data$X,.data$LEGEND) %>% summarise(FREQ = n(),.groups = 'drop') %>%
        mutate(PORCENTAL= round((FREQ / sum(FREQ)), 2) * 100)
      
    }
  }
  else if('Pie chart' == plot$NAME_TIPO)
  {
    if(all(is.na(df$X))) return(df)
    
    df <- df %>% group_by(.data$X,.data$LEGEND) %>% summarise(FREQ = n(), .groups = 'drop')
    df <- df %>% mutate(PER = round((FREQ / sum(FREQ)), 2) * 100)
  }
  else if('Heat Map' == plot$NAME_TIPO){
    
   
  }
  else if('Radar' == plot$NAME_TIPO){
    
    df <- df %>% group_by(.data$LEGEND) %>% summarise(FREQ = n(), .groups = 'drop')  
    
  } 
  else if('Map' == plot$NAME_TIPO)
  {
    if(all(is.na(df$Y)) && all(is.na(df$X))) return(df)
    
    df <- df %>%
          group_by(.data$LEGEND) %>% 
          summarise(X = last(X),Y= last(Y),last(DT_HR_LOCAL),ID.X = last(ID.X),ID.Y = last(ID.Y), .groups = 'drop')
  }
  return(df)
}