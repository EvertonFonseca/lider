
selectCronogramaFreqDao <- function(con){
  
  DBI::dbGetQuery(con,'SELECT * FROM CRONOGRAMA_FREQ')
}

selectCronogramaDiasDao <- function(con){
  
  DBI::dbGetQuery(con,'SELECT * FROM CRONOGRAMA_DIAS')
}

selectCronogramaMesesDao <- function(con){
  
  DBI::dbGetQuery(con,'SELECT * FROM CRONOGRAMA_MESES')
}