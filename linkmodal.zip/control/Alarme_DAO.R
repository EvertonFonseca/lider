insertNewAlarmeDAO <- function(con,obj){
  
  id <- nextSequenciaID(con,'ALARME')
  
  insertTable(con,'ALARME',obj)
  
}

selectAllAlarmesDAO <- function(con){
  
  query <- "SELECT DISTINCT
            A.CD_ID_ALARME,
            A.NAME_ALARME,
            A.LOGICA,
            A.DESCRICAO_ALARME,
            A.FG_ONLINE,
            A.STATUS,
            A.ACTIVE_REVERSE,
            S.CD_ID_ATRIBUTO,
            S.NAME_ATRIBUTO,
            S.CD_ID_STRUCT,
            S.CD_ID_DATA,
            CH.CD_ID_OBJECT,
            CH.ID_OBJECT,
            aa.CD_ID_A,
            aa.SCRIPT_A,
            aa.LAST_CALL,
            U.NAME_USER
            FROM alarme A 
            INNER JOIN atributo_alarme SA ON SA.CD_ID_ALARME = A.CD_ID_ALARME 
            INNER JOIN atributo S ON S.CD_ID_ATRIBUTO = SA.CD_ID_ATRIBUTO
            INNER JOIN object CH  ON CH.CD_ID_OBJECT = A.CD_ID_OBJECT
            INNER JOIN setor SE ON SE.CD_ID_SETOR  = CH.CD_ID_SETOR
            INNER JOIN object_struct CM ON CM.CD_ID_STRUCT = CH.CD_ID_STRUCT
            INNER JOIN users U ON U.CD_ID_USER  = SE.CD_ID_USER
            INNER JOIN agendamento_alarme aa ON aa.CD_ID_ALARME = A.CD_ID_ALARME"
              
   DBI::dbGetQuery(con,query)
  
}

selectAllAlarmes <- function(con){
  
  source('control/Object_DAO.R',local = TRUE)
  
  query   <- "SELECT * FROM ALARME"
  
  alarmes <- matrixToModalEncapsolado(DBI::dbGetQuery(con,query))
  
  for (i in seq_along(alarmes)) {
    
    #object
    alarmes[[i]]$OBJECT      <- selectObjectById(con,alarmes[[i]]$CD_ID_OBJECT)
    #agendamentos
    alarmes[[i]]$AGENDAMENTO <- matrixToModalEncapsolado(selectAgendamentoAlarme(con,alarmes[[i]]))
    #emails
    alarmes[[i]]$EMAILS      <- selectEmailAlarme(con,alarmes[[i]])
    #phones
    alarmes[[i]]$PHONES      <- selectPhoneAlarme(con,alarmes[[i]])
    #messages
    alarmes[[i]]$MENSSAGES   <- selectMessageAlarme(con,alarmes[[i]])
   
  }

   return(alarmes)
}

selectMessageAlarme <- function(con,alarme){
  
  DBI::dbGetQuery(con,'SELECT * FROM MESSAGE_ALARME WHERE CD_ID_ALARME = ?',params = alarme$CD_ID_ALARME)
  
}

selectEmailAlarme <- function(con,alarme){
  
  DBI::dbGetQuery(con,'SELECT * 
                       FROM email_alarme e
                       INNER JOIN emails es ON e.CD_ID_EMAIL = es.CD_ID_EMAIL
                       WHERE CD_ID_ALARME = ?',params = alarme$CD_ID_ALARME)
  
}

selectPhoneAlarme <- function(con,alarme){
  
  DBI::dbGetQuery(con,'SELECT *
                       FROM phone_alarme pa
                       INNER JOIN phones p ON p.CD_ID_PHONE = pa.CD_ID_PHONE
                       WHERE CD_ID_ALARME = ?',params = alarme$CD_ID_ALARME)
  
}

selectAgendamentoAlarme <- function(con,alarme){
  
  DBI::dbGetQuery(con,'SELECT * FROM agendamento_alarme WHERE CD_ID_ALARME = ?',params = alarme$CD_ID_ALARME)
}