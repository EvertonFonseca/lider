checkifExistNameFunction <- function(con,name){
  
    DBI::dbGetQuery(con,'SELECT COUNT(*) AS STATUS FROM FUNCTION_ATRIBUTO WHERE NAME_FUNCTION = ?',params = name) %>%
    select(STATUS) %>% pull() > 0
}

checkifExistNameFunctionEdit <- function(con,id,name){
  
  DBI::dbGetQuery(con,'SELECT COUNT(*) AS STATUS FROM FUNCTION_ATRIBUTO WHERE NAME_FUNCTION = ? AND CD_ID_FUNCTION != ?',params = list(name,id)) %>%
  select(STATUS) %>% pull() > 0
}

selectAllFuncao <- function(con){
  
  DBI::dbGetQuery(con,'SELECT
                       F.CD_ID_FUNCTION,
                       F.NAME_FUNCTION,
                       F.BODY_FUNCTION,
                       F.FG_ACTIVE_FUNCTION,
                       A.CD_ID_ATRIBUTO,
                       A.CD_ID_STRUCT,
                       A.NAME_ATRIBUTO,
                       OS.NAME_STRUCT
                       FROM function_atributo F
                       INNER JOIN atributo A ON A.CD_ID_ATRIBUTO = F.CD_ID_ATRIBUTO
                       INNER JOIN object_struct OS ON OS.CD_ID_STRUCT = A.CD_ID_STRUCT')
  
}

selectAllFuncaoByAtributo <- function(con,atributo){
  
  DBI::dbGetQuery(con,'SELECT * FROM FUNCTION_ATRIBUTO WHERE CD_ID_ATRIBUTO = ?',params = atributo$CD_ID_ATRIBUTO)
  
}