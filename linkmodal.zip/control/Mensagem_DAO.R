
processaMessageOnline <- function(name){
  
  quee <- ipc::shinyQueue()
  quee$consumer$start(1000)
  
  future.callr::callr({
    
   source('control/Database.R',local = T)
   repeat({
     
     con <- newConnection()
     
     if(DBI::dbIsValid(con)){
       
       query <- 'SELECT
               a.NAME_ALARME,
               mo.CD_ID_ONLINE,
               a.DESCRICAO_ALARME,
               a.STATUS,
               mo.DT_HR_LOCAL,
               ch.NAME_OBJECT,
               s.NAME_SETOR
               FROM message_online mo 
               INNER JOIN alarme a ON mo.CD_ID_ALARME = a.CD_ID_ALARME
               INNER JOIN OBJECT ch  ON ch.CD_ID_OBJECT   = a.CD_ID_OBJECT
               INNER JOIN setor s  ON s.CD_ID_SETOR   = ch.CD_ID_SETOR
               WHERE a.FG_ONLINE = 1 AND mo.FG_PROCESSED = 0
               ORDER BY DT_HR_LOCAL'
       
       notification <- DBI::dbGetQuery(con,query) %>% mutate(DT_HR_LOCAL = as.POSIXct(as.POSIXlt(DT_HR_LOCAL,tz = Sys.timezone())))
       
       if(nrow(notification) > 0)
       {
         #envia as notificacao para App
         quee$producer$fireAssignReactive(name,notification)
       }
       
       DBI::dbDisconnect(con)
     }
     #sleep by 1s
     Sys.sleep(1)
   })
    
  })
  return(quee)
}

disableAllNotification <- function(x,callback){
  
  source('global.R',encoding = 'UTF-8',local = T)
  source('control/Database.R',local = T)
  
  con <- newConnection()
  x   <- listaToModalToDataframe(x)
  tryResetConnection(con,function(con){
    
    #update os processos
    DBI::dbExecute(
      con,
      'UPDATE MESSAGE_ONLINE SET FG_PROCESSED = 1, DT_HR_LOCAL = ? WHERE CD_ID_ONLINE = ?',
      params = list(x$DT_HR_LOCAL, x$CD_ID_ONLINE)
    )
    
    callback()
  })
  
  return(invisible(NULL))
}


textStatus <- function(status){
  
  #['Crítico' = 3,'Aviso' = 2,'Informação' = 1,'Sucesso' = 0]
  switch (as.character(status),
          '1' = 'red',
          '2' = 'orange',
          '3' = 'blue',
          '4' = 'green',
  )
  
}

iconStatus <- function(status){
  
  #['Crítico' = 3,'Aviso' = 2,'Informação' = 1,'Sucesso' = 0]
  switch (as.character(status),
    '1' = icon('skull-crossbones'),
    '2' = icon('exclamation'),
    '3' = icon('info'),
    '4' = icon('check'),
  )
  
}

eventObserveDropClosed <- function(id,eventName){
  
  shinyjs::runjs(paste0(
    "var status = false;
         var observer = new MutationObserver(function(mutations) {

            var component = document.getElementById('",id,"');
            mutations.forEach(mutation => {
                  if (mutation.attributeName === 'class') {
                       
                      if(component.className == 'shinydashboard-menu-output shiny-bound-output dropdown notifications-menu' && status)
                       {
                         Shiny.setInputValue('",eventName,"',new Date());
                         status = false;
                       }
                      else if(component.className == 'shinydashboard-menu-output shiny-bound-output dropdown notifications-menu open')
                        status = true;
                  }
              })
          
          });
          
          var target = document.querySelector('#",id,"');
          observer.observe(target, { attributes: true});"))
  
}
