checkifExistNameObject <- function(con,name){
  
  DBI::dbGetQuery(con,'SELECT COUNT(*) AS STATUS FROM OBJECT WHERE NAME_OBJECT = ?',params = list(name)) %>% pull() > 0
  
}

checkifExistNameObjectEdit <- function(con,id,name){
  
  DBI::dbGetQuery(con,'SELECT COUNT(*) AS STATUS FROM OBJECT WHERE NAME_OBJECT = ? AND CD_ID_OBJECT != ?',params = list(name,id)) %>% pull() > 0
  
}

checkifExistIdObject <- function(con,name,id.struct){
  
  DBI::dbGetQuery(con,'SELECT COUNT(*) AS STATUS FROM OBJECT WHERE ID_OBJECT = ? AND CD_ID_STRUCT = ?',params = list(name,id.struct)) %>% pull() > 0
  
}

checkifExistIdObjectEdit <- function(con,id,name,id.struct){
  
  DBI::dbGetQuery(con,'SELECT COUNT(*) AS STATUS FROM OBJECT WHERE ID_OBJECT = ? AND CD_ID_OBJECT != ? AND CD_ID_STRUCT = ?',params = list(name,id,id.struct)) %>% pull() > 0
  
}

selectAllObjects <- function(con,check.fg.online = FALSE){
  
  if(!check.fg.online)
  DBI::dbGetQuery(con,'SELECT 
                       O.CD_ID_OBJECT,
                       O.ID_OBJECT,
                       O.NAME_OBJECT,
                       O.FG_ONLINE,
                       O.CD_ID_SETOR,
                       OS.CD_ID_STRUCT,
                       OS.NAME_STRUCT,
                       ID_ATRIBUTO,
                       S.NAME_SETOR
                       FROM object O
                       INNER JOIN object_struct OS ON OS.CD_ID_STRUCT = O.CD_ID_STRUCT
                       INNER JOIN setor S ON S.CD_ID_SETOR = O.CD_ID_SETOR')
  else
    DBI::dbGetQuery(con,'SELECT 
                       O.CD_ID_OBJECT,
                       O.ID_OBJECT,
                       O.NAME_OBJECT,
                       O.FG_ONLINE,
                       O.CD_ID_SETOR,
                       OS.CD_ID_STRUCT,
                       OS.NAME_STRUCT,
                       ID_ATRIBUTO,
                       S.NAME_SETOR
                       FROM object O
                       INNER JOIN object_struct OS ON OS.CD_ID_STRUCT = O.CD_ID_STRUCT
                       INNER JOIN setor S ON S.CD_ID_SETOR = O.CD_ID_SETOR 
                       WHERE O.FG_ONLINE = 1')
  
}

selectObject <- function(con,user,setor,flag.online = FALSE){
  
  source('control/Model_DAO.R',local  = TRUE)
  
  tryCatch({
    
    query <- NA
    if(flag.online)
      query <- paste0("SELECT c.*,
                           cm.NAME_STRUCT
                           FROM object c INNER JOIN object_struct cm ON c.CD_ID_STRUCT = cm.CD_ID_STRUCT 
                           WHERE FG_ONLINE = 1 AND CD_ID_SETOR = ?")
    else
      query <- paste0("SELECT c.*,
                           cm.NAME_STRUCT
                           FROM object c INNER JOIN object_struct cm ON c.CD_ID_STRUCT = cm.CD_ID_STRUCT 
                           WHERE CD_ID_SETOR = ?")
    
    objetos <- matrixToModalEncapsolado(DBI::dbGetQuery(con,query,params = list(setor$CD_ID_SETOR)))
     
    for (k in seq_along(objetos)) {
      
      object  <- objetos[[k]]
      objetos[[k]]$ATRIBUTOS <- selectAllAtributoOfStructName(con,list(CD_ID_STRUCT = object$CD_ID_STRUCT))
    }
    
    setor$OBJETOS <- objetos
    
  })
  
  return(setor)
}

selectObjectById <- function(con,id){
  
  source('control/Model_DAO.R',local  = TRUE)
  
  tryCatch({
    
    query <- paste0("SELECT c.*,
                           cm.NAME_STRUCT
                           FROM object c INNER JOIN object_struct cm ON c.CD_ID_STRUCT = cm.CD_ID_STRUCT 
                           WHERE CD_ID_OBJECT = ?")
    
    
    objetos <- matrixToModalEncapsolado(DBI::dbGetQuery(con,query,params = list(id)))
    
    for (k in seq_along(objetos)) {
      
      object  <- objetos[[k]]
      objetos[[k]]$ATRIBUTOS <- selectAllAtributoOfStructName(con,list(CD_ID_STRUCT = object$CD_ID_STRUCT))
    }
    
     return(objetos) 
    
  })
  
  return(NULL)
}

selectObjects <- function(con,user,setores,flag.online = FALSE){

  source('control/Model_DAO.R',local = TRUE)
  
  tryCatch({
    
    if(length(setores) > 0)
    {
      for (i in 1:length(setores)) {
        
        query <- NA
        if(flag.online)
          query <- paste0("SELECT c.*,
                           cm.NAME_STRUCT
                           FROM object c INNER JOIN object_struct cm ON c.CD_ID_STRUCT = cm.CD_ID_STRUCT 
                           WHERE FG_ONLINE = 1 AND CD_ID_SETOR = ?")
        else
          query <- paste0("SELECT c.*,
                           cm.NAME_STRUCT
                           FROM object c INNER JOIN object_struct cm ON c.CD_ID_STRUCT = cm.CD_ID_STRUCT 
                           WHERE CD_ID_SETOR = ?")
        
        objetos <- matrixToModalEncapsolado(DBI::dbGetQuery(con,query,params = list(setores[[i]]$CD_ID_SETOR)))
        
        for (k in 1:length(objetos)) {
          
          object  <- objetos[[k]]
          objetos[[k]]$ATRIBUTOS <- selectAllAtributoOfStructName(con,list(CD_ID_STRUCT = object$CD_ID_STRUCT))
        }
        
        setores[[i]]$OBJETOS <- objetos
        
      } # end for
    }# end if
    
  })
  
  return(setores)
}
