hasAlterSession <- function(con,user){
  
  flag <- DBI::dbGetQuery(con,'SELECT FG_UPDATE FROM users WHERE CD_ID_USER = ?',params = list(user$CD_ID_USER))
  flag$FG_UPDATE
}

loginUser <- function(con,name,pass){
  
  user <- NULL
  
  tryCatch({
    
    query <- paste0("SELECT 
                    CD_ID_USER,
                    NAME_USER,
                    PASS_USER,
                    FG_ONLINE_USER,
                    CD_ID_TIPO,
                    CD_ID_PARENT,
                    SETORES_ACESSO
                    FROM users 
                    WHERE NAME_USER = '",toupper(name),"' AND PASS_USER = '",pass,"'")
    user  <-  DBI::dbGetQuery(con,query)
    
    #load all config graphics of user
    #user$chips <- dbGetQuery(con,paste0("SELECT * FROM CHIPS WHERE CD_ID_USER = ",user$CD_ID))
    
  },error = function(e){
    
  })
  
  return(user)
  
}

checkIFUserAlreadyExist <- function(con,name){
  
  query <- paste0("SELECT NAME_USER FROM users WHERE NAME_USER = '",toupper(name),"'")
  user  <- DBI::dbGetQuery(con,query)
  
  return(nrow(user) > 0)
}

updateUserOnline <- function(con,user,online){
  
  query  <- paste0("UPDATE USERS SET FG_ONLINE_USER = ",online," WHERE CD_ID_USER = ",user$CD_ID_USER)
  DBI::dbExecute(con,query)
}


updateAllChildrenSession <- function(con,user){
  
    source('control/Database.R',local = T)
  
     updateTable(con,
                 'USERS',
                 paste0('CD_ID_PARENT = ',user$CD_ID_USER,' AND FG_ONLINE_USER = 1'),
                 list(FG_UPDATE = 1)
                 )
}

selectAllChildrenOfUser <- function(con,user){
  
  query <- 'SELECT * FROM users u INNER JOIN users_tipo ut ON u.CD_ID_TIPO = ut.CD_ID_UT WHERE CD_ID_PARENT = ? ORDER BY NAME_USER'
  DBI::dbGetQuery(con,query,params = user$CD_ID_USER)
  
}


checkSessionUserUpdate <- function(input,output,user){
  
  future.callr::callr({
    
    source('control/Database.R',local = T)

    con  <- newConnection()
    
    if(DBI::dbIsValid(con)){
      
     flag <- hasAlterSession(con,user)
     
     if(flag){
        updateTable(con,'USERS',paste0('CD_ID_USER = ',user$CD_ID_USER),list(FG_UPDATE = 0))
     }
     flag
    }
    else{
      FALSE
    }
    
  })%...>%(function(status){
    
    if(status){
       dialogModalOutputSession(input,output,'Sessão foi alterada pelo administrador!')
       
    }
    
  })
  
}