
source('global.R',encoding = "UTF-8")

library(shiny)
library(cachem)
library(dplyr)
library(promises)
library(future)
library(lubridate)
library(foreach)
library(leaflet)
library(leaflet.extras)
library(sp)
#library(plotly)
#library(scales)
library(shinyjs)
library(shiny.i18n) # translate
library(shinyTime)
library(shinyWidgets)
library(shinydashboard)
library(shinydashboardPlus)
#library(shinycssloaders)
library(purrr)
library(shinyBS)
library(tidyr)
#library(htmltools)
library(ipc)
library(pryr)
library(doParallel)
library(parallel)
library(RMySQL)
#library,(gdata)
#library,(rlist)
#library,(DT)
library(vov)
#library('sortable')
#library('colourpicker')
#library(openssl)
#library(httr)
#library(mailR)
library(rJava)
#library(future.apply)
library(shinyCleave)
#library(BMS)
#library(varhandle)

future::plan(future::multisession)

#options
options(
    #shiny.maxRequestSize = 9999 * 1024 ^ 2,
    #shiny.reactlog=TRUE,
    warn = -1,
    future.rng.onMisuse = "ignore"
)

source('control/Users.R',encoding = "UTF-8")
source('model/Components.R',encoding = "UTF-8")
source('view/ui.R',encoding = "UTF-8")
source('view/themes.R',encoding = "UTF-8")

env.global   <- new.env(.GlobalEnv)

translate <- shiny.i18n::Translator$new(translation_json_path  = "www/js/translate/translate.json")
translate$set_translation_language(transl_language = 'pt-br')

session.status <- FALSE
session.user   <- NULL
input          <- NULL
output         <- NULL
systemCache    <- NULL
session        <- NULL
event.click    <- FALSE

server <- function(input,output,session) {
    
    if(session.status){
        shinyjs::runjs("document.body.parentNode.removeChild(document.body);\n window.close();")
        session$close()
        return()
    }
    
    input         <<- input
    output        <<- output
    status.loader <<- FALSE
    
    args <- commandArgs(trailingOnly=TRUE)
    #write(args,'texto.txt')
    # if(length(args) == 2)
    # {
    #   session.user <- list(url = args[1],id = args[2])
    #   httr::POST(paste0('http://',session.user$url,'/',session.user$id),body = "Ola Wt c++ eu sou Shiny = D")
    # }
    # 
    # shinyjs::addCssClass(selector = "body", class = "sidebar-collapse")
    
    session.status    <<- TRUE
    processo.now      <- NULL
    #init all process of user
    processos                    <- NULL
    user                         <- NULL
    reactiveNotification         <- reactiveVal(NULL)
    inputDropsNotification       <- reactiveVal(list())
    inputListNotificationNotRead <- list()
    timeReactive                 <<- reactiveTimer(60000)
    queeNotification             <- NULL
    onResizedWindows             <<- reactiveVal(NULL)
    
    source('view/InputInit.R',encoding = "UTF-8",local = T)
    source('view/OuputInit.R',encoding = "UTF-8",local = T)
    source('control/Mensagem_DAO.R',encoding = "UTF-8",local = T)
    source('view/uiLogin.R',encoding = "UTF-8",env.global)
    source('control/Users.R',encoding = "UTF-8",env.global)
    
    env.global$uiLogin(
        input = input,
        output    = output,
        session   = session,
        translate = translate,
        callback  = function(con,session.user){
            
            source('control/Database.R',local  = T)
            source('control/Setor_DAO.R',local = T)
            
            systemCache <<- cachem::cache_disk(max_size = Inf,missing = NULL)
            user        <<- session.user
            setores     <-  selectSetoresOnly(con,user)
            processos   <<- uiTabSetores(input,output,setores)
          
            eventObserveDropClosed('dropsAlertas','dropNotification')
            #start processo de notificacao
            queeNotification <<- processaMessageOnline('reactiveNotification')
            
            rm(list = ls(all.names = TRUE,envir = environment())) #will clear all objects includes hidden objects.
            rm(list = ls(all.names = T,envir = env.global),envir = env.global)
            
            gc()
            
            #updateTabItems(session = session,inputId = 'tabs',selected = 'tabCentral')
            
        })
    
    shiny::observeEvent(timeReactive(),{
        
        req(user)
        req(user$CD_ID_TIPO == 3) # apenas usuarios analista
        
        checkSessionUserUpdate(input,output,user)
        
    },ignoreInit = TRUE)
    
    observeEvent(input$onResized,{
        
        onResizedWindows(list(width = input$onResized[1],height = input$onResized[2]))
        
    })
    
    ##### END MENUS #####
    shiny::onStop(function() {
        
        if(!is.null(processo.now))
        {
            processo.now$destroy()
        }
        
        if (!is.null(user))
        {
            source('control/Database.R',local = T)
            
            con <- newConnection()
            updateUserOnline(con,user, FALSE)
            DBI::dbDisconnect(con)
        }
        
        if(!is.null(systemCache))
            systemCache$destroy()

        stopApp()
        
    })
    
}

shinyApp(ui(translate), server)



shiny::runGitHub("https://github.com/EvertonFonseca","linkmodal")
