uiServerNew <- function(con,input,output,drivers,callback){
  
  source('model/SmartObserve.R',local = T)
  obs    <- newObserve()
  resete <- reactiveVal()

  id <- 'dialogObj'
  cssStyle <- list()
  cssStyle[[paste0(' #parent',id,' .modal-dialog')]]  <- paste0('height: 80% !important;')
  cssStyle[[paste0(' #parent',id,' .modal-content')]] <- paste0('width: 100% !important; height: 100% !important;')
  cssStyle[[paste0(' #parent',id,' .modal-body')]]    <- paste0('width: 100% !important; height: calc(100% - 57px - 65px) !important; overflow-y: hidden;')
  
  showModal(
    div(
      id = paste0('parent', id),
      style = paste0("height: 100%;"),
      shinyjs::inlineCSS(cssStyle),
      dialogModal(
        title = dialogTitleClose('Nova Database',function(){
          obs$destroy()
          removeModal()
          callback()
        }),
        size = 'm',
        uiOutput(outputId = 'container',style = "width: 100%; height: 100%; overflow-y: auto;"),
        footer = tagList(actionButton(inputId = "btSair", "Sair"),
                         actionButton('btTestar','Testar'),
                         actionButton('btSalvar', 'Salvar'))))
  )
  
  
  output$container <- renderUI({
    
    resete()
    
    output$panelPass <- renderUI({
      
      n      <- as.integer(input$btEye)
      status <- (n %% 2) == 0
      
      if(n == 0){
        passwordInput('textPass',label = 'Senha:',placeholder = 'exemplo: ****',value = '')
      }
      else if(status)
      {
        updateActionButton(getDefaultReactiveDomain(),inputId = 'btEye',icon = icon('eye'))
        passwordInput('textPass',label = 'Senha:',placeholder = 'exemplo: ****',value = input$textPass)
      }
      else
      {
        updateActionButton(getDefaultReactiveDomain(),inputId = 'btEye',icon = icon('eye-slash'))
        textInput('textPass',label = 'Senha:',placeholder = 'exemplo: 1234',value  = input$textPass)
        
      }
      
    })
    
    tagList(
      br(),
      panelTitle(title = "Autenticação",
                 background.color.title = 'white',
                 title.color = 'black',
                 border.color = 'lightgray',
                 children = div(
                   style  = 'padding: 15px;',
                   tagList(
                     shinyjs::inlineCSS("#textTitle    {text-transform: uppercase;}"),
                     shinyjs::inlineCSS("#textDbname   {text-transform: uppercase;}"),
                     textInput('textTitle',label = 'Titulo:',placeholder = 'exemplo: Foo'),
                     selectInput('comboDriver',label = "Driver:",choices = drivers$NAME_DRIVER),
                     textInput('textHost',label = 'Host:',placeholder = 'exemplo: 127.0.0.1'),
                     numericInput('textPort',label = 'Porta:',step = 1,value = 1521),
                     textInput('textDbname',label = 'Database:',placeholder = 'exemplo: TESTE'),
                     textInput('textUser',label = 'Usuario:',placeholder = 'exemplo: ADMIN'),
                     splitLayout(uiOutput('panelPass'),actionButton('btEye',label = '',icon = icon('eye'),style = 'margin-top: 25px;'),cellWidths = c('300px','45px'),cellArgs = list(style = "padding: 6px"))
                     
                   )
                 )
      )
    )
    
  })
  
  
  obs$add(observeEvent(input$btSair,{
    
    #destroy all observe events
    DBI::dbDisconnect(con)
    obs$destroy()
    removeModal()
    callback()
    
  },ignoreInit = T,ignoreNULL = T))
  
  obs$add(observeEvent(input$btTestar,{
    
    actionWebUser(function(){
      
      driver   <- isolate(input$comboDriver)
      host     <- isolate(input$textHost)
      port     <- isolate(input$textPort)
      user     <- isolate(input$textUser)
      pass     <- isolate(input$textPass)
      dbname   <- toupper(isolate(input$textDbname))
  
      con <- connectarDatabase(
        driver = driver,
        host   = host,
        port   = port,
        dbname = dbname,
        user   = user,
        pass   = pass
      )
      
      if(!is.null(con)){
        showNotification("Autenticação foi estabelecer com sucesso!", type = "message")
        DBI::dbDisconnect(con)
      }
      else{
        showNotification("Autenticação não foi valida!", type = "error")
      }
      
    },auto.remove = TRUE)
    
  },ignoreInit = T,ignoreNULL = T))
  
  obs$add(observeEvent(input$btSalvar,{
    
    title    <- toupper(isolate(input$textTitle))
    driver   <- drivers %>% filter(NAME_DRIVER == isolate(input$comboDriver))
    host     <- isolate(input$textHost)
    port     <- isolate(input$textPort)
    user     <- isolate(input$textUser)
    pass     <- isolate(input$textPass)
    dbname   <- toupper(isolate(input$textDbname))
    
    if(stringi::stri_isempty(stringr::str_trim(title))){
      
      showNotification("O titulo não foi preenchido!", type = "error")
      
      return()
    }
    
    if(checkifExistNameDatabase(con = con,name = title)){
      
      showNotification("O titulo já possui nos registros!", type = "error")
    }
    else{
      
      tryResetConnection(con,function(coon){
        
        con <<- coon
        
        insertTable(con,'DATABASE_STORE',list(
          TITLE_DB = title,
          HOST_DB  = host,
          PORT_DB  = port,
          NAME_DB  = dbname,
          USER_DB  = user,
          PASS_DB  = pass,
          CD_ID_DRIVER = driver$CD_ID_DRIVER
          
        ))

        dialogConfirm(
          title = 'Sevidor criado com sucesso!',
          text = 'Deseja criar novamente um novo servidor?',
          callback = function(status) {
          
            if(!status){
              DBI::dbDisconnect(con)
              obs$destroy()
              callback()
              removeModal()
            }
            else
              resete(Sys.time())
            
          })
        
      })
    }
  
  },ignoreInit = T,ignoreNULL = T))
  
}

uiServerTable <- function(con,input,output,servers,drivers,callback){
  
  source('model/SmartObserve.R',local = T)
  obs  <- newObserve()
  
  observeEvents  <- list()
  servers        <- reactiveVal(servers)
  sliderPosition <- reactiveVal(1)
  server         <- NULL
  
  id <- 'dialogObj'
  cssStyle <- list()
  cssStyle[[paste0(' #parent',id,' .modal-dialog')]]  <- paste0('height: 80% !important;')
  cssStyle[[paste0(' #parent',id,' .modal-content')]] <- paste0('width: 100% !important; height: 100% !important;')
  cssStyle[[paste0(' #parent',id,' .modal-body')]]    <- paste0('width: 100% !important; height: calc(100% - 57px - 65px) !important; overflow-y: hidden;')
  
  #Modal para Dialog
  showModal(div(
    id = paste0('parent', id),
    style = paste0("height: 100%;"),
    shinyjs::inlineCSS(cssStyle),
    dialogModal(
      title = dialogTitleClose('Registro Servidor',function(){
        
        #destroy all observe events
        DBI::dbDisconnect(con)
        obs$destroy()
        removeModal()
        callback()
        
      }),
      size = 'm',
      swiper(id = 'swiperMain',width = '100%',height = '100%',
             parent.style = 'height: 100%; width: 100%;',
             swiperSlideUi(
               outputId = 'slider1',
               style = 'height: 100%; width: 100%; overflow-y: auto; padding: 5px;',
               uiOutput('slider1')
             ),
             swiperSlideUi(
               outputId = 'slider2',
               style = 'height: 100%; width: 100%; overflow-y: auto; padding: 5px;',
               uiOutput('slider2',style = 'display: none;')
             )
      ),
      footer = uiOutput('uiFooter'),
      callback = function(size){onResizedWindows(list(height = size$height))}
    )
  ))
  
  output$uiFooter <- renderUI({
    
    current <- sliderPosition()
    
    if(current == 1){
      tagList(actionButton('btActionCancel', label = "Sair"))
    }
    else{
      tagList(actionButton('btActionCancel', label = "Voltar"),actionButton('btActionTestar', label = "Testar"),actionButton('btActionUpdate', label = "Atualizar"))
    }
    
    
  })
  
  output$slider1 <- renderUI({
    
    output$tableDinamica <- DT::renderDataTable({
      
      req(input$comboDriver)
      
      dataset <-  servers() %>% filter(NAME_DRIVER == input$comboDriver)
      
      if(length(dataset) == 0) return(NULL)
      
      colunaNames <- c('LINHA','TITULO','DRIVER','VISUALIZAR / EDITAR','REMOVER')
      
      DT::datatable({
        
        dataset %>% 
          mutate_if(is.POSIXct,function(x){ format(x,'%d/%m/%Y %H:%M:%S')})  %>% 
          mutate_if(is.Date,function(x){ format(x,'%d/%m/%Y')}) %>% 
          mutate_if(is.character,toupper) %>% 
          mutate(
             !!colunaNames[1] := 1:nrow(dataset),
             !!colunaNames[2] :=  dataset$TITLE_DB,
             !!colunaNames[3] :=  dataset$NAME_DRIVER,
             !!colunaNames[4] :=  sapply(dataset$CD_ID_DB, function (x) {
                   
                   as.character(
                     actionButton(
                       paste0('btEdit'),
                       label = '',
                       icon = icon('eye'),
                       onclick = paste0('Shiny.setInputValue(\"editPressedRow\","',x,'",{priority: "event"})'),
                       #style = 'background-color: transparent; color: lightblue; border-solid: none;'
                     )
                   )
                 }),
             !!colunaNames[5] :=  sapply(dataset$CD_ID_DB, function(x){
                   
                   as.character(
                     actionButton(
                       paste0('btRemove'),
                       label = '',
                       icon = icon('trash'),
                       onclick = paste0('Shiny.setInputValue(\"deletePressedRow\","',x,'",{priority: "event"})'),
                       #style = 'background-color: transparent; color: lightblue; border-solid: none;'
                     )
                   )
                   
                 })
                 
          ) %>% select(colunaNames) %>% arrange(colunaNames[2])
      }, 
      class = 'cell-border stripe',
      extensions = 'Scroller',
      options = list(
        language = list(url = 'js/table/translate.json'),
        dom = 't',
        bSort=FALSE,
        columnDefs = list(list(visible=FALSE, targets=c(0)),list(className = 'dt-center', targets = "_all"),list(width = 'autos',targets = c(3))),
        deferRender = TRUE,
        scroller = FALSE,
        fixedHeader = TRUE,
        scrollX = TRUE,
        scrollY = 'auto'
      ),
      escape = F,
      selection = 'none',
      )  %>% DT::formatStyle(colnames(result), cursor = 'pointer')
      
    })
    
    div(
      style = 'border-style: solid; border-color: white; border-width: 1px; overflow-x: auto;',
      selectInput('comboDriver','Driver',choices = drivers$NAME_DRIVER),
      DT::dataTableOutput(outputId = 'tableDinamica')
    )
    
  })
  
  output$slider2 <- renderUI({
   
    output$panelPassEdit <- renderUI({
      
      n      <- as.integer(input$btEye)
      status <- (n %% 2) == 0
      
      if(n == 0){
        passwordInput('textPassEdit',label = 'Senha:',placeholder = 'exemplo: ****',value = server$PASS_DB)
      }
      else if(status)
      {
        updateActionButton(getDefaultReactiveDomain(),inputId = 'btEye',icon = icon('eye'))
        passwordInput('textPassEdit',label = 'Senha:',placeholder = 'exemplo: ****',value = input$textPassEdit)
      }
      else
      {
        updateActionButton(getDefaultReactiveDomain(),inputId = 'btEye',icon = icon('eye-slash'))
        textInput('textPassEdit',label = 'Senha:',placeholder = 'exemplo: 1234',value  = input$textPassEdit)
        
      }
      
    })

    panelTitle(title = "Autenticação",
               background.color.title = 'white',
               title.color = 'black',
               border.color = 'lightgray',
               children = div(
                 style  = 'padding: 15px;',
                 tagList(
                   shinyjs::inlineCSS("#textTitleEdit    {text-transform: uppercase;}"),
                   shinyjs::inlineCSS("#textDbnameEdit   {text-transform: uppercase;}"),
                   textInput('textTitleEdit',label = 'Titulo:',placeholder = 'exemplo: Foo',value = server$TITLE_DB),
                   selectInput('comboDriverEdit',label = "Driver:",choices = server$NAME_DRIVER),
                   textInput('textHostEdit',label = 'Host:',placeholder = 'exemplo: 127.0.0.1',value = server$HOST_DB),
                   numericInput('textPortEdit',label = 'Porta:',step = 1,value = server$PORT_DB),
                   textInput('textDbnameEdit',label = 'Database:',placeholder = 'exemplo: TESTE',value = server$NAME_DB),
                   textInput('textUserEdit',label = 'Usuario:',placeholder = 'exemplo: ADMIN',value = server$USER_DB),
                   splitLayout(uiOutput('panelPassEdit'),actionButton('btEye',label = '',icon = icon('eye'),style = 'margin-top: 25px;'),cellWidths = c('300px','45px'),cellArgs = list(style = "padding: 6px"))
                 )
               ))
    
  })
  
  obs$add(observeEvent(input$editPressedRow,{
    
    server <<- isolate(servers()) %>% filter(CD_ID_DB == input$editPressedRow)
    
    swiperSlideNext()
    sliderPosition(swiperPosition)
    
  },ignoreInit = T))
  
  obs$add(observeEvent(input$deletePressedRow,{
    
    server <- isolate(servers()) %>% filter(CD_ID_DB == input$deletePressedRow)
    
    messageAlerta(input,
                  title   = paste0('Todos os processos ligado ao servidor será removido!'),
                  message = paste0('Deseja realmente excluir o sevidor',server$TITLE_DB,"?"),
                  callback.no = function(){
                    
                  },
                  callback.yes = function(){
                    
                    tryResetConnection(con,function(conn){
                      
                      con <<- conn
                      #remove Database setor
                      DBI::dbExecute(con,paste0('DELETE FROM DATABASE_STORE WHERE CD_ID_DB = ?',params = server$CD_ID_DB))
                      
                      servers.aux <- selectAllServerWithDriver(con)

                      if(nrow(servers.aux) > 0)
                        servers(servers.aux)
                      else
                      {#destroy all observe events
                        DBI::dbDisconnect(con)
                        obs$destroy()
                        removeModal()
                        callback()
                      }
                    })
                    
                    
                  })
    
  },ignoreInit = T))
  
  obs$add(observeEvent(input$btActionTestar,{
    
    actionWebUser(function(){
      
      driver   <- isolate(input$comboDriverEdit)
      host     <- isolate(input$textHostEdit)
      port     <- isolate(input$textPortEdit)
      user     <- isolate(input$textUserEdit)
      pass     <- isolate(input$textPassEdit)
      dbname   <- toupper(isolate(input$textDbnameEdit))
      
      con.test <- connectarDatabase(
        driver = driver,
        host   = host,
        port   = port,
        dbname = dbname,
        user   = user,
        pass   = pass
      )
      
      if(!is.null(con.test)){
        showNotification("Autenticação foi estabelecer com sucesso!", type = "message")
        DBI::dbDisconnect(con.test)
      }
      else{
        showNotification("Autenticação não foi valida!", type = "error")
      }
      
    },auto.remove = TRUE)
    
  },ignoreInit = T,ignoreNULL = T))
  
  
  obs$add(observeEvent(input$btActionCancel,{
    
    current <- swiperPosition
    
    if(current == 1){
      
      #destroy all observe events
      DBI::dbDisconnect(con)
      obs$destroy()
      removeModal()
      callback()
    }
    else{
      
      swiperSlidePrevious()
      sliderPosition(swiperPosition)
    }
    
  },ignoreInit = T))
  
  obs$add(observeEvent(input$btActionUpdate,{
    
      title    <- toupper(isolate(input$textTitleEdit))
      driver   <- drivers %>% filter(NAME_DRIVER == isolate(input$comboDriverEdit))
      host     <- isolate(input$textHostEdit)
      port     <- isolate(input$textPortEdit)
      user     <- isolate(input$textUserEdit)
      pass     <- isolate(input$textPassEdit)
      dbname   <- toupper(isolate(input$textDbnameEdit))
      
      if(stringi::stri_isempty(stringr::str_trim(title))){
        
        showNotification("O titulo não foi preenchido!", type = "warning")
        
        return()
      }
      
      if(checkifExistNameDatabaseUpdate(con = con,server$CD_ID_DB,name = title)){
        
        showNotification("O titulo já possui nos registros!", type = "warning")
      }
      else{
        
        tryResetConnection(con,function(coon){
          
          con <<- coon
          
          updateTable(con,'DATABASE_STORE',
          paste0('CD_ID_DB = ',server$CD_ID_DB),
          list(
            TITLE_DB = title,
            HOST_DB  = host,
            PORT_DB  = port,
            NAME_DB  = dbname,
            USER_DB  = user,
            PASS_DB  = pass,
            CD_ID_DRIVER = driver$CD_ID_DRIVER
            
          ))
         
          #reload servers
          servers(selectAllServerWithDriver(con))
          swiperSlidePrevious()
          sliderPosition(swiperPosition)
          server <<- NULL
          
        })
      }

  },ignoreInit = T))
  
}