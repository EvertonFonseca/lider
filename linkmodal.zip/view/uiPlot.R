uiPlotNew <- function(con,input,output,tipoPlots,setores,typedatas,estruturas,objetos,callback){
  
  source('model/SmartObserve.R',local = T)
  obs              <- newObserve()
  obs2             <- newObserve()
  tipo.plot        <- NULL
  positionReactive <- reactiveVal(1)
  refresh          <- reactiveVal(NULL)
  context.plot     <- NULL
  setor            <- NULL
  objetos.tmp      <- NULL
  estruturas.tmp   <- NULL
  atributos.tmp    <- NULL
  datatable        <- NULL
  
  id <- 'dialogObj'
  cssStyle <- list()
  cssStyle[[paste0(' #parent',id,' .modal-dialog')]]  <- paste0('height: 80% !important;')
  cssStyle[[paste0(' #parent',id,' .modal-content')]] <- paste0('width: 100% !important; height: 100% !important;')
  cssStyle[[paste0(' #parent',id,' .modal-body')]]    <- paste0('width: 100% !important; height: calc(100% - 57px - 65px) !important; overflow-y: hidden;')
  
  showModal(shiny::div(
    id = paste0('parent', id),
    style = paste0("height: 90%;"),
    shinyjs::inlineCSS(cssStyle),
    dialogModal(
      title = dialogTitleClose('Create Grafico',function(){
        
        shinyjs::runjs("Shiny.setInputValue('comboBoxSetor',null);")
        #destroi todos os events
        DBI::dbDisconnect(con)
        obs$destroy()
        obs2$destroy()
        removeModal()
        callback()
        
      }),
      size = 'm',
      div(style = 'height: 100%; width: 100%;',
          swiper(id = 'swiperMainPlot', 
                 parent.style = 'height: 100%; width: 100%;',
                 width = '100%',
                 height = '100%',
                 swiperSlideUi(
                   outputId = 'slider1',
                   style = 'height: 100%; width: 100%;  overflow-y: auto; overflow-x: hidden;',
                   uiOutput('slider1')),
                 swiperSlideUi(
                   outputId = 'slider2',
                   style = 'height: 100%; width: 100%;  overflow-y: auto;',
                   uiOutput('slider2',style = 'display: none;')),
                 swiperSlideUi(
                   outputId = 'slider3',
                   style = 'height: 100%; width: 100%;  overflow-y: auto;',
                   uiOutput('slider3',style = 'display: none;'))
          )
      ),
      br(),
      footer = uiOutput('uiFooter'))))
  
  output$uiFooter <- renderUI({
    
    current <- positionReactive()
    
    if(current == 1 || current == 2){
      tagList(actionButton(inputId = "btSair","Sair"),actionButton('btSalvar','Avançar'))
    }
    else{
      tagList(actionButton(inputId = "btSair","Voltar"),actionButton('btSalvar','Salvar'))
    }
    
  })

  
  output$slider1 <- renderUI({

    updateTextInput(inputId = 'textTitlePlot',value = '')
    updateTextInput(inputId = 'textEixoX',value = '')
    updateTextInput(inputId = 'textEixoY',value = '')
    updateTextInput(inputId = 'textLegend',value = '')

    output$containerFormat <- renderUI({
      
      tipo.plot <<- tipoPlots %>% filter(NAME_TIPO == input$plotType) 

      x <- NULL
      y <- NULL
      
      if(tipo.plot$CD_ID_TIPO == 1 || tipo.plot$CD_ID_TIPO == 2){ #scatter and line
        
        y <- c("numeric")#typedatas %>% filter(R_DATA == 'numeric' | R_DATA == 'integer')
        x <- c("numeric","time")#typedatas %>% filter(R_DATA == 'numeric' | R_DATA == 'time' | R_DATA == 'date')
        
      }
      else if(tipo.plot$CD_ID_TIPO == 3){ # box
        
        y <- c("numeric")
        x <- c("text","time")
        
      }
      else if(tipo.plot$CD_ID_TIPO == 4){ # hist
        
        y <- c("numeric")
        x <- c("numeric")
        
      }
      else if(tipo.plot$CD_ID_TIPO == 5){ # dens
        
        y <- c("numeric")
        x <- c("numeric")
        
      }
      else if(tipo.plot$CD_ID_TIPO == 6){ # bar
        
        y <- c("numeric")
        x <- c("text")
        
      }
      else if(tipo.plot$CD_ID_TIPO == 7){ # pie
        
        y <- c("numeric")
        x <- c("text")
        
      }
      else if(tipo.plot$CD_ID_TIPO == 8){ # map
        
        y <- c("numeric")
        x <- c("numeric")
        
      }
      
      y.txt    <- column(6,textInput('textEixoY',label  = 'Texto Eixo Y',placeholder = 'Digite o text para Eixo Y',value = isolate(input$textEixoY)))
      y.format <- column(6,selectInput('comboEixoY',label  = 'Tipo de dado Eixo Y',choices = toupper(y)))
      x.txt    <- column(6,textInput('textEixoX',label  = 'Texto Eixo X',placeholder = 'Digite o text para Eixo X',value = isolate(input$textEixoX)))
      x.format <- column(6,selectInput('comboEixoX',label  = 'Tipo de dado Eixo X',choices = toupper(x)))
      
     fluidRow(
       y.txt,
       y.format,
       x.txt,
       x.format
     )
  
    })

    tagList(
      fluidRow(
        shinyjs::inlineCSS("#textTitlePlot {text-transform: uppercase;}"),
        shinyjs::inlineCSS("#textEixoY {text-transform: uppercase;}"),
        shinyjs::inlineCSS("#textEixoX {text-transform: uppercase;}"),
        shinyjs::inlineCSS("#textLegend {text-transform: uppercase;}"),
        column(12,selectInput(
          'comboBoxSetor',
          label = 'Seleciona Setor',
          choices = setores$NAME_SETOR,
          selected = isolate(input$comboBoxSetor)
        )),
        column(12,textInput('textTitlePlot',label = 'Titulo',placeholder = 'Digite o titulo para grafico',value = '')),
      ),    
      br(),
      panelTitle(title = 'Configuração',
                       background.color.title = 'white',
                       title.color = 'black',
                       border.color = 'lightgray',
                       children = fluidRow(style = 'padding: 10px',
                                           column(12,selectInput('plotType',label = 'Tipo de grafico',choices =  tipoPlots$NAME_TIPO,width = '100%')),
                                           column(12,uiOutput('containerFormat')),
                                           column(12,textInput('textLegend',label = 'Texto Legenda',placeholder = 'Digite o titulo para legenda',value = '',width = '100%'))
                                           
                       ))
      
    )# end tagList
  })
  
  output$slider2 <- renderUI({
  
    req(positionReactive() == 2)
    
    output$containerEstruturas <- renderUI({
      
      req(input$comboBoxSetor)
      
      delay(100,{
        changetextPlaceHolder()
      })

      multiInput(
        inputId = 'multiTipoStrutcs',
        width = '100%',
        options = list(
          enable_search = T,
          non_selected_header = "Estruturas não selecionados",
          selected_header     = "Estruturas selecionados"
        ),
        selected =  if(is.null(isolate(input$multiTipoStrutcs))) estruturas.tmp$NAME_STRUCT else isolate(input$multiTipoStrutcs),
        label = "Estrutura do Objeto",
        choices = NULL,
        choiceNames  = lapply(estruturas.tmp$NAME_STRUCT, function(x)  tagList(x)),
        choiceValues = lapply(estruturas.tmp$NAME_STRUCT, function(x)  x)
      ) %>% tagAppendAttributes(style = ';height: auto; width: 100%;')
      
    })
    
    output$containerObjetos <- renderUI({
      
      delay(100,{
        changetextPlaceHolder()
      })
      
      estruturas.tmp <- estruturas.tmp %>% filter(NAME_STRUCT %in% input$multiTipoStrutcs)
      objetos.tmp    <- objetos.tmp %>% filter(CD_ID_STRUCT %in% estruturas.tmp$CD_ID_STRUCT)

      if(tipo.plot$CD_ID_TIPO != 7){
      
        multiInput(
          inputId = 'multiTipoObjects',
          width = '100%',
          options = list(
            enable_search = T,
            non_selected_header = "Objetos não selecionados",
            selected_header     = "Objetos selecionados"
          ),
          selected =  NULL,
          label = "Objeto",
          choices = NULL,
          choiceNames  = lapply(objetos.tmp$NAME_OBJECT, function(x)  tagList(x)),
          choiceValues = lapply(objetos.tmp$NAME_OBJECT, function(x)  x)
        ) %>% tagAppendAttributes(style = ';height: auto; width: 100%;')
      }
      else{
        
        selectInput(
          inputId = 'multiTipoObjects',
          label   = 'Objeto selecionado',
          width   = '100%',
          choices = objetos.tmp$NAME_OBJECT
        )
        
      }
 
    })

    div(
      style = 'height: auto;',
      uiOutput('containerEstruturas'),
      uiOutput('containerObjetos')
    )
    
  })
  
  output$slider3 <- renderUI({

    req(positionReactive() == 3)
    
    objetos.tmp    <- objetos.tmp %>% filter(NAME_OBJECT %in% isolate(input$multiTipoObjects))
    component.y    <- NULL

    obs2$clear()
    
    if(is.null(datatable))
    {
      datatable   <<- reactiveVal({
        x <- as.data.frame(matrix(nrow = 0,ncol = 4))
        colnames(x) <- c(context.plot$EIXO.Y,context.plot$EIXO.X,"LEGENDA","REMOVER")
        x
      })
    }else{
      isolate(datatable({
        x <- as.data.frame(matrix(nrow = 0,ncol = 4))
        colnames(x) <- c(context.plot$EIXO.Y,context.plot$EIXO.X,"LEGENDA","REMOVER")
        x
      }))
    }
    
    obs2$add(observeEvent(input$deletePressedRow,{
      
      id    <- as.integer(input$deletePressedRow)
      table <- isolate(datatable())
      table <- table[-id,]
      
      if(nrow(table) == 0){
        datatable({
          x <- as.data.frame(matrix(nrow = 0,ncol = 4))
          colnames(x) <- c(context.plot$EIXO.Y,context.plot$EIXO.X,"LEGENDA","REMOVER")
          x
        })
      }else{
        datatable(table)
      }
      
      
    },ignoreInit = TRUE,ignoreNULL = TRUE))
    
    obs2$add(observeEvent(input$btInsertTable,{
  
      table     <- isolate(datatable())

      table.new <- insertTablePlot(table          = table,
                                   context.plot   = context.plot,
                                   objetos.tmp    = objetos.tmp,
                                   atributos.tmp  = atributos.tmp,
                                   nameObject.y   = isolate(input$comboObjetoY),
                                   nameObject.x   = isolate(input$comboObjetoX),
                                   nameAtriburo.y = isolate(input$comboAtributoY),
                                   nameAtriburo.x = isolate(input$comboAtributoX)
                                   )

      datatable(rbind(table,table.new))
      
    },ignoreInit = TRUE,ignoreNULL = TRUE))

    obs2$add(observeEvent(input$comboObjetoY,{
      
      objeto         <- objetos.tmp %>% filter(NAME_OBJECT    == input$comboObjetoY)
      atributo       <- atributos.tmp %>% filter((CD_ID_STRUCT == objeto$CD_ID_STRUCT & context.plot$FORMAT.Y == R_DATA) | !is.na(CD_ID_QUAT))  
      updateSelectInput(inputId = 'comboAtributoY',choices = unique(atributo$NAME_ATRIBUTO))
      
    },ignoreNULL = TRUE))
    
    obs2$add(observeEvent(input$comboObjetoX,{
      
      objeto         <- objetos.tmp %>% filter(NAME_OBJECT    == input$comboObjetoX)
      atributo       <- atributos.tmp %>% filter((CD_ID_STRUCT == objeto$CD_ID_STRUCT & context.plot$FORMAT.X == R_DATA) | !is.na(CD_ID_QUAT))
      updateSelectInput(inputId = 'comboAtributoX',choices = unique(atributo$NAME_ATRIBUTO))    
      
    },ignoreNULL = TRUE))
    
    
    output$tableDataframe <- DT::renderDataTable({
      
      datas       <- datatable()  
      colunaNames <- c({if(context.plot$BINARY)context.plot$EIXO.Y else NULL},context.plot$EIXO.X,"LEGENDA","REMOVER")

      if(nrow(datas) > 0){
        
        if(context.plot$BINARY){

          datas <-  datas %>% 
            mutate_if(is.character,toupper) %>% 
            mutate(
              !!colunaNames[1] :=  datas[[context.plot$EIXO.Y]],
              !!colunaNames[2] :=  datas[[context.plot$EIXO.X]],
              !!colunaNames[3] :=  datas$LEGENDA,
              !!colunaNames[4] :=  sapply(1:nrow(datas),function(x){
                
                as.character(
                  actionButton(
                    paste0('btRemove'),
                    label = '',
                    icon = icon('trash'),
                    onclick = paste0('Shiny.setInputValue(\"deletePressedRow\","',x,'",{priority: "event"})'),
                    #style = 'background-color: transparent; color: lightblue; border-solid: none;'
                  )
                )
                
              }))  %>% select(colunaNames)
          
        }else{

          datas <-  datas %>% 
            mutate_if(is.character,toupper) %>% 
            mutate(
              !!colunaNames[1] :=  datas[[context.plot$EIXO.X]],
              !!colunaNames[2] :=  datas$LEGENDA,
              !!colunaNames[3] :=  sapply(1:nrow(datas),function(x){
                
                as.character(
                  actionButton(
                    paste0('btRemove'),
                    label = '',
                    icon = icon('trash'),
                    onclick = paste0('Shiny.setInputValue(\"deletePressedRow\","',x,'",{priority: "event"})'),
                    #style = 'background-color: transparent; color: lightblue; border-solid: none;'
                  )
                )
                
              }))  %>% select(colunaNames)
          
        }
      }
      else{
        datas <-  datas %>% select(colunaNames)
      }
      
      DT::datatable({datas}, 
                    class = 'cell-border stripe',
                    extensions = 'Scroller',
                    options = list(
                      language = list(url = 'js/table/translate.json'),
                      dom = 't',
                      bSort=FALSE,
                      columnDefs = list(list(visible=FALSE, targets=c(0)),list(className = 'dt-center', targets = "_all"),list(width = 'autos',targets = 0:3)),
                      deferRender = TRUE,
                      scroller = FALSE
                    ),
                    escape = F,
                    selection = 'none',
      )  %>% DT::formatStyle(colunaNames, cursor = 'pointer')
      
    })
    
    if(context.plot$BINARY)
    {
      atributos.y    <-   atributos.tmp %>% filter(context.plot$FORMAT.Y == R_DATA)
      component.y    <-   tagList(panelTitle(title = 'Eixo Y',
                                             background.color.title = 'white',
                                             title.color = 'black',
                                             border.color = 'lightgray',
                                             children = div(style = 'padding: 10px',
                                                            splitLayout(
                                                              selectInput('comboObjetoY','Objeto',choices = objetos.tmp$NAME_OBJECT,selected = isolate(input$comboObjetoY),width = '100%'),
                                                              selectInput('comboAtributoY','Atributo',choices = '',width = '100%'),
                                                              cellWidths = c('50%','50%')
                                                            ))),br())
    }
    
    div(
      style = 'padding-left: 15px; padding-right: 15px; padding-bottom: 10px',
      br(),
      component.y,
      panelTitle(title = 'Eixo X',
                 background.color.title = 'white',
                 title.color = 'black',
                 border.color = 'lightgray',
                 children = div(style = 'padding: 10px',
                                splitLayout(
                                  selectInput('comboObjetoX','Objeto',choices = objetos.tmp$NAME_OBJECT,selected = isolate(input$comboObjetoX),width = '100%'),
                                  selectInput('comboAtributoX','Atributo',choices = '',width = '100%'),
                                  cellWidths = c('50%','50%')
                                ))),
      br(),
      span('Adicionar',style = 'font-size: 16px;'),
      actionButton('btInsertTable','',icon = icon('arrow-down'),width = '100%',style = 'font-size: 18px;'),
      br(),
      div(
        style = 'width: 100%; height: auto; padding: 5px;',
        DT::dataTableOutput('tableDataframe')
      ))
    
  })

  obs$add(observeEvent(input$btSalvar,{
    
    #update Buttons
    index <- swiperPosition

    if(index == 1){
      
      textTitle     <- toupper(isolate(input$textTitlePlot))
      textEixoY     <- toupper(isolate(input$textEixoY))
      textEixoX     <- toupper(isolate(input$textEixoX))
      textLegend    <- toupper(isolate(input$textLegend))
      binary.status <- FALSE
      
      
      if(tipo.plot$CD_ID_TIPO  == 1 || tipo.plot$CD_ID_TIPO  == 2 || tipo.plot$CD_ID_TIPO  == 3 || tipo.plot$CD_ID_TIPO  == 8){ #scatter and line

         binary.status <- TRUE
         
         if(checkifTextEmpty(textTitle) || 
            checkifTextEmpty(textEixoY) ||
            checkifTextEmpty(textEixoX) ||
            checkifTextEmpty(textLegend)){
           
           showNotification("Existe campos que não foram preenchido!", type = "warning")
           
           return()
         }
         
         if(stringr::str_trim(textEixoY) == stringr::str_trim(textEixoX)){
           
           showNotification("O texto do Eixo Y e X não podem ser iguais!", type = "warning")
           
           return()
         }
      }
      else{
        
        binary.status <- FALSE
        
        if(checkifTextEmpty(textTitle) || 
           checkifTextEmpty(textEixoX) ||
           checkifTextEmpty(textLegend)){
          
          showNotification("Existe campos que não foram preenchido!", type = "warning")
          
          return()
        }
        
      }
      
      context.plot <<- list(
        TITLE    = textTitle,
        EIXO.X   = textEixoX,
        EIXO.Y   = textEixoY,
        LEGEND   = textLegend,
        FORMAT.X = tolower(isolate(input$comboEixoX)),
        FORMAT.Y = tolower(isolate(input$comboEixoY)),
        BINARY   = binary.status
      )
      
      actionWebUser(function(){
        
        tryResetConnection(con,function(coon){
          
          setor          <<- setores %>% filter(NAME_SETOR == input$comboBoxSetor)
          objetos.tmp    <<- objetos %>% filter(CD_ID_SETOR %in% setor$CD_ID_SETOR)
          estruturas.tmp <<- estruturas %>% filter(CD_ID_STRUCT %in% objetos.tmp$CD_ID_STRUCT)
          atributos.tmp  <<- selectAllAtributosToPlot(con,estruturas.tmp)
          estruturas.tmp <<- validaEstruturasByPlot(context.plot,estruturas.tmp,atributos.tmp)
          
          if(nrow(estruturas.tmp) == 0){
            
            if(binary.status)
            showNotification(
              paste0("Não Existe estruturas que contem o tipo de dados Y: ",
                     context.plot$FORMAT.Y,' e X: ',context.plot$FORMAT.X),
              type = "warning")
            else
              showNotification(
                paste0("Não Existe estruturas que contem o tipo de dados X: ",
                       context.plot$FORMAT.X),
                type = "warning")
            
            setor          <<- NULL
            objetos.tmp    <<- NULL
            estruturas.tmp <<- NULL
            
          }else{
            
            swiperSlideNext()
            positionReactive(swiperPosition)
            
          }

        })
        
      },auto.remove = FALSE)

    }
    else if (index == 2){
      
      if(length(isolate(input$multiTipoObjects)) == 0){
        
        showNotification("Nenhum objeto foi selecionado!", type = "warning")
        return()
      }
      
      swiperSlideNext()
      positionReactive(swiperPosition)
    }
    else if (index == 3){
      
      if(nrow(isolate(datatable())) == 0){
        showNotification("Nenhum dado foi encontrado na tabela dataframe!", type = "warning")
        return()
      }

      tryResetConnection(con,function(coon){
        
        con <<- coon

        status <- tryTransation(con,{
 
           table <- isolate(datatable())
           
           id <- nextSequenciaID(con,'PLOT')

           #inserir plot
           insertTable(con,'PLOT',list(
             CD_ID_PLOT       = id,
             TITLE_PLOT       = context.plot$TITLE,
             TEXT_X_PLOT      = context.plot$EIXO.X,
             TEXT_Y_PLOT      = context.plot$EIXO.Y,
             TEXT_LEGEND_PLOT = context.plot$LEGEND,
             CD_ID_TIPO       = tipo.plot$CD_ID_TIPO,
             CD_ID_SETOR      = setor$CD_ID_SETOR,
             TIPO_Y_DATA      = context.plot$FORMAT.Y,
             TIPO_X_DATA      = context.plot$FORMAT.X,
             ORDEM_PLOT       = setor$COUNT_PLOTS + 1
             
           ))

           #every dataplot
           for (i in 1:nrow(table)) {
               
                data <- table[i,]
                # insert dataplot
                insertTable(con,'DATAPLOT',list(
                  CD_ID_ATRIBUTO_X  = data$ATRIBUTO.X,
                  CD_ID_ATRIBUTO_Y  = ifelse(is.null(data$ATRIBUTO.Y),NA,data$ATRIBUTO.Y),
                  CD_ID_OBJECT_X    = data$OBJECT.X,
                  CD_ID_OBJECT_Y    = ifelse(is.null(data$OBJECT.Y),NA,data$OBJECT.Y),
                  CD_ID_PLOT        = id
                ))
           }
        })
        
        if(status){
          
          dialogConfirm(
            title = 'Grafico criado com sucesso!',
            text = 'Deseja criar novamente um novo grafico?',
            callback = function(status) {
              
              updateTextInput(inputId = 'textTitlePlot',value = '')
              updateTextInput(inputId = 'textEixoX',value = '')
              updateTextInput(inputId = 'textEixoY',value = '')
              updateTextInput(inputId = 'textLegend',value = '')
              
              context.plot     <<- NULL
              setor            <<- NULL
              objetos.tmp      <<- NULL
              estruturas.tmp   <<- NULL
              atributos.tmp    <<- NULL
              datatable        <<- NULL

              if(!status){
                #destroy all observe events
                DBI::dbDisconnect(con)
                obs$destroy()
                obs2$destroy()
                removeModal()
                callback()
              }
              else
              {
                positionReactive(1)
                swiperSlideTo(index = 0)  
              }
              
            })
          
        }
        else{
          showNotification("Não foi possivel realizar essa operação falha na conexão!", type = "error")
        }
        
      })
      
    }
    
  },ignoreInit = T))
  
  obs$add(observeEvent(input$btSair,{
    
    index <- swiperPosition
    
    if(index == 1){
      
      #destroi todos os events
      DBI::dbDisconnect(con)
      obs$destroy()
      obs2$destroy()
      removeModal()
      callback()
    }
    #Sair
    else if(index == 2){

      swiperSlidePrevious()
      positionReactive(swiperPosition)
    }
    else if(index == 3){

      if(nrow(isolate(datatable())) > 0) 
      {
        messageAlerta(input,
                      title   = 'Todos os dados desta etapa serão perdido se voltar para etapa anterior!',
                      message = 'Deseja realmente retroceder?',
                      callback.no = function(){
                        
                      },
                      callback.yes = function(){
                       
                        #define render table null
                        datatable <<- NULL
                        
                        swiperSlidePrevious()
                        positionReactive(swiperPosition)
                      })
      }
      else{
        
        swiperSlidePrevious()
        positionReactive(swiperPosition)
      }
    }
    
    
  },ignoreInit = T))
  
}

uiPlotTable <- function(con,input,output,plots,tipoPlots,setores,typedatas,estruturas,objetos,callback){
  
  source('model/SmartObserve.R',local = T)
  obs              <- newObserve()
  obs2             <- newObserve()
  tipo.plot        <- NULL
  positionReactive <- reactiveVal(1)
  refresh          <- reactiveVal(NULL)
  context.plot     <- NULL
  setor            <- NULL
  objetos.tmp      <- NULL
  estruturas.tmp   <- NULL
  atributos.tmp    <- NULL
  datatable        <- NULL
  plots            <- reactiveVal(plots)
  plot             <- NULL
  dataplots        <- NULL
  
  id <- 'dialogObj'
  cssStyle <- list()
  cssStyle[[paste0(' #parent',id,' .modal-dialog')]]  <- paste0('height: 80% !important;')
  cssStyle[[paste0(' #parent',id,' .modal-content')]] <- paste0('width: 100% !important; height: 100% !important;')
  cssStyle[[paste0(' #parent',id,' .modal-body')]]    <- paste0('width: 100% !important; height: calc(100% - 57px - 65px) !important; overflow-y: hidden;')
  
  showModal(shiny::div(
    id = paste0('parent', id),
    style = paste0("height: 90%;"),
    shinyjs::inlineCSS(cssStyle),
    dialogModal(
      title = dialogTitleClose('Create Grafico',function(){
        
        shinyjs::runjs("Shiny.setInputValue('comboBoxSetor',null);")
        #destroi todos os events
        DBI::dbDisconnect(con)
        obs$destroy()
        obs2$destroy()
        removeModal()
        callback()
        
      }),
      size = 'm',
      div(style = 'height: 100%; width: 100%;',
          swiper(id = 'swiperMainPlot', 
                 parent.style = 'height: 100%; width: 100%;',
                 width = '100%',
                 height = '100%',
                 swiperSlideUi(
                   outputId = 'slider1',
                   style = 'height: 100%; width: 100%;  overflow-y: auto; overflow-x: hidden;',
                   uiOutput('slider1')),
                 swiperSlideUi(
                   outputId = 'slider2',
                   style = 'height: 100%; width: 100%;  overflow-y: auto;  overflow-x: hidden;',
                   uiOutput('slider2',style = 'display: none;')),
                 swiperSlideUi(
                   outputId = 'slider3',
                   style = 'height: 100%; width: 100%;  overflow-y: auto;',
                   uiOutput('slider3',style = 'display: none;')),
                 swiperSlideUi(
                   outputId = 'slider4',
                   style = 'height: 100%; width: 100%;  overflow-y: auto;',
                   uiOutput('slider4',style = 'display: none;'))
          )
      ),
      br(),
      footer = uiOutput('uiFooter'),
      callback = function(size){onResizedWindows(list(height = size$height))}
      )))
  
  output$uiFooter <- renderUI({
    
    current <- positionReactive()
    
    if(current == 1){
      tagList(actionButton('btSair', label = "Sair"))
    }
    else if(current == 2 || current == 3) {
      tagList(actionButton('btSair', label = "Voltar"),actionButton('btSalvar', label = "Avançar"))
    }
    else{
      tagList(actionButton('btSair', label = "Voltar"),actionButton('btSalvar', label = "Atualizar"))
    }
    
    
  })
  
  
  output$slider1 <- renderUI({
    
    output$tableDinamica <- DT::renderDataTable({
      
      setor   <<- setores %>% filter(NAME_SETOR == input$comboSetor)
      dataset <-  plots() %>% filter(CD_ID_SETOR == setor$CD_ID_SETOR)
      
      if(length(dataset) == 0) return(NULL)
      
      colunaNames <- c('LINHA','TITULO','GRAFICO','EIXO Y','EIXO X','LEGENDA','ATIVO','VISUALIZAR / EDITAR','REMOVER')
      
      height <- (onResizedWindows()$height * 0.65)  - (200)
      
      DT::datatable({
        
        dataset %>% 
          mutate_if(is.POSIXct,function(x){ format(x,'%d/%m/%Y %H:%M:%S')})  %>% 
          mutate_if(is.Date,function(x){ format(x,'%d/%m/%Y')}) %>% 
          mutate_if(is.character,toupper) %>% 
          mutate(
            !!colunaNames[1] :=  1:nrow(dataset),
            !!colunaNames[2] :=  dataset$TITLE_PLOT,
            !!colunaNames[3] :=  dataset$NAME_TIPO,
            !!colunaNames[4] :=  dataset$TEXT_Y_PLOT,
            !!colunaNames[5] :=  dataset$TEXT_X_PLOT,
            !!colunaNames[6] :=  dataset$TEXT_LEGEND_PLOT,
            !!colunaNames[7] :=  apply(dataset,1, function(x) {
              
              x <- as.list(x)
              
              json <- paste0('{"object":"',x$CD_ID_PLOT,'","status":document.getElementById("',paste0("checkBoxActive",x$CD_ID_PLOT),'").checked}')  
              
              as.character( div(
                style = "width: auto; height: auto;",
                prettyToggle(
                  inputId = paste0("checkBoxActive",x$CD_ID_PLOT),
                  label_on = "Sim",
                  label_off = "Não", 
                  outline = TRUE,
                  plain = TRUE,
                  value = as.logical(as.integer(x$FLAG_ACTIVE)),
                  icon_on = icon("thumbs-up"),
                  icon_off = icon("thumbs-down"),
                  bigger = T,
                  width = 'auto'
                ),
                onclick = paste0('Shiny.setInputValue(\"editPressedStatus\",',json,',{priority: "event"})')
              ))
              
            }),
            !!colunaNames[8] :=  sapply(dataset$CD_ID_PLOT, function (x) {
              
              as.character(
                actionButton(
                  paste0('btEdit'),
                  label = '',
                  icon = icon('eye'),
                  onclick = paste0('Shiny.setInputValue(\"editPressedRow\","',x,'",{priority: "event"})'),
                  #style = 'background-color: transparent; color: lightblue; border-solid: none;'
                )
              )
            }),
            !!colunaNames[9] :=  sapply(dataset$CD_ID_PLOT, function(x){
              
              as.character(
                actionButton(
                  paste0('btRemove'),
                  label = '',
                  icon = icon('trash'),
                  onclick = paste0('Shiny.setInputValue(\"deletePressedRow\","',x,'",{priority: "event"})'),
                  #style = 'background-color: transparent; color: lightblue; border-solid: none;'
                )
              )
              
            })
            
          ) %>% select(colunaNames) %>% arrange(colunaNames[2])
      }, 
      class = 'cell-border stripe',
      extensions = 'Scroller',
      options = list(
        language = list(url = 'js/table/translate.json'),
        dom = 't',
        bSort=FALSE,
        columnDefs = list(list(visible=FALSE, targets=c(0)),list(className = 'dt-center', targets = "_all")),
        deferRender = TRUE,
        scroller = TRUE,
        fixedHeader = TRUE,
        scrollX = TRUE,
        scrollY = paste0(height,"px")
      ),
      escape = F,
      selection = 'none',
      )  %>% DT::formatStyle(colnames(result), cursor = 'pointer')
      
    })
    
    div(
      selectInput('comboSetor','Setor',choices = setores$NAME_SETOR),
      DT::dataTableOutput(outputId = 'tableDinamica')
    )
    
  })
  
  output$slider2 <- renderUI({
    
    req(positionReactive() == 2)
   
    output$containerFormat <- renderUI({
      
      tipo.plot <<- tipoPlots %>% filter(NAME_TIPO == isolate(input$plotType)) 
      
      x <- NULL
      y <- NULL
      
      if(tipo.plot$CD_ID_TIPO == 1 || tipo.plot$CD_ID_TIPO == 2){ #scatter and line
        
        y <- c("numeric")#typedatas %>% filter(R_DATA == 'numeric' | R_DATA == 'integer')
        x <- c("numeric","time")#typedatas %>% filter(R_DATA == 'numeric' | R_DATA == 'time' | R_DATA == 'date')
        
      }
      else if(tipo.plot$CD_ID_TIPO == 3){ # box
        
        y <- c("numeric")
        x <- c("text","time")
        
      }
      else if(tipo.plot$CD_ID_TIPO == 4){ # hist
        
        y <- c("numeric")
        x <- c("numeric")
        
      }
      else if(tipo.plot$CD_ID_TIPO == 5){ # dens
        
        y <- c("numeric")
        x <- c("numeric")
        
      }
      else if(tipo.plot$CD_ID_TIPO == 6){ # bar
        
        y <- c("numeric")
        x <- c("text")
        
      }
      else if(tipo.plot$CD_ID_TIPO == 7){ # pie
        
        y <- c("numeric")
        x <- c("text")
        
      }
      else if(tipo.plot$CD_ID_TIPO == 8){ # map
        
        y <- c("numeric")
        x <- c("numeric")
        
      }
      
      y.txt    <- column(6,textInput('textEixoY',label  = 'Texto Eixo Y',placeholder = 'Digite o text para Eixo Y',value = plot$TEXT_Y_PLOT))
      y.format <- column(6,selectInput('comboEixoY',label  = 'Tipo de dado Eixo Y',choices = plot$TIPO_Y_DATA))
      x.txt    <- column(6,textInput('textEixoX',label  = 'Texto Eixo X',placeholder = 'Digite o text para Eixo X',value = plot$TEXT_X_PLOT))
      x.format <- column(6,selectInput('comboEixoX',label  = 'Tipo de dado Eixo X',choices = plot$TIPO_X_DATA))
      
      fluidRow(
        y.txt,
        y.format,
        x.txt,
        x.format
      )
      
    })
    
    tagList(
      fluidRow(
        shinyjs::inlineCSS("#textTitlePlot {text-transform: uppercase;}"),
        shinyjs::inlineCSS("#textEixoY {text-transform: uppercase;}"),
        shinyjs::inlineCSS("#textEixoX {text-transform: uppercase;}"),
        shinyjs::inlineCSS("#textLegend {text-transform: uppercase;}"),
        column(12,selectInput(
          'comboBoxSetor',
          label = 'Seleciona Setor',
          choices  = setor$NAME_SETOR
        )),
        column(12,textInput('textTitlePlot',label = 'Titulo',placeholder = 'Digite o titulo para grafico',value = plot$TITLE_PLOT)),
      ),    
      br(),
      panelTitle(title = 'Configuração',
                 background.color.title = 'white',
                 title.color = 'black',
                 border.color = 'lightgray',
                 children = fluidRow(style = 'padding: 10px',
                                     column(12,selectInput('plotType',label = 'Tipo de grafico',choices =  plot$NAME_TIPO,width = '100%')),
                                     column(12,uiOutput('containerFormat')),
                                     column(12,textInput('textLegend',label = 'Texto Legenda',placeholder = 'Digite o titulo para legenda',value = plot$TEXT_LEGEND_PLOT,width = '100%'))
                                     
                 ))
      
    )# end tagList
    
  })
  
  output$slider3 <- renderUI({
    
    req(positionReactive() == 3)

    struct.init <- NULL
    object.init <- NULL

    if(context.plot$BINARY){
      
      obj.y        <- objetos %>% filter(CD_ID_OBJECT %in% dataplots$CD_ID_OBJECT_Y)
      struct.y     <- estruturas %>% filter(CD_ID_STRUCT %in% unique(obj.y$CD_ID_STRUCT))
      
      obj.x        <- objetos %>% filter(CD_ID_OBJECT %in% dataplots$CD_ID_OBJECT_X)
      struct.x     <- estruturas %>% filter(CD_ID_STRUCT %in% unique(obj.x$CD_ID_STRUCT))
      
      struct.init  <- rbind(struct.y,struct.y)
      object.init  <- rbind(obj.y,obj.x)
      
    }else{
      
      object.init <- objetos %>% filter(CD_ID_OBJECT %in% dataplots$CD_ID_OBJECT_X)
      struct.init <- estruturas %>% filter(CD_ID_STRUCT %in% unique(object.init$CD_ID_STRUCT))
    }
    
    output$containerEstruturas <- renderUI({
      
      req(input$comboBoxSetor)

      delay(100,{
        changetextPlaceHolder()
      })
      
      multiInput(
        inputId = 'multiTipoStrutcs',
        width = '100%',
        options = list(
          enable_search = T,
          non_selected_header = "Estruturas não selecionados",
          selected_header     = "Estruturas selecionados"
        ),
        selected = struct.init$NAME_STRUCT,
        label = "Estrutura do Objeto",
        choices = NULL,
        choiceNames  = lapply(estruturas.tmp$NAME_STRUCT, function(x)  tagList(x)),
        choiceValues = lapply(estruturas.tmp$NAME_STRUCT, function(x)  x)
      ) %>% tagAppendAttributes(style = ';height: auto; width: 100%;')
      
    })
    
    output$containerObjetos <- renderUI({
      
      delay(100,{
        changetextPlaceHolder()
      })
      
      estruturas.tmp <- estruturas.tmp %>% filter(NAME_STRUCT %in% input$multiTipoStrutcs)
      objetos.tmp    <- objetos.tmp %>% filter(CD_ID_STRUCT %in% estruturas.tmp$CD_ID_STRUCT)
      
      if(tipo.plot$CD_ID_TIPO != 7){
        
        multiInput(
          inputId = 'multiTipoObjects',
          width = '100%',
          options = list(
            enable_search = T,
            non_selected_header = "Objetos não selecionados",
            selected_header     = "Objetos selecionados"
          ),
          selected =  object.init$NAME_OBJECT,
          label = "Objeto",
          choices = NULL,
          choiceNames  = lapply(objetos.tmp$NAME_OBJECT, function(x)  tagList(x)),
          choiceValues = lapply(objetos.tmp$NAME_OBJECT, function(x)  x)
        ) %>% tagAppendAttributes(style = ';height: auto; width: 100%;')
      }
      else{
        
        selectInput(
          inputId = 'multiTipoObjects',
          label   = 'Objeto selecionado',
          width   = '100%',
          choices = objetos.tmp$NAME_OBJECT
        )
        
      }
      
    })
    
    div(
      style = 'height: auto;',
      uiOutput('containerEstruturas'),
      uiOutput('containerObjetos')
    )
    
  })
  
  output$slider4 <- renderUI({
    
    req(positionReactive() == 4)

    objetos.tmp      <- objetos.tmp %>% filter(NAME_OBJECT %in% isolate(input$multiTipoObjects))
    component.y      <- NULL
    obs2$clear()

    datatable <<- reactiveVal({
      
      x <- as.data.frame(matrix(nrow = 0,ncol = 4))
      colnames(x) <- c(context.plot$EIXO.Y,context.plot$EIXO.X,"LEGENDA","REMOVER")

      foreach(
        i = 1:nrow(dataplots),
        .combine = rbind,
        .inorder = TRUE
      ) %do%{
        
        insertTablePlotInit(table      = x,
                        context.plot   = context.plot,
                        objetos.tmp    = objetos.tmp,
                        atributos.tmp  = atributos.tmp,
                        dataplot       = dataplots[i,])
        
      }
    })
   
    obs2$add(observeEvent(input$deletePressedRowTable,{
      
      id    <- as.integer(input$deletePressedRowTable)
      table <- isolate(datatable())
      table <- table[-id,]

      if(nrow(table) == 0){
        datatable({
          x <- as.data.frame(matrix(nrow = 0,ncol = 4))
          colnames(x) <- c(context.plot$EIXO.Y,context.plot$EIXO.X,"LEGENDA","REMOVER")
          x
        })
      }else{
        datatable(table)
      }

      
    },ignoreInit = TRUE,ignoreNULL = TRUE))
    
    obs2$add(observeEvent(input$btInsertTable,{
      
      table     <- isolate(datatable())

      table.new <- insertTablePlot(table          = table,
                                   context.plot   = context.plot,
                                   objetos.tmp    = objetos.tmp,
                                   atributos.tmp  = atributos.tmp,
                                   nameObject.y   = isolate(input$comboObjetoY),
                                   nameObject.x   = isolate(input$comboObjetoX),
                                   nameAtriburo.y = isolate(input$comboAtributoY),
                                   nameAtriburo.x = isolate(input$comboAtributoX)
      )

      datatable(rbind(table,table.new))
      
    },ignoreInit = TRUE,ignoreNULL = TRUE))
    
    obs2$add(observeEvent(input$comboObjetoY,{

      objeto         <- objetos.tmp %>% filter(NAME_OBJECT    == input$comboObjetoY)
      
      if(nrow(objeto) == 0) return(NULL)
      
      atributo       <- atributos.tmp %>% filter((CD_ID_STRUCT == objeto$CD_ID_STRUCT & context.plot$FORMAT.Y == R_DATA) | !is.na(CD_ID_QUAT))  
      updateSelectInput(inputId = 'comboAtributoY',choices = atributo$NAME_ATRIBUTO)

      
    },ignoreNULL = TRUE))
    
    obs2$add(observeEvent(input$comboObjetoX,{
      
      objeto         <- objetos.tmp %>% filter(NAME_OBJECT    == input$comboObjetoX)
      
      if(nrow(objeto) == 0) return(NULL)
      
      atributo       <- atributos.tmp %>% filter((CD_ID_STRUCT == objeto$CD_ID_STRUCT & context.plot$FORMAT.X == R_DATA) | !is.na(CD_ID_QUAT))
      updateSelectInput(inputId = 'comboAtributoX',choices = atributo$NAME_ATRIBUTO)  

      
    },ignoreNULL = TRUE))
    
    
    output$tableDataframe <- DT::renderDataTable({
      
      datas       <- datatable()  
      colunaNames <- c({if(context.plot$BINARY)context.plot$EIXO.Y else NULL},context.plot$EIXO.X,"LEGENDA","REMOVER")
      
      if(nrow(datas) > 0){
        
        if(context.plot$BINARY){
          
          datas <-  datas %>% 
            mutate_if(is.character,toupper) %>% 
            mutate(
              !!colunaNames[1] :=  datas[[context.plot$EIXO.Y]],
              !!colunaNames[2] :=  datas[[context.plot$EIXO.X]],
              !!colunaNames[3] :=  datas$LEGENDA,
              !!colunaNames[4] :=  sapply(1:nrow(datas),function(x){
                
                as.character(
                  actionButton(
                    paste0('btRemove'),
                    label = '',
                    icon = icon('trash'),
                    onclick = paste0('Shiny.setInputValue(\"deletePressedRowTable\","',x,'",{priority: "event"})'),
                    #style = 'background-color: transparent; color: lightblue; border-solid: none;'
                  )
                )
                
              }))  %>% select(colunaNames)
          
        }else{
          
          datas <-  datas %>% 
            mutate_if(is.character,toupper) %>% 
            mutate(
              !!colunaNames[1] :=  datas[[context.plot$EIXO.X]],
              !!colunaNames[2] :=  datas$LEGENDA,
              !!colunaNames[3] :=  sapply(1:nrow(datas),function(x){
                
                as.character(
                  actionButton(
                    paste0('btRemove'),
                    label = '',
                    icon = icon('trash'),
                    onclick = paste0('Shiny.setInputValue(\"deletePressedRowTable\","',x,'",{priority: "event"})'),
                    #style = 'background-color: transparent; color: lightblue; border-solid: none;'
                  )
                )
                
              }))  %>% select(colunaNames)
          
        }
      }
      else{
        datas <-  datas %>% select(colunaNames)
      }
      
      DT::datatable({datas}, 
                    class = 'cell-border stripe',
                    extensions = 'Scroller',
                    options = list(
                      language = list(url = 'js/table/translate.json'),
                      dom = 't',
                      bSort=FALSE,
                      columnDefs = list(list(visible=FALSE, targets=c(0)),list(className = 'dt-center', targets = "_all"),list(width = 'autos',targets = 0:3)),
                      deferRender = TRUE,
                      scroller = FALSE
                    ),
                    escape = F,
                    selection = 'none',
      )  %>% DT::formatStyle(colunaNames, cursor = 'pointer')
      
    })
    
    if(context.plot$BINARY)
    {
      atributos.y    <-   atributos.tmp %>% filter(context.plot$FORMAT.Y == R_DATA)
      component.y    <-   tagList(panelTitle(title = 'Eixo Y',
                                             background.color.title = 'white',
                                             title.color = 'black',
                                             border.color = 'lightgray',
                                             children = div(style = 'padding: 10px',
                                                            splitLayout(
                                                              selectInput('comboObjetoY','Objeto',choices = objetos.tmp$NAME_OBJECT,width = '100%'),
                                                              selectInput('comboAtributoY','Atributo',choices = '',width = '100%'),
                                                              cellWidths = c('50%','50%')
                                                            ))),br())
    }
    
    div(
      style = 'padding-left: 15px; padding-right: 15px; padding-bottom: 10px',
      br(),
      component.y,
      panelTitle(title = 'Eixo X',
                 background.color.title = 'white',
                 title.color = 'black',
                 border.color = 'lightgray',
                 children = div(style = 'padding: 10px',
                                splitLayout(
                                  selectInput('comboObjetoX','Objeto',choices = objetos.tmp$NAME_OBJECT,width = '100%'),
                                  selectInput('comboAtributoX','Atributo',choices = '',width = '100%'),
                                  cellWidths = c('50%','50%')
                                ))),
      br(),
      span('Adicionar',style = 'font-size: 16px;'),
      actionButton('btInsertTable','',icon = icon('arrow-down'),width = '100%',style = 'font-size: 18px;'),
      br(),
      div(
        style = 'width: 100%; height: auto; padding: 5px;',
        DT::dataTableOutput('tableDataframe')
      ))
    
  })
  
  obs$add(observeEvent(input$editPressedRow,{
    
    actionWebUser(function(){
      
      tryResetConnection(con,function(coon){
        
        con <<- coon
        
        plot      <<- isolate(plots()) %>% filter(CD_ID_PLOT == input$editPressedRow)
        dataplots <<- selelectDataplots(con,plot)
        
        swiperSlideNext()
        positionReactive(swiperPosition)
        
      },auto.remove = FALSE)
      
    },auto.remove = TRUE)
    
  },ignoreInit = T))
  
  obs$add(observeEvent(input$deletePressedRow,{
    
    plot <- isolate(plots()) %>% filter(CD_ID_PLOT == input$deletePressedRow)
    
    messageAlerta(input,
                  title   = paste0('Todos os processos ligado a esse grafico será removido!'),
                  message = paste0('Deseja realmente excluir o grafico ',plot$TITLE_PLOT,"?"),
                  callback.no = function(){
                    
                  },
                  callback.yes = function(){
                    
                    tryResetConnection(con,function(conn){
                      
                      con <<- conn
                      #remove Database setor
                      DBI::dbExecute(con,paste0('DELETE FROM PLOT WHERE CD_ID_PLOT = ?'),params = plot$CD_ID_PLOT)
                      
                      plots.aux <- selelectAllPlots(con)
                      
                      if(nrow(plots.aux) > 0)
                        plots(plots.aux)
                      else
                      {
                        shinyjs::runjs("Shiny.setInputValue('comboBoxSetor',null);")
                        #destroi todos os events
                        DBI::dbDisconnect(con)
                        obs$destroy()
                        obs2$destroy()
                        removeModal()
                        callback()
                      }
                    })
                    
                    
                  })
    
  },ignoreInit = T))
  
  obs$add(observeEvent(input$btSalvar,{
    
    #update Buttons
    index <- swiperPosition
    
    if(index == 2){

      textTitle     <- toupper(isolate(input$textTitlePlot))
      textEixoY     <- toupper(isolate(input$textEixoY))
      textEixoX     <- toupper(isolate(input$textEixoX))
      textLegend    <- toupper(isolate(input$textLegend))
      binary.status <- FALSE
      
      
      if(tipo.plot$CD_ID_TIPO  == 1 || tipo.plot$CD_ID_TIPO  == 2 || tipo.plot$CD_ID_TIPO  == 3 || tipo.plot$CD_ID_TIPO  == 8){ #scatter and line
        
        binary.status <- TRUE
        
        if(checkifTextEmpty(textTitle) || 
           checkifTextEmpty(textEixoY) ||
           checkifTextEmpty(textEixoX) ||
           checkifTextEmpty(textLegend)){
          
          showNotification("Existe campos que não foram preenchido!", type = "warning")
          
          return()
        }
        
        if(stringr::str_trim(textEixoY) == stringr::str_trim(textEixoX)){
          
          showNotification("O texto do Eixo Y e X não podem ser iguais!", type = "warning")
          
          return()
        }
      }
      else{
        
        binary.status <- FALSE
        
        if(checkifTextEmpty(textTitle) || 
           checkifTextEmpty(textEixoX) ||
           checkifTextEmpty(textLegend)){
          
          showNotification("Existe campos que não foram preenchido!", type = "warning")
          
          return()
        }
        
      }
      
      context.plot <<- list(
        TITLE    = textTitle,
        EIXO.X   = textEixoX,
        EIXO.Y   = textEixoY,
        LEGEND   = textLegend,
        FORMAT.X = tolower(isolate(input$comboEixoX)),
        FORMAT.Y = tolower(isolate(input$comboEixoY)),
        BINARY   = binary.status
      )
      
      actionWebUser(function(){
        
        tryResetConnection(con,function(coon){
          
          setor          <<- setores %>% filter(NAME_SETOR == input$comboBoxSetor)
          objetos.tmp    <<- objetos %>% filter(CD_ID_SETOR %in% setor$CD_ID_SETOR)
          estruturas.tmp <<- estruturas %>% filter(CD_ID_STRUCT %in% objetos.tmp$CD_ID_STRUCT)
          atributos.tmp  <<- selectAllAtributosToPlot(con,estruturas.tmp)
          estruturas.tmp <<- validaEstruturasByPlot(context.plot,estruturas.tmp,atributos.tmp)
          
          if(nrow(estruturas.tmp) == 0){
            
            if(binary.status)
              showNotification(
                paste0("Não Existe estruturas que contem o tipo de dados Y: ",
                       context.plot$FORMAT.Y,' e X: ',context.plot$FORMAT.X),
                type = "warning")
            else
              showNotification(
                paste0("Não Existe estruturas que contem o tipo de dados X: ",
                       context.plot$FORMAT.X),
                type = "warning")
            
            setor          <<- NULL
            objetos.tmp    <<- NULL
            estruturas.tmp <<- NULL
            
          }else{
            
            swiperSlideNext()
            positionReactive(swiperPosition)
            
          }
          
        })
        
      },auto.remove = FALSE)

    }
    else if (index == 3){
      
      if(length(isolate(input$multiTipoObjects)) == 0){
        
        showNotification("Nenhum objeto foi selecionado!", type = "warning")
        return()
      }
      
      swiperSlideNext()
      positionReactive(swiperPosition)
    }
    else if (index == 4){
      
      if(nrow(isolate(datatable())) == 0){
        showNotification("Nenhum dado foi encontrado na tabela dataframe!", type = "warning")
        return()
      }
      
      tryResetConnection(con,function(coon){
        
        con <<- coon
        
        status <- tryTransation(con,{
          
         table <- isolate(datatable())

          #inserir plot
         updateTable(con,'PLOT',paste0('CD_ID_PLOT = ',plot$CD_ID_PLOT),
         list(
            TITLE_PLOT       = context.plot$TITLE,
            TEXT_X_PLOT      = context.plot$EIXO.X,
            TEXT_Y_PLOT      = context.plot$EIXO.Y,
            TEXT_LEGEND_PLOT = context.plot$LEGEND
          ))
          #every dataplot
          for (i in 1:nrow(table)) {
            
            data <- table[i,]
            
            if(data$FLAG)
            {
            updateTable(con,'DATAPLOT',paste0('CD_ID_DATAPLOT = ',data$CD_ID),
             list(
               CD_ID_ATRIBUTO_X  = data$ATRIBUTO.X,
               CD_ID_ATRIBUTO_Y  = ifelse(is.null(data$ATRIBUTO.Y),NA,data$ATRIBUTO.Y),
               CD_ID_OBJECT_X    = data$OBJECT.X,
               CD_ID_OBJECT_Y    = ifelse(is.null(data$OBJECT.Y),NA,data$OBJECT.Y)
             ))

            }else{
              # insert dataplot
              insertTable(con,'DATAPLOT',list(
                CD_ID_ATRIBUTO_X  = data$ATRIBUTO.X,
                CD_ID_ATRIBUTO_Y  = ifelse(is.null(data$ATRIBUTO.Y),NA,data$ATRIBUTO.Y),
                CD_ID_OBJECT_X    = data$OBJECT.X,
                CD_ID_OBJECT_Y    = ifelse(is.null(data$OBJECT.Y),NA,data$OBJECT.Y),
                CD_ID_PLOT        = plot$CD_ID_PLOT
              ))
            }
          }
         
         #remove atributos que não contem mais na tabela
         dataplots.remove <- dataplots %>% filter(!(CD_ID_DATAPLOT %in% table$CD_ID))
         sapply(dataplots.remove$CD_ID_DATAPLOT, function(x)  DBI::dbExecute(con,"DELETE FROM DATAPLOT WHERE CD_ID_DATAPLOT = ?",params = x))

        })
        
        if(status){

         #remove da cache
         systemCache$remove(paste0('dataplotcache',plot$CD_ID_PLOT))  
          
         plots(selelectAllPlots(con))
         positionReactive(1)
         swiperSlideTo(index = 0)  

        }
        else{
          showNotification("Não foi possivel realizar essa operação falha na conexão!", type = "error")
        }
        
      })
      
    }
    
  },ignoreInit = T))
  
  obs$add(observeEvent(input$btSair,{
    
    index <- swiperPosition
    
    if(index == 1){
      
      #destroi todos os events
      DBI::dbDisconnect(con)
      obs$destroy()
      obs2$destroy()
      removeModal()
      callback()
    }
    #Sair
    else if(index == 2){
      
      swiperSlidePrevious()
      positionReactive(swiperPosition)
    }
    else if(index == 3){
      
      swiperSlidePrevious()
      positionReactive(swiperPosition)
    }
    else{
      
      swiperSlidePrevious()
      positionReactive(swiperPosition)
    }
    
    
  },ignoreInit = T))
  
}

validaEstruturasByPlot <- function(context.plot,estruturas.tmp,atributos){
  
  if(context.plot$BINARY){
    
    estruturas.tmp[sapply(1:nrow(estruturas.tmp), function(x){
      
      x <- estruturas.tmp[x,]
      atributos %>% filter(CD_ID_STRUCT == x$CD_ID_STRUCT) %>% filter(context.plot$FORMAT.Y %in% .data$R_DATA & 
                                                                      context.plot$FORMAT.X %in% .data$R_DATA) %>% nrow() > 0
    }),]
    
  }else{
    
    estruturas.tmp[sapply(1:nrow(estruturas.tmp), function(x){
      
      x <- estruturas.tmp[x,]
      atributos %>% filter(CD_ID_STRUCT == x$CD_ID_STRUCT) %>% filter(context.plot$FORMAT.X %in% .data$R_DATA) %>% nrow() > 0
      
    }),]
    
  }
  
}


checkifTextEmpty <- function(text){
  
  stringi::stri_isempty(stringr::str_trim(text))
}

selectAllAtributosToPlot <- function(con,estruturas){
  
  foreach(
    i = 1:nrow(estruturas),
    .combine = rbind,
    .inorder = T
  ) %do%{
    
    struct <- estruturas[i,]
   cbind(selectAllAtributoOfStruct(con,struct),CD_ID_STRUCT = struct$CD_ID_STRUCT)
    
  }
  
}


insertTablePlot <- function(table,context.plot,objetos.tmp,atributos.tmp,nameObject.y,nameObject.x,nameAtriburo.y,nameAtriburo.x){
  
  x <- NULL
  
  if(context.plot$BINARY){
    
    object.y   <- objetos.tmp %>% filter(NAME_OBJECT == nameObject.y)
    object.x   <- objetos.tmp %>% filter(NAME_OBJECT == nameObject.x)
    atributo.y <- atributos.tmp %>% filter(CD_ID_STRUCT == object.y$CD_ID_STRUCT) %>% filter(NAME_ATRIBUTO == nameAtriburo.y)
    atributo.x <- atributos.tmp %>% filter(CD_ID_STRUCT == object.x$CD_ID_STRUCT) %>% filter(NAME_ATRIBUTO == nameAtriburo.x)
    
    x <- as.data.frame(matrix(nrow = 1,ncol = 3))
    colnames(x) <- c(context.plot$EIXO.Y,context.plot$EIXO.X,"LEGENDA")
    x[context.plot$EIXO.Y] <- unique(atributo.y$NAME_ATRIBUTO)
    x[context.plot$EIXO.X] <- unique(atributo.x$NAME_ATRIBUTO)
    x["LEGENDA"] <- {
      
      if(object.y$NAME_OBJECT == object.x$NAME_OBJECT){
        object.y$NAME_OBJECT
      }else{
        paste0(object.y$NAME_OBJECT,' - ',object.x$NAME_OBJECT)
        
      }
      
    }
    
    x$OBJECT.Y   <- object.y$CD_ID_OBJECT
    x$OBJECT.X   <- object.x$CD_ID_OBJECT
    x$ATRIBUTO.Y <- unique(atributo.y$CD_ID_ATRIBUTO)
    x$ATRIBUTO.X <- unique(atributo.x$CD_ID_ATRIBUTO)
    x$FLAG       <- FALSE
    x$CD_ID      <- 0

    if(nrow(table) > 0)
    {
      status <- sapply(1:nrow(table), function(i){
        
        data <- table[i,]
        
        return(all(data[context.plot$EIXO.Y] ==  x[context.plot$EIXO.Y],
                   data[context.plot$EIXO.X] ==  x[context.plot$EIXO.X],
                   data["LEGENDA"] ==  x["LEGENDA"]))
        
      })
      
      if(status)
        x <- NULL
    }
    
  }else{
    
    object.x   <- objetos.tmp %>% filter(NAME_OBJECT == nameObject.x)
    atributo.x <- atributos.tmp %>% filter(CD_ID_STRUCT == object.x$CD_ID_STRUCT) %>% filter(NAME_ATRIBUTO == nameAtriburo.x)
    
    x <- as.data.frame(matrix(nrow = 1,ncol = 2))
    colnames(x) <- c(context.plot$EIXO.X,"LEGENDA")
    x[context.plot$EIXO.X] <- unique(atributo.x$NAME_ATRIBUTO)
    x["LEGENDA"] <- object.x$NAME_OBJECT
    x$OBJECT.X   <- object.x$CD_ID_OBJECT
    x$ATRIBUTO.X <- unique(atributo.x$CD_ID_ATRIBUTO)
    x$FLAG       <- FALSE
    x$CD_ID      <- 0

    if(nrow(table) > 0)
    {
      status <- sapply(1:nrow(table), function(i){
        
        data <- table[i,]
        
        return(all(data[context.plot$EIXO.X] ==  x[context.plot$EIXO.X], data["LEGENDA"] ==  x["LEGENDA"]))
        
      })
      
      if(status)
        x <- NULL
    }
    
    
  }

  return(x)
}

insertTablePlotInit <- function(table,context.plot,objetos.tmp,atributos.tmp,dataplot){
  
  x <- NULL
  
  if(context.plot$BINARY){
    
    object.y <- objetos.tmp %>% filter(CD_ID_OBJECT == dataplot$CD_ID_OBJECT_Y)
    object.x <- objetos.tmp %>% filter(CD_ID_OBJECT == dataplot$CD_ID_OBJECT_X)

    if(nrow(object.x) == 0 || nrow(object.y) == 0) return(NULL)
    
    atributo.y <- atributos.tmp %>% filter(CD_ID_STRUCT == object.y$CD_ID_STRUCT) %>% filter(CD_ID_ATRIBUTO == dataplot$CD_ID_ATRIBUTO_Y)
    atributo.x <- atributos.tmp %>% filter(CD_ID_STRUCT == object.x$CD_ID_STRUCT) %>% filter(CD_ID_ATRIBUTO == dataplot$CD_ID_ATRIBUTO_X)
    
    x <- as.data.frame(matrix(nrow = 1,ncol = 3))
    colnames(x) <- c(context.plot$EIXO.Y,context.plot$EIXO.X,"LEGENDA")
    x[context.plot$EIXO.Y] <- unique(atributo.y$NAME_ATRIBUTO)
    x[context.plot$EIXO.X] <- unique(atributo.x$NAME_ATRIBUTO)
    x["LEGENDA"] <- {
      
      if(object.y$NAME_OBJECT == object.x$NAME_OBJECT){
        object.y$NAME_OBJECT
      }else{
        paste0(object.y$NAME_OBJECT,' - ',object.x$NAME_OBJECT)
        
      }
      
    }
    
    x$OBJECT.Y   <- object.y$CD_ID_OBJECT
    x$OBJECT.X   <- object.x$CD_ID_OBJECT
    x$ATRIBUTO.Y <- unique(atributo.y$CD_ID_ATRIBUTO)
    x$ATRIBUTO.X <- unique(atributo.x$CD_ID_ATRIBUTO)
    x$FLAG       <- TRUE
    x$CD_ID      <- dataplot$CD_ID_DATAPLOT
    
    if(nrow(table) > 0)
    {
      status <- sapply(1:nrow(table), function(i){
        
        data <- table[i,]
        
        return(all(data[context.plot$EIXO.Y] ==  x[context.plot$EIXO.Y],
                   data[context.plot$EIXO.X] ==  x[context.plot$EIXO.X],
                   data["LEGENDA"] ==  x["LEGENDA"]))
        
      })
      
      if(status)
        x <- NULL
    }
    
  }else{
    
    object.x   <- objetos.tmp %>% filter(CD_ID_OBJECT == dataplot$CD_ID_OBJECT_X)
    
    if(nrow(object.x) == 0) return(NULL)
    
    atributo.x <- atributos.tmp %>% filter(CD_ID_STRUCT == object.x$CD_ID_STRUCT) %>% filter(CD_ID_ATRIBUTO == dataplot$CD_ID_ATRIBUTO_X)
    
    x <- as.data.frame(matrix(nrow = 1,ncol = 2))
    colnames(x) <- c(context.plot$EIXO.X,"LEGENDA")
    x[context.plot$EIXO.X] <- unique(atributo.x$NAME_ATRIBUTO)
    x["LEGENDA"] <- object.x$NAME_OBJECT
    x$OBJECT.X   <- object.x$CD_ID_OBJECT
    x$ATRIBUTO.X <- unique(atributo.x$CD_ID_ATRIBUTO)
    x$FLAG       <- FALSE
    x$CD_ID      <- 0
    x$FLAG       <- TRUE
    x$CD_ID      <- dataplot$CD_ID_DATAPLOT
    
    if(nrow(table) > 0)
    {
      status <- sapply(1:nrow(table), function(i){
        
        data <- table[i,]
        
        return(all(data[context.plot$EIXO.X] ==  x[context.plot$EIXO.X], data["LEGENDA"] ==  x["LEGENDA"]))
        
      })
      
      if(status)
        x <- NULL
    }
    
    
  }
  
  return(x)
}

uiConfigTools <- function(con,input,output,setores,callback){
  
  source('model/SmartObserve.R',local = T)
  obs             <- newObserve()
  obs2            <- newObserve()
  obs3            <- newObserve()
  sliderPosition  <- reactiveVal(1)
  valueMapDraw    <- reactiveValues()
  updateRegistro  <- reactiveVal(NULL)
  setor           <- NULL
  plots           <- NULL
  tools.plots     <- NULL
  tools.datas     <- reactiveVal(NULL)
  toolEdit        <- NULL
  flag            <- 0
  resetpanel      <- reactiveVal(NULL)
  imagens         <- list.files('www/image/icone.map/')
  
  id <- 'dialogObj'
  cssStyle <- list()
  cssStyle[[paste0(' #parent',id,' .modal-dialog')]]  <- paste0('height: 655px !important;')
  cssStyle[[paste0(' #parent',id,' .modal-content')]] <- paste0('width: 100% !important; height: 100% !important;')
  cssStyle[[paste0(' #parent',id,' .modal-body')]]    <- paste0('width: 100% !important; height: calc(100% - 57px - 65px) !important; overflow-y: hidden;')
  
  #Modal para Dialog
  showModal(div(
    id = paste0('parent', id),
    style = paste0("height: 90%;"),
    shinyjs::inlineCSS(cssStyle),
    dialogModal(
      title = dialogTitleClose('Ferramentas',function(){
        
        obs$destroy()
        obs2$destroy()
        obs3$destroy()
        removeModal()
        callback()
        
      }),
      size = 'l',
      swiper(id = 'swiperMain',
             parent.style = 'height: 100%; width: 100%;',
             width = '100%',
             height = '100%',
             swiperSlide(
               style = 'height: 100%; width: 100%; overflow-y: auto; overflow-x: hidden; padding: 5px;',
               uiOutput('slider1')
             ),
             swiperSlide(
               style = 'height: 100%; width: 100%; padding: 5px; overflow-y: auto; overflow-x: hidden;',
               uiOutput('slider2')
             )
      ),
      footer = uiOutput('uiFooter')
    )
  ))
  
  output$uiFooter <- renderUI({
    
    current <-  sliderPosition()
    
    if(current == 1){
      tagList(actionButton('btActionCancel', label = "Sair"))
    }
    else{
      tagList(actionButton('btActionCancel', label = "Voltar"),actionButton('btActionUpdate', label = "Salvar"))
    }
    
  })
  
  createTable <- function(dataset){
    
    if(nrow(dataset) == 0) {
      
      x <- as.data.frame(matrix(ncol = 5,nrow = 0))
      colnames(x) <- c("LINHA","NOME","ATIVAR","EDITAR","REMOVER")
      x <-  DT::datatable({x}, 
                          class = 'cell-border stripe',
                          extensions = 'Scroller',
                          options = list(
                            language = list(url = 'js/table/translate.json'),
                            dom = 't',
                            bSort=FALSE,
                            columnDefs = list(list(visible=FALSE, targets=c(0)),list(className = 'dt-center', targets = "_all"),list(width = 'auto',targets = "_all")),
                            deferRender = TRUE,
                            scroller = FALSE,
                            fixedHeader = TRUE,
                            scrollX = TRUE,
                            scrollY = 'auto'
                          ),
                          escape = F,
                          selection = 'none',
      )  %>% DT::formatStyle(colnames(result), cursor = 'pointer')
      
      return(x)
    }
    
    dataset$LINHA <- 1:nrow(dataset)
    
    DT::datatable({
      
      dataset %>% 
        mutate(
          NOME   = NAME_PT,
          ATIVAR = sapply(1:nrow(dataset),function(i) {
            
            x    <- dataset[i,]
            json <- paste0('{"tool":"',x$CD_ID_PT,'","status":document.getElementById("',paste0("checkBoxActiveplot",x$CD_ID_PT),'").checked}')  
            
            as.character( div(
              style = "width: auto; height: auto;",
              prettyToggle(
                inputId = paste0("checkBoxActiveplot",x$CD_ID_PT),
                label_on = "Sim",
                label_off = "Não", 
                outline = TRUE,
                plain = TRUE,
                value = x$FLAG_ACTIVE_PT,
                icon_on = icon("thumbs-up"),
                icon_off = icon("thumbs-down"),
                bigger = T,
                width = 'auto'
              ),
              onclick = paste0('Shiny.setInputValue(\"editPressedStatus\",',json,',{priority: "event"})')
            ))
            
          }),
          EDITAR = sapply(CD_ID_PT, function (x) {
            
            as.character(
              actionButton(
                paste0('btEdit'),
                label = '',
                icon = icon('eye'),
                onclick = paste0('Shiny.setInputValue(\"editPressedRow\","',x,'",{priority: "event"})'),
                #style = 'background-color: transparent; color: lightblue; border-solid: none;'
              )
            )
          }),
          REMOVER = sapply(CD_ID_PT, function(x){
            
            as.character(
              actionButton(
                paste0('btRemove'),
                label = '',
                icon = icon('trash'),
                onclick = paste0('Shiny.setInputValue(\"deletePressedRow\","',x,'",{priority: "event"})'),
                #style = 'background-color: transparent; color: lightblue; border-solid: none;'
              )
            )
            
          })
          
        )%>% select(LINHA,NOME,ATIVAR,EDITAR,REMOVER)
    }, 
    class = 'cell-border stripe',
    extensions = 'Scroller',
    options = list(
      language = list(url = 'js/table/translate.json'),
      dom = 't',
      bSort=FALSE,
      columnDefs = list(list(visible=FALSE, targets=c(0)),list(className = 'dt-center', targets = "_all"),list(width = 'auto',targets = "_all")),
      deferRender = TRUE,
      scroller = FALSE,
      fixedHeader = TRUE,
      scrollX = TRUE,
      scrollY = 'auto'
    ),
    escape = F,
    selection = 'none',
    )  %>% DT::formatStyle(colnames(result), cursor = 'pointer')
    
    
  }

  output$slider1 <- renderUI({
    
    output$panelMap <- renderUI({
      
      req(input$comboGrafico)
      
      plot.aux  <- plots %>% filter(TITLE_PLOT == input$comboGrafico)
      tool.plot <- tools.plots %>% filter(CD_ID_TIPO == plot.aux$CD_ID_TIPO) 
      
      obs2$clear()
      
      #Tipo de plot Map
      if(plot.aux$CD_ID_TIPO == 8){
        
        obs2$add(observeEvent(input$btControl1,{
          
          flag <<- 1
          swiperSlideNext()
          sliderPosition(swiperPosition)
          
        },ignoreInit = T,ignoreNULL = T))
        
        
        obs2$add(observeEvent(input$btControl2,{
          
          flag <<- 2
          swiperSlideNext()
          sliderPosition(swiperPosition)
          
        },ignoreInit = T,ignoreNULL = T))
        
        tagList(
          actionButton('btControl1',label = 'Adicionar Cerca Virtual',icon = icon('draw-polygon'),width = '100%'),
          div(style = 'height: 5px;'),
          actionButton('btControl2',label  = 'Adicionar Ponto de marcar',icon = icon('map-marker-alt'),width = '100%')
        )
      }
      else{
        
        obs2$add(observeEvent(input$btControl1,{
          
          flag <<-  switch (plot.aux$CD_ID_TIPO,
                            '1' = 3,
                            '2' = 5,
                            '3' = 7,
                            '4' = 9,
                            '5' = 11,
                            '6' = 13,
                            '7' = 15
          )
          
          swiperSlideNext()
          sliderPosition(swiperPosition)
          
        },ignoreInit = T,ignoreNULL = T))
        
        
        obs2$add(observeEvent(input$btControl2,{
          
          flag <<-  switch (plot.aux$CD_ID_TIPO,
                            '1' = 4,
                            '2' = 6,
                            '3' = 8,
                            '4' = 10,
                            '5' = 12,
                            '6' = 14,
                            '7' = 16
          )
          
          swiperSlideNext()
          sliderPosition(swiperPosition)
          
        },ignoreInit = T,ignoreNULL = T))
        
        tagList(
          actionButton('btControl1',label = 'Adicionar linha vertical',width = '100%'),
          div(style = 'height: 5px;'),
          actionButton('btControl2',label  = 'Adicionar linha horizontal',width = '100%')
        )
        
      }
      
      
    })
    
    obs$add(observeEvent(c(input$comboSetor,updateRegistro()),{
      
      tryResetConnection(con,function(coon){
        
        con <<- coon
        
        #find setor
        setor        <<- setores %>% filter(NAME_SETOR == input$comboSetor)
        comboGrafico <- isolate(input$comboGrafico)
        
        #load all plots
        plots       <<- selelectPlotDao(con,setor)
        tools.plots <<- foreach(index = 1:nrow(plots),.combine = 'rbind') %do%{
          x <- plots[index,]
          selectToolPlotDao(con,x)
        }
        
        tools.datas(foreach(index = 1:nrow(plots),.combine = 'rbind') %do%{
          x <- plots[index,]
          selectToolPlotDataDao(con,x)
        })
        
        if(stringi::stri_isempty(comboGrafico))
          updateSelectInput(getDefaultReactiveDomain(),inputId = 'comboGrafico',choices = plots$TITLE_PLOT)
        else
          updateSelectInput(getDefaultReactiveDomain(),inputId = 'comboGrafico',choices = plots$TITLE_PLOT,selected = comboGrafico)
        
      })
      
      
    },ignoreInit = F))
    
    output$panelTools <- renderUI({
      
      req(input$comboGrafico)
      
      datasets  <- tools.datas()
      
      plot.aux  <- plots %>% filter(TITLE_PLOT == input$comboGrafico)
      tool.plot <- tools.plots %>% filter(CD_ID_TIPO == plot.aux$CD_ID_TIPO) 
      
      
      inputs    <- apply(tool.plot,1, function(x){
        
        output[[paste0('tabletool_',x["CD_ID_PTP"])]] <- DT::renderDataTable({
          
          value <- as.integer(x["CD_ID_PTP"])
          createTable(datasets %>% filter(CD_ID_PLOT == plot.aux$CD_ID_PLOT) %>% filter(CD_ID_PTP == value))
        })
        
        tagList(
          panelTitle(title = x["DESCRICAO_PTP"],
                     background.color.title = 'white',
                     title.color = 'black',
                     height       = "100%",
                     border.color = 'lightgray',
                     children =  div(style = 'padding: 10px;',
                                     DT::dataTableOutput(paste0('tabletool_',x["CD_ID_PTP"]))
                                     
                     )),
          br())
        
      })
      
      tagList(inputs)
      
    })
    
    #design
    div(fluidRow(
      column(6,
             selectInput(inputId = 'comboSetor',label = 'Setor',choices = setores$NAME_SETOR),
             selectInput(inputId = 'comboGrafico',label = 'Grafico',choices = ""),
             style = 'height: 150px;'
      ),
      column(6,
             panelTitle(title = "Controle",
                        background.color.title = 'white',
                        title.color = 'black',
                        height       = "100%",
                        border.color = 'lightgray',
                        children =  uiOutput('panelMap',style = 'padding: 10px;')),
             style = 'height: 150px;'
             
      )
    ),
    br(),
    uiOutput('panelTools')
    )
    
  })
  
  output$slider2 <- renderUI({
    
    req(sliderPosition() == 2)
    resetpanel()
    
    plot.aux  <- plots %>% filter(TITLE_PLOT == isolate(input$comboGrafico))
    
    #Tipo de plot Map
    if(plot.aux$CD_ID_TIPO == 8){
      
      #fix the polygon to start another
      obs3$clear()
      
      latlongs     <- reactiveValues()   #temporary to hold coords
      latlongs$df2 <- data.frame(Longitude = numeric(0), Latitude = numeric(0))
      
      #########
      #empty reactive spdf
      valueMapDraw$drawnPoly <- SpatialPolygonsDataFrame(SpatialPolygons(list()), data=data.frame (notes=character(0), stringsAsFactors = F))
      
      if(!is.null(toolEdit)){
        
        if(flag == 1)
        {
          isolate({
            p <- sf::st_as_sfc(toolEdit$SCRIPT_PT)
            sf::st_coordinates(p)
            
            poly    <- Polygon(sf::st_coordinates(p)[,1:2])
            polys   <- Polygons(list(poly),ID = 1)
            spPolys <- SpatialPolygons(list(polys))
            
            #
            valueMapDraw$drawnPoly <- rbind(valueMapDraw$drawnPoly,SpatialPolygonsDataFrame(spPolys, 
                                                                                            data=data.frame(notes=NA, row.names=
                                                                                                              row.names(spPolys))))
          })
          
        }else{
          
          p <- jsonlite::fromJSON(toolEdit$SCRIPT_PT)
          isolate({
            
            poly    <- Polygon(p$coordenadas)
            polys   <- Polygons(list(poly),ID = 1)
            spPolys <- SpatialPolygons(list(polys))
            
            #
            valueMapDraw$drawnPoly <- rbind(valueMapDraw$drawnPoly,SpatialPolygonsDataFrame(spPolys, 
                                                                                            data=data.frame(notes=NA, row.names=
                                                                                                              row.names(spPolys))))
          })
        }
      }
      
      #mostrar cercas virtuais ja existente
      obs3$add(observeEvent(input$checkBoxShowCerca,{
        
        status   <- input$checkBoxShowCerca
        proxy    <- leaflet::leafletProxy('mapDesign')
        
        if(status){
          
          polignos <- isolate(tools.datas()) %>% filter(CD_ID_PLOT == plot.aux$CD_ID_PLOT) %>% filter(CD_ID_PTP == flag)
          n <- nrow(polignos)
          
          if(n > 0)
          {
            
            for (i in 1:n) {
              
              x <- polignos[i,]
              
              if(!is.null(toolEdit)){
                
                if(x$SCRIPT_PT == toolEdit$SCRIPT_PT )
                  next
              }
              
              if(flag == 1){
                
                p <- sf::st_as_sfc(x$SCRIPT_PT)
                proxy %>%
                  leaflet::addPolygons(
                    group = 'virtual',
                    data = p,
                    color = 'blue',
                    fillOpacity = .5,
                    popup = paste0(
                      "<b>Cerca virtual: </b>", x$NAME_PT,"<br>"),
                    labelOptions = labelOptions(
                      textOnly = F,
                      style = list("box-shadow" = "3px 3px rgba(0,0,0,0.25)", "border-color" = "rgba(0,0,0,0.5)"))
                  )
              }else{
                
                p <- jsonlite::fromJSON(x$SCRIPT_PT)
                
                proxy %>%
                  leaflet::addMarkers(
                    group = 'virtual',
                    data =  p$coordenadas,
                    icon = makeIcon(iconUrl = paste0('image/icone.map/', p$icone)),
                    popup = paste0(
                      "<b>Marca: </b>", x$NAME_PT,"<br>"),
                    labelOptions = labelOptions(
                      textOnly = F,
                      style = list("box-shadow" = "3px 3px rgba(0,0,0,0.25)", "border-color" = "rgba(0,0,0,0.5)"))
                  )
              }
            }
          }
          
          
        }else{
          proxy %>% leaflet::clearGroup(group = 'virtual')
        }
        
        
      },ignoreInit = T,ignoreNULL = T))
      
      #fix the polygon to start another
      obs3$add(observeEvent(input$mapDesign_draw_new_feature, {
        
        coor      <-unlist(input$mapDesign_draw_new_feature$geometry$coordinates)
        
        Longitude <-coor[seq(1,length(coor), 2)] 
        
        Latitude  <-coor[seq(2,length(coor), 2)]
        
        isolate(latlongs$df2 <- rbind(latlongs$df2, cbind(Longitude, Latitude)))
        
        poly    <- Polygon(cbind(latlongs$df2$Longitude, latlongs$df2$Latitude))
        polys   <- Polygons(list(poly),    ID=input$mapDesign_draw_new_feature$properties$`_leaflet_id`)
        spPolys <- SpatialPolygons(list(polys))
        
        
        #
        valueMapDraw$drawnPoly <- rbind(valueMapDraw$drawnPoly,SpatialPolygonsDataFrame(spPolys, 
                                                                                        data=data.frame(notes=NA, row.names=
                                                                                                          row.names(spPolys))))
        
        latlongs$df2 <- data.frame(Longitude = numeric(0), Latitude = numeric(0))   #clear df
        
      },ignoreInit = T,ignoreNULL = T))
      
      ########################
      ### edit polygons / delete polygons
      obs3$add(observeEvent(input$mapDesign_draw_edited_features, {
        
        f <- input$mapDesign_draw_edited_features
        
        if(length(f$features) == 0) return()
        
        if("features.properties.layerId" %in% names(unlist(f))){
          f$features[[1]]$properties['_leaflet_id'] <- 1
        }
        
        coordy     <- lapply(f$features, function(x){unlist(x$geometry$coordinates)})
        
        Longitudes <- lapply(coordy, function(coor) {coor[seq(1,length(coor), 2)] })
        
        Latitudes  <- lapply(coordy, function(coor) { coor[seq(2,length(coor), 2)] })
        
        polys<-list()
        for (i in 1:length(Longitudes)){
          polys[[i]]<- Polygons(
            list(Polygon(cbind(Longitudes[[i]], Latitudes[[i]]))), ID=f$features[[i]]$properties['_leaflet_id']
          )}
        
        spPolys <- SpatialPolygons(polys)
        
        SPDF    <- SpatialPolygonsDataFrame(spPolys, 
                                            data=data.frame(notes=valueMapDraw$drawnPoly$notes[row.names(valueMapDraw$drawnPoly) %in% row.names(spPolys)], row.names=row.names(spPolys)))
        
        valueMapDraw$drawnPoly <- valueMapDraw$drawnPoly[!row.names(valueMapDraw$drawnPoly) %in% row.names(SPDF),]
        valueMapDraw$drawnPoly <- rbind(valueMapDraw$drawnPoly, SPDF)
        
      },ignoreInit = T,ignoreNULL = T))
      
      obs3$add(observeEvent(input$mapDesign_draw_deleted_features, { 
        
        f   <- input$mapDesign_draw_deleted_features
        
        ids <- sapply(f$features, function(x){unlist(x$properties['_leaflet_id'])})
        
        valueMapDraw$drawnPoly <- valueMapDraw$drawnPoly[!row.names(valueMapDraw$drawnPoly) %in% ids,]
        
      },ignoreInit = T,ignoreNULL = T))
      
      output$mapDesign <- renderLeaflet({
        
        #translate map
        shinyjs::delay(1000,{translateMap()})
        
        map <- leaflet("mapDesign")
        map <- map %>% addTiles()
        
        if(!is.null(toolEdit)){
          
          map <- map %>% addDrawToolbar(
            targetGroup = "drawnPoly", 
            rectangleOptions = F, 
            polylineOptions = F, 
            markerOptions = F, 
            circleMarkerOptions = F,
            editOptions    = editToolbarOptions(selectedPathOptions = selectedPathOptions()), 
            circleOptions  = F,
            polygonOptions = F)
          
          
          if(flag == 1)
          {
            p   <- sf::st_as_sfc(toolEdit$SCRIPT_PT)
            map %>% addPolygons(data = p,color = 'blue',weight = 2,fillColor = 'red',fillOpacity = .5,group = c("drawnPoly"),layerId = 1)
          }
          else{
            p <- jsonlite::fromJSON(toolEdit$SCRIPT_PT)
            map %>% addMarkers(data = p$coordenadas,group = c("drawnPoly"),layerId = 1)
          }
          
          
        }else{
          
          map <- map %>% addDrawToolbar(
            targetGroup = "drawnPoly", 
            rectangleOptions = {
              
              if(flag == 1){
                drawRectangleOptions(showArea=TRUE, repeatMode=F  , shapeOptions=drawShapeOptions( fillColor="red",clickable = TRUE))
              }
              else{
                F
              }
            }, 
            polylineOptions = F, 
            markerOptions = {
              
              if(flag == 2){
                drawMarkerOptions() 
              }
              else{
                F
              }
            }, 
            circleMarkerOptions = F,
            editOptions   = editToolbarOptions(selectedPathOptions = selectedPathOptions(),remove = is.null(toolEdit)), 
            circleOptions = F,
            polygonOptions= {
              
              if(flag == 1){
                drawPolygonOptions(showArea=TRUE, repeatMode=F  , shapeOptions=drawShapeOptions( fillColor="red",clickable = TRUE))
              }
              else{
                F
              }
              
            })
          
          map
        }
        
      })
      
      if(flag == 1){
        div(
          shinyjs::inlineCSS("#textName {text-transform: uppercase;}"),
          textInput('textName','Cerca Virtual',placeholder = 'Digite o nome da cerca virtual',width = '100%',value = ifelse(is.null(toolEdit),'',toolEdit$NAME_PT)),
          div(
            leafletOutput("mapDesign"),
            absolutePanel(top = 320, left = 20,fixed = F,
                          style = 'width: auto;',
                          prettySwitch(
                            inputId = "checkBoxShowCerca",
                            label  = "Virtual", 
                            status = "success",
                            value  = F,
                            fill   = TRUE,
                            width = 'auto'
                          )
                          
            ))
        )
      }else{
        
        sliderValue <- 1
        icone <- 'default.png'
        
        if(!is.null(toolEdit)){
          p <- jsonlite::fromJSON(toolEdit$SCRIPT_PT)
          icone <- p$icone
        }
        
        div(
          fluidRow(
            column(6,
                   shinyjs::inlineCSS("#textName {text-transform: uppercase;}"),
                   textInput('textName','Marca de ponto',placeholder = 'Digite o nome da marca de ponto',width = '100%',value = ifelse(is.null(toolEdit),'',toolEdit$NAME_PT))),
            column(6,selectInput('comboImage','Imagem',choices = imagens,selected = icone))
          ),
          div(
            leafletOutput("mapDesign"),
            absolutePanel(top = 320, left = 20,fixed = F,
                          style = 'width: auto;',
                          prettySwitch(
                            inputId = "checkBoxShowCerca",
                            label  = "Virtual", 
                            status = "success",
                            value  = F,
                            fill   = TRUE,
                            width = 'auto'
                          )
                          
            ))
        )
      }
      
    }else if(any(flag %in% seq(from = 3,to = 15,by = 2))){ # vertical line
      
      sliderValue <- 1
      valor       <- 0
      tipo        <- 'solid'
      color       <- '#FF0000'
      
      if(!is.null(toolEdit)){
        
        p     <- jsonlite::fromJSON(toolEdit$SCRIPT_PT)
        
        sliderValue <- p$size
        valor       <- p$value
        tipo        <- p$tipo
        color       <- p$color
      }
      
      fluidRow(
        column(6,       
               shinyjs::inlineCSS("#textName {text-transform: uppercase;}"),
               textInput('textName','Linha',placeholder = 'Digite o nome da linha',width = '100%',value = ifelse(is.null(toolEdit),'',toolEdit$NAME_PT))),
        column(6,sliderInput('sliderSize',label = 'Tamanho',min = 1,max = 5,step = 0.1,value = sliderValue)),
        column(4,numericInput('textValue',label = 'Intercessão X',value = valor,width = '100%')),
        column(4,
               colourpicker::colourInput(
                 inputId = "comboColor", 
                 label = 'Cor',
                 value = color,
                 returnName = F,
                 palette = "limited",
                 closeOnClick = TRUE)
        ),
        column(4,
               selectInput(
                 'comboLineType',
                 'Tipo',
                 choices = c(
                   "blank",
                   "solid",
                   "dashed",
                   "dotted",
                   "dotdash",
                   "longdash",
                   "twodash",
                   "1F",
                   "F1",
                   "4C88C488",
                   "12345678"
                 ),
                 selected = tipo
               )
        )
      )
      
    }
    else if(any(flag %in% seq(from = 4,to = 16,by = 2))){ # horizontal line
      
      sliderValue <- 1
      valor       <- 0
      tipo        <- 'solid'
      color       <- '#FF0000'
      
      if(!is.null(toolEdit)){
        
        p     <- jsonlite::fromJSON(toolEdit$SCRIPT_PT)
        
        sliderValue <- p$size
        valor       <- p$value
        tipo        <- p$tipo
        color       <- p$color
      }
      
      fluidRow(
        column(6,       
               shinyjs::inlineCSS("#textName {text-transform: uppercase;}"),
               textInput('textName','Linha',placeholder = 'Digite o nome da linha',width = '100%',value = ifelse(is.null(toolEdit),'',toolEdit$NAME_PT))),
        column(6,sliderInput('sliderSize',label = 'Tamanho',min = 1,max = 5,step = 0.1,value = sliderValue)),
        column(4,numericInput('textValue',label = 'Intercessão Y',value = valor,width = '100%')),
        column(4,
               colourpicker::colourInput(
                 inputId = "comboColor", 
                 label = 'Cor',
                 value = color,
                 returnName = F,
                 palette = "limited",
                 closeOnClick = TRUE)
        ),
        column(4,
               selectInput(
                 'comboLineType',
                 'Tipo',
                 choices = c(
                   "blank",
                   "solid",
                   "dashed",
                   "dotted",
                   "dotdash",
                   "longdash",
                   "twodash",
                   "1F",
                   "F1",
                   "4C88C488",
                   "12345678"
                 ),
                 selected = tipo
               )
        )
      )
      
    }
    
    
  })
  
  obs$add(observeEvent(input$editPressedStatus,{
    
    obj    <- input$editPressedStatus
    tool   <- isolate(tools.datas()) %>% filter(CD_ID_PT == obj$tool)
    
    tryResetConnection(con,function(conn){
      
      con <<- conn
      
      updateTable(con,"PLOT_TOOLS",paste0("CD_ID_PT = ",tool$CD_ID_PT),list(FLAG_ACTIVE_PT = as.integer(obj$status)))
    })
    
  },ignoreInit = T))
  
  obs$add(observeEvent(input$editPressedRow,{
    
    obj      <- input$editPressedRow
    tool     <- isolate(tools.datas()) %>% filter(CD_ID_PT == obj)
    flag     <<- tool$CD_ID_PTP
    toolEdit <<- tool
    
    #next page
    swiperSlideNext()
    sliderPosition(swiperPosition)
    
  },ignoreInit = T))
  
  obs$add(observeEvent(input$deletePressedRow,{
    
    obj      <- input$deletePressedRow
    tool     <- isolate(tools.datas()) %>% filter(CD_ID_PT == obj)
    
    messageAlerta(input,
                  title   = paste0('Todos os processos ligado a essa ferramenta será removido'),
                  message = paste0('Deseja realmente excluir a ferramenta ',tool$NAME_PT,"?"),
                  callback.no = function(){
                    
                  },
                  callback.yes = function(){
                    
                    tryResetConnection(con,function(conn){
                      
                      con <<- conn
                      DBI::dbExecute(con,"DELETE FROM PLOT_TOOLS WHERE CD_ID_PT = ?",params = list(tool$CD_ID_PT))
                      
                      updateRegistro(Sys.time())
                    })
                    
                  })
    
  },ignoreInit = T))
  
  
  obs$add(observeEvent(input$btActionUpdate,{
    
    current   <- swiperPosition
    plot.aux  <- plots %>% filter(TITLE_PLOT == isolate(input$comboGrafico))
    
    tryResetConnection(con,function(conn){
      
      con <<- conn
      
      #Nome
      nome <- toupper(isolate(input$textName))
      
      #Tipo de plot Map
      if(flag == 1){
        
        if(stringi::stri_isempty(stringr::str_trim(nome))){
          
          showNotification("O nome da cerca virtual esta vazia!", type = "warning")
          return()
        }
        
        if (!is.null(toolEdit)){
          
          if(DBI::dbGetQuery(con,
                             'SELECT COUNT(*) AS STATUS 
                                 FROM plot_tools
                                 WHERE CD_ID_PLOT = ?
                                 AND CD_ID_PTP    = ?
                                 AND NAME_PT      = ?
                                 AND CD_ID_PT    != ?
                                 ',params = list(plot.aux$CD_ID_PLOT,flag,nome,toolEdit$CD_ID_PT)) > 0){
            
            showNotification("O nome da cerca virtual já existe nesse mapa", type = "warning")
            return()
          }
          
        }
        else if(DBI::dbGetQuery(con,
                                'SELECT COUNT(*) AS STATUS 
                                 FROM plot_tools
                                 WHERE CD_ID_PLOT = ?
                                 AND CD_ID_PTP    = ?
                                 AND NAME_PT      = ?',params = list(plot.aux$CD_ID_PLOT,flag,nome)) > 0){
          
          showNotification("O nome da cerca virtual já existe nesse mapa", type = "warning")
          return()
        }
        
        cerca.virtual <- sf::st_union(sf::st_as_sfc(valueMapDraw$drawnPoly),by_feature = F)
        cerca.virtual <- sf::st_as_text(cerca.virtual)
        
        if (is.null(toolEdit)){
          
          insertTable(con,"PLOT_TOOLS",list(
            NAME_PT      = nome,
            SCRIPT_PT    = cerca.virtual,
            CD_ID_PTP    = flag,
            CD_ID_PLOT   = plot.aux$CD_ID_PLOT
          ))
          
          dialogConfirm(
            title = 'Cerva virtual criado com suceso!',
            text = 'Deseja criar novamente uma nova cerca?',
            callback = function(status) {
              
              if(!status){
                updateRegistro(Sys.time())
                flag <<- 0
                swiperSlidePrevious()
                sliderPosition(swiperPosition)
              }
              else{
                resetpanel(Sys.time())
              }
              
            })
          
        }else{
          
          DBI::dbExecute(con,"UPDATE PLOT_TOOLS SET NAME_PT = ?,SCRIPT_PT = ? WHERE CD_ID_PT = ?",params = list(nome,cerca.virtual,toolEdit$CD_ID_PT))
          
          updateRegistro(Sys.time())
          toolEdit <<- NULL
          flag     <<- 0
          swiperSlidePrevious()
          sliderPosition(swiperPosition)
          
          
        }
        
      }else if(flag == 2){ # mapa marker point
        
        
        if(stringi::stri_isempty(stringr::str_trim(nome))){
          
          showNotification("O nome da marca do ponto esta vazia!", type = "warning")
          return()
        }
        
        if (!is.null(toolEdit)){
          
          if(DBI::dbGetQuery(con,
                             'SELECT COUNT(*) AS STATUS 
                                 FROM plot_tools
                                 WHERE CD_ID_PLOT = ?
                                 AND CD_ID_PTP    = ?
                                 AND NAME_PT      = ?
                                 AND CD_ID_PT    != ?
                                 ',params = list(plot.aux$CD_ID_PLOT,flag,nome,toolEdit$CD_ID_PT)) > 0){
            
            showNotification("O nome da marca do ponto já existe nesse mapa", type = "warning")
            return()
          }
          
        }
        else if(DBI::dbGetQuery(con,
                                'SELECT COUNT(*) AS STATUS 
                                 FROM plot_tools
                                 WHERE CD_ID_PLOT = ?
                                 AND CD_ID_PTP    = ?
                                 AND NAME_PT      = ?',params = list(plot.aux$CD_ID_PLOT,flag,nome)) > 0){
          
          showNotification("O nome da marca do ponto já existe nesse mapa", type = "warning")
          return()
        }
        
        coordenadas <- sp::coordinates(valueMapDraw$drawnPoly)
        script      <- jsonlite::toJSON(list(
          icone       = input$comboImage,
          coordenadas = coordenadas
        ),auto_unbox = T)
        
        if (is.null(toolEdit)){
          
          insertTable(con,"PLOT_TOOLS",list(
            NAME_PT      = nome,
            SCRIPT_PT    = script,
            CD_ID_PTP    = flag,
            CD_ID_PLOT   = plot.aux$CD_ID_PLOT
          ))
          
          dialogConfirm(
            title = 'Marca de ponto criado com suceso!',
            text = 'Deseja criar novamente uma nova marca de ponto?',
            callback = function(status) {
              
              if(!status){
                updateRegistro(Sys.time())
                flag <<- 0
                swiperSlidePrevious()
                sliderPosition(swiperPosition)
              }
              else{
                resetpanel(Sys.time())
              }
              
            })
          
        }else{
          
          DBI::dbExecute(con,"UPDATE PLOT_TOOLS SET NAME_PT = ?,SCRIPT_PT = ? WHERE CD_ID_PT = ?",params = list(nome,script,toolEdit$CD_ID_PT))
          
          updateRegistro(Sys.time())
          toolEdit <<- NULL
          flag     <<- 0
          swiperSlidePrevious()
          sliderPosition(swiperPosition)
          
          
        }
      }
      else if(any(flag %in% seq(from = 3,to = 15,by = 2)) || any(flag %in% seq(from = 4,to = 16,by = 2))){ #vertical ou horizontal line
        
        size  <- input$sliderSize
        color <- input$comboColor
        value <- input$textValue
        tipo  <- input$comboLineType
        
        lineObj <- list(
          color = color,
          value = value,
          size  = size,
          tipo  = tipo
        )  
        
        if (is.null(toolEdit)){
          
          insertTable(con,"PLOT_TOOLS",list(
            NAME_PT      = nome,
            SCRIPT_PT    = jsonlite::toJSON(lineObj,auto_unbox = T),
            CD_ID_PTP    = flag,
            CD_ID_PLOT   = plot.aux$CD_ID_PLOT
          ))
          
          dialogConfirm(
            title = 'Linha criado com suceso!',
            text = 'Deseja criar novamente uma nova linha?',
            callback = function(status) {
              
              if(!status){
                updateRegistro(Sys.time())
                flag <<- 0
                swiperSlidePrevious()
                sliderPosition(swiperPosition)
              }
              else{
                resetpanel(Sys.time())
              }
              
            })
          
        }else{
          
          DBI::dbExecute(con,"UPDATE PLOT_TOOLS SET NAME_PT = ?,SCRIPT_PT = ? WHERE CD_ID_PT = ?",params = list(nome,jsonlite::toJSON(lineObj,auto_unbox = T),toolEdit$CD_ID_PT))
          
          updateRegistro(Sys.time())
          toolEdit <<- NULL
          flag     <<- 0
          swiperSlidePrevious()
          sliderPosition(swiperPosition)
          
          
        }
      }
      
    })
    
  },ignoreInit = T,ignoreNULL = T))
  
  obs$add(observeEvent(input$btActionCancel,{
    
    current <- swiperPosition
    
    if(current == 1){
      obs$destroy()
      obs2$destroy()
      obs3$destroy()
      removeModal()
      callback()
    }
    else{
      toolEdit <<- NULL
      flag     <<- 0
      swiperSlidePrevious()
      sliderPosition(swiperPosition)
    }
    
  },ignoreInit = T,ignoreNULL = T))
  
  
}
