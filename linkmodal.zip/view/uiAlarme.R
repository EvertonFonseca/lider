uiAlarmeNew     <- function(input,output,con,setores,servers,callback){
  
  source('model/SmartObserve.R',local = T)
  obs  <- newObserve()
  obs2 <- newObserve()
  obs.comando <- newObserve()
  
  logica             <<- NULL
  setores            <- setores[which(sapply(setores, function(x){ length(x$OBJETOS) != 0}))]
  object             <- NULL
  setoresNomes       <- sapply(setores, function(x) { x$NAME_SETOR })
  objects            <- NULL
  events             <- list()
  vetorLogica        <- getVetorLogico()
  currentPosition    <- reactiveVal(1)
  niveis             <- c('Crítico','Aviso','Informação','Sucesso')
  colorNiveis        <- c('red','orange','blue','green')
  comando            <- NA
  contatos           <- selectContatosDao(con,user)
  init.comondo       <- TRUE
  resetDigital       <- reactiveVal(NULL)
  agendamentos       <- list(
                          freq  = selectCronogramaFreqDao(con),
                          dias  = selectCronogramaDiasDao(con),
                          meses = selectCronogramaMesesDao(con)
                        )
  
  
  id <- 'dialogObj'
  cssStyle <- list()
  cssStyle[[paste0(' #parent',id,' .modal-dialog')]]  <- paste0('height: 80% !important;')
  cssStyle[[paste0(' #parent',id,' .modal-content')]] <- paste0('width: 100% !important; height: 100% !important;')
  cssStyle[[paste0(' #parent',id,' .modal-body')]]    <- paste0('width: 100% !important; height: calc(100% - 57px - 65px) !important; overflow-y: hidden;')
  
  showModal(shiny::div(
    id = paste0('parent', id),
    style = paste0("height: 90%;"),
    shinyjs::inlineCSS(cssStyle),
    dialogModal(
      title = dialogTitleClose('Criar Alarme',function(){

        DBI::dbDisconnect(con)
        obs.comando$destroy()
        obs$destroy()
        obs2$destroy()
        removeModal()
        callback()
        
      }),
      size = 'm',
      swiper(id = 'swiperMain',
             parent.style = 'height: 100%; width: 100%;',
             width = '100%',
             height = '100%',
             swiperSlide(
               style = 'height: 100%; width: 100%; overflow-y: auto; overflow-x: hidden;',
               uiOutput('slider1',style = 'height: 100%; width: 100%;')
             ),
             swiperSlide(
               style = 'height: 100%; width: 100%; overflow-y: auto; overflow-x: hidden;',
               uiOutput('slider2',style = 'height: 100%; width: 100%;')
             ),
             swiperSlide(
               style = 'height: 100%; width: 100%; overflow-y: auto; overflow-x: hidden; padding: 10px;',
               uiOutput('slider3',style = 'height: 100%; width: 100%;')
             )
      ),
      footer = uiOutput('uiFooter')
    )
  ))
  
  output$uiFooter <- renderUI({
    
    current <- currentPosition()
    
    if(current == 1){
      tagList(actionButton('btPreveius', label = "Sair"),actionButton('btNext', label = "Avançar"))
    }
    else if(current == 2){
      tagList(actionButton('btPreveius', label = "Voltar"),actionButton('btNext', label = "Avançar"))
    }
    else{
      tagList(actionButton('btPreveius', label = "Voltar"),actionButton('btNext', label = "Salvar"))
    }
    
  })
  
  buildScriptAgendamento <- function(){
    
    frequencia <- which(agendamentos$freq$NAME_CF == input$radioAgendamento)
    script     <- list(frequencia = frequencia)
    
    if(frequencia == 1) # UMA VEZ
    {
      script$data <- input$agendaDateDe
      script$hora <- format(input$agendaTimeDe,'%H:%M')
    }
    else if(frequencia == 2){ # POR MES
      
      script$meses <- which(input$comboAgenda == agendamentos$meses$NAME_CM)
      script$hora  <- format(input$agendaTimeDe,'%H:%M')
    }
    else if(frequencia == 3){ # SEMANAL
      
      script$semanas <- which(input$comboAgenda == agendamentos$dias$NAME_CD)
      script$hora    <- format(input$agendaTimeDe,'%H:%M')
      
    }
    else if(frequencia == 4){ # DIARIAMENTE
      
      script$hora <- format(input$agendaTimeDe,'%H:%M')
      
    }
    return(jsonlite::toJSON(script,auto_unbox = T))
  }
  
  transformePosicaoAtributos <- function(comando,object){
    
    for (i in seq_along(comando)) {
      
      token <- comando[i]
      atributo <- rlist::list.find(object$ATRIBUTOS,NAME_ATRIBUTO == token)
      
      if(is_empty(atributo)) next
      
      comando[i] <- paste0('ATRIBUTO_',atributo[[1]]$CD_ID_ATRIBUTO)
    }
    return(comando)
  }

  obs$add(observeEvent(input$btNext,{
    
    current <- swiperPosition
    
    if(current == 1){
      
      if(length(isolate(input$multiAtributos)) == 0){
        showNotification("Nenhum atributo foi selecionado!", type = "warning") 
        return()
      }
      
      swiperSlideNext()
      currentPosition(swiperPosition)
    }
    else if(current == 2){
      
      if(length(isolate(input$resultadoLogica)) == 0){
        showNotification("Nenhuma logica foi constuida!", type = "warning") 
        return()
      }
      else if(!any(isolate(input$multiAtributos) %in% isolate(input$resultadoLogica))){
        showNotification("Nenhuma atributo está nessa logica!", type = "warning") 
        return()
      }
      
      logica      <<- isolate(input$resultadoLogica)
      swiperSlideNext()
      currentPosition(swiperPosition)
      
    }else if(current == 3){
      
      
      tryResetConnection(con,function(conn){
        
        con <<- conn
        nomeAlarme        <- toupper(stringr::str_trim(input$textoNomeAlarme))
        statusEmails      <- input$checkEmail
        statusPhones      <- input$checkPhones
        statusMessage     <- input$checkMessageAlerta
        statusDigitalOut  <- input$checkobject
        message           <- toupper(stringr::str_trim(input$textoMessage))
        
        if(stringi::stri_isempty(nomeAlarme)){
          showNotification("Campo nome do alarme está vazio!", type = "warning")
          return()
        }
        else if(!any(statusEmails,statusPhones,statusMessage)){
          
          showNotification("Nenhuma ação foi selecionada!", type = "warning")
          return()
        }
        
        emailsAtivos       <- input$multiEmails
        phonesAtivos       <- input$multiPhones
        listaCodigosEmails <- NULL
        listaCodigosPhones <- NULL
        
        if(statusEmails){
          
          if(length(emailsAtivos) == 0){
            
            showNotification("Nenhum email foi selecionado!", type = "warning")
            return()
          }
          
          listaCodigosEmails <- unlist(lapply(emailsAtivos, function(x) unique(contatos %>% filter(stringr::str_detect(x,ADDRESS_EMAIL)) %>% select(CD_ID_EMAIL) %>% pull())))
        }
        
        if(statusPhones){
          
          if(length(phonesAtivos) == 0){
            
            showNotification("Nenhum numero de celular foi selecionado!", type = "warning")
            return()
          }
          
          listaCodigosPhones <- unlist(lapply(phonesAtivos, function(x) unique(contatos %>% filter(stringr::str_detect(x,NUMBER_PHONE)) %>% select(CD_ID_PHONE) %>% pull())))
        }
        
        if(stringi::stri_isempty(message)){
          
          showNotification("Nenhuma mensagem foi escrita!", type = "warning")
          return()
        }

      status <- tryTransation(con,{
          
          #inserir Alarme
          id <- nextSequenciaID(con,'ALARME')
          
          insertTable(con,'ALARME',list(
            CD_ID_ALARME     = id,
            NAME_ALARME      = nomeAlarme,
            LOGICA           = paste0(comando,collapse = ' '),
            DESCRICAO_ALARME = message,
            STATUS           = which(niveis == isolate(input$comboNiveis)),
            CD_ID_OBJECT     = object$CD_ID_OBJECT,
            ACTIVE_REVERSE   = FALSE
          ))
          
          #insere um novo agendamento
          insertTable(con,'AGENDAMENTO_ALARME',list(
            CD_ID_ALARME = id,
            SCRIPT_A     = buildScriptAgendamento()
          ))
          
          #inserir atributoes alarmes
          sapply(input$multiAtributos, function(x){

            x <- rlist::list.find(object$ATRIBUTOS,NAME_ATRIBUTO == x)
            
            if(is_empty(x)) return(NULL)
            
            insertTable(con,'ATRIBUTO_ALARME',list(
              CD_ID_ALARME   = id,
              CD_ID_ATRIBUTO = x[[1]]$CD_ID_ATRIBUTO
            ))
            
          })
          
          #insert email if it was checked
          if(statusEmails){
            
            sapply(listaCodigosEmails, function(x){
              
              insertTable(con,'EMAIL_ALARME',list(
                CD_ID_ALARME  = id,
                CD_ID_EMAIL   = x
              ))
            })
          }
          
          #insert phone if it was checked
          if(statusPhones){
            
            sapply(listaCodigosPhones, function(x){
              
              insertTable(con,'PHONE_ALARME',list(
                CD_ID_ALARME  = id,
                CD_ID_PHONE   = x
              ))
            })
          }
          
          if(statusMessage){
            
            insertTable(con,'MESSAGE_ALARME',list(
              CD_ID_ALARME = id
            ))
          }
          
        })
        
        if(status){
          
          shinyjs::runjs("Shiny.setInputValue('resultadoLogica',null);")
          
          dialogConfirm(
            title = 'Alarme criado com sucesso!',
            text = 'Deseja criar novamente um novo Alarme?',
            callback = function(status) {
              
              if(!status){
                DBI::dbDisconnect(con)
                obs.comando$destroy()
                obs$destroy()
                obs2$destroy()
                removeModal()
                callback()
              }
              else{
                currentPosition(1)
                swiperPosition <<- 1
                swiperSlideTo(index = 0)
              }
              
            })
          
        }
        else{
          showNotification("Não foi possivel executar essa operação!", type = "error") 
        }
      
        
      })
      
      
    }
    
  },ignoreInit = T))
  
  obs$add(observeEvent(input$btPreveius,{
    
    current <- swiperPosition
    
    if(current == 1){
      
      DBI::dbDisconnect(con)
      obs.comando$destroy()
      obs$destroy()
      obs2$destroy()
      removeModal()
      callback()
    }
    else{
      
      swiperSlidePrevious()
      currentPosition(swiperPosition)
    }
    
  },ignoreInit = T))
  
  output$slider1 <- renderUI({
    
    req(currentPosition() == 1)
    
    obs2$clear()
    logica <<- NULL
    init.comondo <<- TRUE

    obs2$add(observeEvent(input[['comboBoxSetor']],{
      
      comboSetor <- input[['comboBoxSetor']]
      
      index   <- which(sapply(setores, function(x){ x$NAME_SETOR == comboSetor}))
      setor   <<- setores[index][[1]]
      objects <<- setor$OBJETOS
      updateSelectInput(getDefaultReactiveDomain(),"comboBoxobjects",choices = sapply(objects, function(object) object$NAME_OBJECT))
      
    }))
    
    output$containerAtributos <- renderUI({
      
      shiny::req(input$comboBoxobjects)
      
      setor      <<- rlist::list.find(setores,NAME_SETOR == isolate(input$comboBoxSetor))[[1]]
      object     <<- rlist::list.filter(setor$OBJETOS,NAME_OBJECT == input$comboBoxobjects)[[1]]
      atributos  <-  rlist::list.filter(object$ATRIBUTOS,R_DATA != 'time')
      
      changetextPlaceHolder()
      
      multiInput(
        inputId = 'multiAtributos',
        width = '100%',
        options = list(
          enable_search = T,
          non_selected_header = "Atributos não selecionados",
          selected_header     = "Atributos selecionados"
        ),
        selected = isolate(input$multiAtributos),
        label = "Atributos do object",
        choices = NULL,
        choiceNames  = lapply( atributos, function(atributo)  tagList(atributo$NAME_ATRIBUTO)),
        choiceValues = lapply( atributos, function(atributo)  atributo$NAME_ATRIBUTO)
      ) %>% tagAppendAttributes(style = ';height: auto; width: 100%;')
      
    })
    
    div(
      style = 'padding-5px;',
      selectInput(
        'comboBoxSetor',
        label = 'Seleciona Setor',
        choices = setoresNomes,
        selected = isolate(input[['comboBoxSetor']])
      ),
      selectInput(
        'comboBoxobjects',
        label = 'Seleciona object',
        choices = '',
        selected = isolate(input[['comboBoxobjects']])
      ),
      uiOutput('containerAtributos')
    )
    
  })
  
  output$slider2 <- renderUI({
    
    req(currentPosition() == 2)

    update.comando <- reactiveVal(logica)
    obs.comando$clear()
    
    obs.comando$add(observeEvent(input$resultadoLogica,{
      
      update.comando(input$resultadoLogica)
      
    },ignoreInit = TRUE,ignoreNULL = TRUE))
    
    comando <<- NA

    output$bucketList <- renderUI({

      comandos <- update.comando()

      if(!is.null(comandos))
      {
        valor    <- as.character(isolate(input[[paste0('textNumeric')]]))
        
        if(!(!is.na(as.numeric(valor)))){
           valor <- paste0('"',valor,'"')
        }
        
        comandos <- stringr::str_replace(comandos,'Valor',valor)
        comandos <- comandos[is.na(comandos) == F] # remove os valores NA
      }
      
      vetorescomandos <- lapply(isolate(input$multiAtributos), function(x) x)
      #vetorescomandos <- vetorescomandos %>% rlist::list.append(textInput(paste0('textNumeric'),'Valor',value = '',placeholder = 'Digite um texto ou valor'))
      vetorescomandos <- vetorescomandos %>% rlist::list.append(textInput(paste0('textNumeric'),'Valor',value = 0))
      sapply(vetorLogica, function(x)  vetorescomandos <<- rlist::list.append(vetorescomandos,x))
      
      if(init.comondo){
        comandos <- NULL
        init.comondo <<- FALSE
      }
      
      #resete valores
      input$comandos
      
      div(
        style = ' padding-5px;',
        h4("Construa a logica para alarme"),
        sortable::bucket_list(
          header = "",
          orientation = 'horizontal',
          sortable::add_rank_list(
            input_id = 'comandos',
            text     = "Comandos",
            labels   = vetorescomandos
          ),
          sortable::add_rank_list(
            input_id = 'resultadoLogica',
            text   = "Logica",
            labels = comandos
          )
        )
      )
      
    })
    uiOutput('bucketList')
    
  })
  
  output$slider3 <- renderUI({
    
    req(currentPosition() == 3)
    
    obs2$clear()
    
    textMessage <- ''
    resetDigital(NULL)
    
    #transformando a logica em mapa de atributoes
    comando     <<- transformePosicaoAtributos(logica,object)
    logica      <- paste0(logica,collapse = ' ')
    
    output$textLogica <- renderText({logica})
    
    output$uiEmail <- renderUI({
      
      status <- input$checkEmail
      
      if(status){
        
        changetextPlaceHolder()
        
        emailsLista <- NULL
        if(nrow(contatos) > 0){
          emailsLista <- paste0(contatos$NAME_CONTATO,' - ',contatos$ADDRESS_EMAIL)
        }
        
        
        tagList(
          multiInput(
            inputId = 'multiEmails',
            width = '100%',
            options = list(
              enable_search = T,
              non_selected_header = "Emails",
              selected_header     = "Ativos"
            ),
            selected = isolate(input$multiEmails),
            label = "Emails de contatos",
            choices = NULL,
            choiceNames  = unique(lapply(emailsLista, function(x)  tagList(x))),
            choiceValues = unique(lapply(emailsLista, function(x)  x))
          ) %>% tagAppendAttributes(style = ';height: auto; width: 100%;'),
          br()
        )
        
      }
      else
      {
        NULL
      }
    })
    
    output$uiPhones <- renderUI({
      
      status <- input$checkPhones
      
      if(status){
        
        changetextPlaceHolder()
        
        phonesLista <- NULL
        if(nrow(contatos) > 0){
          phonesLista <- paste0(contatos$NAME_CONTATO,' - ',contatos$NUMBER_PHONE)
        }
        
        tagList(
          multiInput(
            inputId = 'multiPhones',
            width = '100%',
            options = list(
              enable_search = T,
              non_selected_header = "Celulares",
              selected_header     = "Ativos"
            ),
            selected = isolate(input$multiEmails),
            label = "Numeros de contatos",
            choices = NULL,
            choiceNames  = unique(lapply(phonesLista, function(x)  tagList(x))),
            choiceValues = unique(lapply(phonesLista, function(x)  x))
          ) %>% tagAppendAttributes(style = ';height: auto; width: 100%;'),
          br()
        )
        
      }
      else
      {
        NULL
      }
    })
   
    output$painelAgendamento <- renderUI({
      
      agenda <- input$radioAgendamento
      freq   <- agendamentos$freq$NAME_CF
      
      if(which(freq == agenda) == 1) #once
      {
        fluidRow(   
          column(12,
                 splitLayout(
                   dateInput('agendaDateDe','Data de início',width = 'auto',value = Sys.Date()  + lubridate::days(1),format = "dd/mm/yyyy",language = 'pt-BR'),
                   timeInput(inputId = 'agendaTimeDe','HH:MM',value = strptime("00:00:00", "%T"),seconds = F),
                   cellWidths = 'auto'
                 )
                 
          ))
      }
      else if(which(freq == agenda) == 2) #meses
      {
        fluidRow(   
          column(12,
                 timeInput(inputId = 'agendaTimeDe','HH:MM',value = strptime("00:00:00", "%T"),seconds = F)),
          column(12,
                 selectInput(
                   inputId = "comboAgenda",
                   label = "Quais são os mesês?", 
                   choices = agendamentos$meses$NAME_CM,
                   multiple = T,
                   selected = agendamentos$meses$NAME_CM
                 )
          ))
      }
      else if(which(freq == agenda) == 3) #semana
      {
        fluidRow(   
          column(12,
                 timeInput(inputId = 'agendaTimeDe','HH:MM',value = strptime("00:00:00", "%T"),seconds = F)),
          column(12,
                 selectInput(
                   inputId = "comboAgenda",
                   label = "Quais são os dias das semanas?", 
                   choices = agendamentos$dias$NAME_CD,
                   multiple = T,
                   selected = agendamentos$dias$NAME_CD
                 )
          ))
      }
      
      else if(which(freq == agenda) == 4) #dia a dia
      {
        fluidRow(
          column(12,
                 timeInput(inputId = 'agendaTimeDe','HH:MM',value = strptime("00:00:00", "%T"),seconds = F))
        )
      }else{
        NULL
      }
    })
    
    # output$uiSql <- renderUI({
    #   
    #   req(input$checkSql)
    # 
    #   abributos <- setNames(unlist(rlist::list.select(object$ATRIBUTOS,NAME_ATRIBUTO)),NULL)
    #   
    #   tagList(
    #     fluidRow(column(12,selectInput('comboServer','Seleciona Servidor',choices   = servers$TITLE_DB,width = '100%')),
    #              column(12,      
    #                     multiInput(
    #                       inputId = 'multiAtributos',
    #                       width = '100%',
    #                       options = list(
    #                         enable_search = T,
    #                         non_selected_header = "Atributos",
    #                         selected_header     = "Atributos na query"
    #                       ),
    #                       selected = isolate(input$multiEmails),
    #                       label = paste0("Atributos ",object$NAME_OBJECT),
    #                       choices = NULL,
    #                       choiceNames  = unique(lapply(abributos, function(x)  tagList(x))),
    #                       choiceValues = unique(lapply(abributos, function(x)  x))
    #                     ) %>% tagAppendAttributes(style = ';height: auto; width: 100%;'))
    #              ),
    #     tags$span("BEGIN",style = 'font-weight: bold;'),
    #     textAreaInput('textoSql',
    #                   '',
    #                   value = '',
    #                   placeholder = 'Digite o corpo da query.',
    #                   height = '100%',
    #                   resize = "none") %>% 
    #       shiny::tagAppendAttributes(style = 'width: 100%; font-weight: bold; height: 150px;'),
    #     br(),
    #     tags$span("END;",style = 'font-weight: bold;'),
    #     br()
    #   )
    #   
    # })
    # 
    # obs2$add(observeEvent(input$textoMessage,{
    #   
    #   textMessage <<- input$textoMessage
    #   
    # },ignoreInit = T))
    
    output$containerMessage <- renderUI({
      
      req(input$checkEmail || input$checkPhones || input$checkMessageAlerta)
      
      tagList(
        shinyjs::inlineCSS(paste0("#",paste0('textoMessage')," {text-transform: uppercase;}")),
        textAreaInput('textoMessage',
                      'Mensagem',
                      value = textMessage,
                      placeholder = 'Escreve uma mensagem para esse alarme',
                      height = '100px',
                      resize = "none") %>% 
          shiny::tagAppendAttributes(style = 'width: 100%; font-size: 18px; font-weight: bold;')
      )
      
    })
    
    output$imageNiveis <- shiny::renderUI({
      
      icon               <-  c("skull-crossbones",  "exclamation","info","check")
      index              <- which(input$comboNiveis == niveis)  
      
      shiny::span(shiny::icon(icon[index]),style = paste0('color: ',colorNiveis[index],'; top: 30px; position: relative; font-size: 18px;'))
      
    })
    
    div(
      style = ' padding-5px;',
      fluidRow(
        column(6,
               shinyjs::inlineCSS(paste0("#",paste0('textoNomeAlarme')," {text-transform: uppercase;}")),
               textInput("textoNomeAlarme","Nome Alarme",placeholder = "Digite o nome do alarme")
        ),
        column(6,
               shiny::splitLayout(
                 shiny::uiOutput('imageNiveis'),
                 selectInput(inputId = "comboNiveis", 
                             label = "Niveis", 
                             choices = niveis
                 ),
                 cellWidths = c('18px','90%'),
                 cellArgs   = list(style = "padding-left: 2px")
               ) 
        )
      ),
      br(),
      panelTitle(title = "Agendamento",
                 background.color.title = 'white',
                 title.color = 'black',
                 border.color = 'lightgray',
                 children = fluidRow(
                   style = 'padding-top: 10px; padding-left: 15px; padding-right: 15px;',
                   column(3,     
                          shinyWidgets::prettyRadioButtons(
                            inputId = "radioAgendamento",
                            label = "Frequência", 
                            choices = agendamentos$freq$NAME_CF
                          )),
                   column(9,uiOutput('painelAgendamento',style = 'padding-left: 15px; padding-right: 15px;'))
                   
                 )),
      br(),
      panelTitle(title = "Tipo de Ações",
                 background.color.title = 'white',
                 title.color = 'black',
                 border.color = 'lightgray',
                 children = div(
                   style = 'padding: 15px;',
                   prettySwitch(
                     inputId = "checkMessageAlerta",
                     label = "Ativar envio de mensagem notificação", 
                     status = "success",
                     value = T,
                     fill = TRUE
                   ),
                   prettySwitch(
                     inputId = "checkEmail",
                     label = "Ativar envio email", 
                     status = "success",
                     value = FALSE,
                     fill = TRUE
                   ),
                   uiOutput('uiEmail',style = 'padding: 5px;'),
                   prettySwitch(
                     inputId = "checkPhones",
                     label = "Ativar envio celulares", 
                     status = "success",
                     value = FALSE,
                     fill = TRUE
                   ),
                   uiOutput('uiPhones',style = 'padding: 5px;'),
                   # prettySwitch(
                   #   inputId = "checkSql",
                   #   label = "Ativar envio Sql", 
                   #   status = "success",
                   #   value = FALSE,
                   #   fill = TRUE
                   # ),
                   #uiOutput('uiSql',style = 'padding: 5px;'),
                   #prettySwitch(
                   #   inputId = "checkHttp",
                   #   label = "Ativar envio Http Post", 
                   #   status = "success",
                   #   value = FALSE,
                   #   fill = TRUE
                   # ),
                   #uiOutput('uiHttpPost',style = 'padding: 5px;'),
                   uiOutput(outputId = 'containerMessage',style = 'padding: 5px;')
                 )
      ),
      br(),
      tagList(
        textAreaInput('textLogica',
                      'Logica',
                      value = logica,
                      height = '100px',
                      resize = "none") %>% 
          shiny::tagAppendAttributes(style = 'width: 100%;') %>%  
          tagAppendAttributesFind(2,style = 'text-align: center;',readonly = 'readonly'))
      
    )
    
  })
  
}

uiAlarmeTable <- function(input,output,con,setores,alarmes,callback){

  source('model/SmartObserve.R',local = T)
  obs         <- newObserve()
  obs2        <- newObserve()
  obs.comando <- newObserve()
  logica      <- NULL
  alarmes              <- reactiveVal(alarmes)
  alarme               <- reactiveVal(NULL)
  object               <- NULL
  observeEvents        <- list()
  sliderPosition       <- reactiveVal(1)
  atributoes.digitais  <- NULL
  niveis               <- c('Crítico','Aviso','Informação','Sucesso')
  agendamentos         <- list(
                          freq  = selectCronogramaFreqDao(con),
                          dias  = selectCronogramaDiasDao(con),
                          meses = selectCronogramaMesesDao(con)
                        )
  colorNiveis          <- c('red','orange','blue','green')
  comando              <- NA
  contatos             <- selectContatosDao(con,user)
  vetorLogica          <- getVetorLogico()
  resetDigital         <- reactiveVal(NULL)
  tools.monitor        <- NULL

  id <- 'dialogObj'
  cssStyle <- list()
  cssStyle[[paste0(' #parent',id,' .modal-dialog')]]  <- paste0('height: 80% !important;')
  cssStyle[[paste0(' #parent',id,' .modal-content')]] <- paste0('width: 100% !important; height: 100% !important;')
  cssStyle[[paste0(' #parent',id,' .modal-body')]]    <- paste0('width: 100% !important; height: calc(100% - 57px - 65px) !important; overflow-y: hidden;')

  #Modal para Dialog
  showModal(div(
    id = paste0('parent', id),
    style = paste0("height: 90%;"),
    shinyjs::inlineCSS(cssStyle),
    dialogModal(
      title = dialogTitleClose('Registro Alarmes',function(){

        DBI::dbDisconnect(con)
        obs.comando$destroy()
        obs$destroy()
        obs2$destroy()
        swiperDestroy()
        removeModal()
        callback()

      }),
      size = 'm',
      swiper(id = 'swiperMain',
             parent.style = 'height: 100%; width: 100%;',
             width = '100%',
             height = '100%',
             swiperSlide(
               style = 'height: 100%; width: 100%; overflow-y: auto;',
               uiOutput('slider1',style = 'height: 100%; width: 100%;')
             ),
             swiperSlide(
               style = 'height: 100%; width: 100%;  overflow-y: auto;',
               uiOutput('slider2',style = 'height: 100%; width: 100%;')
             ),
             swiperSlide(
               style = 'height: 100%; width: 100%;  overflow-y: auto;',
               uiOutput('slider3',style = 'height: 100%; width: 100%;')
             ),
             swiperSlide(
               style = 'height: 100%; width: 100%; overflow-y: auto; overflow-x: hidden; padding: 10px;',
               uiOutput('slider4',style = 'height: 100%; width: 100%;')
             )
      ),
      footer = uiOutput('uiFooter'),
      callback = function(size){onResizedWindows(list(height = size$height))}
    )
  ))
  
  output$uiFooter <- renderUI({
    
    current <- sliderPosition()
    
    if(current == 1){
      tagList(actionButton('btActionCancel', label = "Sair"))
    }
    else if(current >= 2 && current <= 3){
      tagList(actionButton('btActionCancel', label = "Voltar"),actionButton('btActionUpdate' ,label = 'Avançar'))
    }
    else{
      tagList(actionButton('btActionCancel', label = "Voltar"),actionButton('btActionUpdate' ,label = 'Atualizar'))
    }
    
    
  })

  replaceNameObjeto  <- function(logica,object){

    tokens <- unlist(stringr::str_split(logica,' '))
    values <- sapply(object$ATRIBUTOS,function(atributo){

      name         <- paste0('ATRIBUTO_',atributo$CD_ID_ATRIBUTO)
      valor        <- atributo$NAME_ATRIBUTO
      names(valor) <- name
      valor
    })
    #retonar value replaced
    stringr::str_replace_all(tokens,values)
  }

  buildScriptAgendamento <- function(){

    frequencia <- which(agendamentos$freq$NAME_CF == input$radioAgendamento)
    script     <- list(frequencia = frequencia)

    if(frequencia == 1) # UMA VEZ
    {
      script$data <- input$agendaDateDe
      script$hora <- format(input$agendaTimeDe,'%H:%M')
    }
    else if(frequencia == 2){ # POR MES

      script$meses <- which(input$comboAgenda == agendamentos$meses$NAME_CM)
      script$hora  <- format(input$agendaTimeDe,'%H:%M')
    }
    else if(frequencia == 3){ # SEMANAL

      script$semanas <- which(input$comboAgenda == agendamentos$dias$NAME_CD)
      script$hora    <- format(input$agendaTimeDe,'%H:%M')

    }
    else if(frequencia == 4){ # DIARIAMENTE

      script$hora <- format(input$agendaTimeDe,'%H:%M')

    }
    return(jsonlite::toJSON(script,auto_unbox = T))
  }

  transformePosicaoAtributos <- function(comando,object){
    
    for (i in seq_along(comando)) {
      
      token <- comando[i]
      atributo <- rlist::list.find(object$ATRIBUTOS,NAME_ATRIBUTO == token)
      
      if(is_empty(atributo)) next
      
      comando[i] <- paste0('ATRIBUTO_',atributo[[1]]$CD_ID_ATRIBUTO)
    }
    return(comando)
  }


  output$slider1 <- renderUI({

    output$tableDinamica <- DT::renderDataTable({

      # future({
      dataset  <-  alarmes() %>%
        select(CD_ID_ALARME,NAME_ALARME,DESCRICAO_ALARME,STATUS,NAME_USER) %>%
        arrange(NAME_ALARME) %>%
        unique()

      if(length(dataset) == 0) return(NULL)

      colunaNames <- c('LINHA','ALARME','DESCRIÇÃO','NOTIFICAÇÃO','USUARIO','ATIVO','VISUALIZAR / EDITAR','REMOVER')
      
      dataset$LINHA             <- 1:nrow(dataset)
      dataset$ALARME            <- dataset$NAME_ALARME
      dataset$DESCRICAO         <- dataset$DESCRICAO_ALARME
      dataset$NOTIFICACAO       <- sapply(dataset$STATUS,function(x) niveis[x])
      dataset$USUARIO           <- dataset$NAME_USER

      height <- (onResizedWindows()$height * 0.65)  - (150)
  
      DT::datatable({

        dataset %>%
          mutate_if(is.POSIXct,function(x){ format(x,'%d/%m/%Y %H:%M:%S')})  %>%
          mutate_if(is.Date,function(x){ format(x,'%d/%m/%Y')}) %>%
          mutate_if(is.character,toupper) %>%
          mutate(
            !!colunaNames[1] :=  1:nrow(dataset),
            !!colunaNames[2] :=  dataset$NAME_ALARME,
            !!colunaNames[3] :=  dataset$DESCRICAO_ALARME,
            !!colunaNames[4] :=  sapply(dataset$STATUS,function(x) niveis[x]),
            !!colunaNames[5] :=  dataset$NAME_USER,
            !!colunaNames[6] := sapply(dataset$CD_ID_ALARME, function(x) {
              
              alarme <- isolate(alarmes()) %>% filter(CD_ID_ALARME == x)
              
              json <- paste0('{"alarme":"',x,'","status":document.getElementById("',paste0("checkBoxActiveplot",x),'").checked}')
              
              as.character( div(
                style = "width: auto; height: auto;",
                prettyToggle(
                  inputId = paste0("checkBoxActiveplot",x),
                  label_on = "Sim",
                  label_off = "Não",
                  outline = TRUE,
                  plain = TRUE,
                  value = alarme$FG_ONLINE,
                  icon_on = icon("thumbs-up"),
                  icon_off = icon("thumbs-down"),
                  bigger = T,
                  width = 'auto'
                ),
                onclick = paste0('Shiny.setInputValue(\"editPressedStatus\",',json,',{priority: "event"})')
              ))
              
            }),
            !!colunaNames[7] := sapply(CD_ID_ALARME, function (x) {
              
              as.character(
                actionButton(
                  paste0('btEdit'),
                  label = '',
                  icon = icon('eye'),
                  onclick = paste0('Shiny.setInputValue(\"editPressedRow\","',x,'",{priority: "event"})'),
                  #style = 'background-color: transparent; color: lightblue; border-solid: none;'
                )
              )
            }),
            !!colunaNames[8] := sapply(CD_ID_ALARME, function(x){
              
              as.character(
                actionButton(
                  paste0('btRemove'),
                  label = '',
                  icon = icon('trash'),
                  onclick = paste0('Shiny.setInputValue(\"deletePressedRow\","',x,'",{priority: "event"})'),
                  #style = 'background-color: transparent; color: lightblue; border-solid: none;'
                )
              )
              
            })

          ) %>% select(colunaNames)
      },
      class = 'cell-border stripe',
      extensions = 'Scroller',
      options = list(
        language = list(url = 'js/table/translate.json'),
        dom = 't',
        bSort=FALSE,
        columnDefs = list(list(visible=FALSE, targets=c(0)),list(className = 'dt-center', targets = "_all"),list(width = '75px',targets = c(1,4)),list(width = 'autos',targets = c(3))),
        deferRender = TRUE,
        scroller = TRUE,
        fixedHeader = TRUE,
        scrollX = TRUE,
        scrollY = paste0(height,"px")
      ),
      escape = F,
      selection = 'none',
      )  %>% DT::formatStyle(colnames(result), cursor = 'pointer')

    })

    div(
      style = 'border-style: solid; border-color: white; border-width: 1px; overflow-x: auto;',
      DT::dataTableOutput(outputId = 'tableDinamica')
    )

  })

  output$slider2 <- renderUI({

    req(sliderPosition() == 2)

    alarme   <- isolate(alarme()$alerta)
    object   <- isolate(alarme()$object)
   
    output$containerAtributosEdit <- renderUI({

      atributoes <-  object$ATRIBUTOS

      changetextPlaceHolder()

      multiInput(
        inputId = 'multiAtributosEdit',
        width = '100%',
        options = list(
          enable_search = T,
          non_selected_header = "Atributos não selecionados",
          selected_header     = "Atributos selecionados"
        ),
        selected = sapply(rlist::list.filter(atributoes,CD_ID_ATRIBUTO %in% alarme$CD_ID_ATRIBUTO), function(atributo)  atributo$NAME_ATRIBUTO),
        label = "Atributos do object",
        choices = NULL,
        choiceNames  = lapply(atributoes, function(atributo)  tagList(atributo$NAME_ATRIBUTO)),
        choiceValues = lapply(atributoes, function(atributo)  atributo$NAME_ATRIBUTO)
      ) %>% tagAppendAttributes(style = ';height: auto; width: 100%;')

    })

    div(
      style = 'padding-5px;',
      textInput('textoobjectEdit','object',value = object$NAME_OBJECT) %>%
        tagAppendAttributesFind(2,readonly = 'readonly'),
      uiOutput('containerAtributosEdit')
    )


  })

  output$slider3 <- renderUI({

    req(sliderPosition() == 3)

    update.comando <- reactiveVal(logica)
    obs.comando$clear()
    
    obs.comando$add(observeEvent(input$resultadoLogicaEdit,{
      
      update.comando(input$resultadoLogicaEdit)
      
    },ignoreInit = TRUE,ignoreNULL = TRUE))
    
    init.comondo <<- TRUE

    output$bucketListEdit <- renderUI({

      comandos       <- update.comando()
      multiAtributos <- isolate(input$multiAtributosEdit)

      if(!is.null(comandos))
      {
        valor    <- as.character(isolate(input[[paste0('textNumeric')]]))
        
        if(!(!is.na(as.numeric(valor)))){
          valor <- paste0('"',valor,'"')
        }
        
        comandos <- stringr::str_replace(comandos,'Valor',valor)
        comandos <- comandos[is.na(comandos) == F] # remove os valores NA
      }

      vetorescomandos <- lapply(multiAtributos, function(x) x)
      #vetorescomandos <- vetorescomandos %>% rlist::list.append(textInput(paste0('textNumeric'),'Valor',value = '',placeholder = 'Digite um texto ou valor'))
      vetorescomandos <- vetorescomandos %>% rlist::list.append(textInput(paste0('textNumeric'),'Valor',value = 0))
      sapply(vetorLogica, function(x)  vetorescomandos <<- rlist::list.append(vetorescomandos,x))


      if(init.comondo){

        comandos     <- replaceNameObjeto(unique(alarme()$alerta$LOGICA),alarme()$object)
        init.comondo <<- FALSE

        nomes  <- setNames(unlist(rlist::list.select(alarme()$object$ATRIBUTOS,NAME_ATRIBUTO)),NULL)
        for (token in nomes) {

          if(!any(token %in% multiAtributos)){

            comandos <- stringr::str_remove_all(comandos,token)
            comandos <- comandos[!stringi::stri_isempty(comandos)]
          }

        }
      }

      #resete valores
      input$comandos

      div(
        style = 'padding-5px;',
        h4("Construa a logica para alarme"),
        sortable::bucket_list(
          header = "",
          orientation = 'horizontal',
          sortable::add_rank_list(
            input_id = 'comandos',
            text     = "Comandos",
            labels   = vetorescomandos
          ),
          sortable::add_rank_list(
            input_id = 'resultadoLogicaEdit',
            text   = "Logica",
            labels = comandos
          )
        )
      )

    })
    uiOutput('bucketListEdit')

  })

  output$slider4 <- renderUI({

    req(sliderPosition() == 4)

    init <- TRUE

    obs2$clear()
  
    resetDigital(NULL)
    emails      <- isolate(alarme()$emails)
    phones      <- isolate(alarme()$phones)
    messages    <- isolate(alarme()$messages)
    alarme      <- isolate(alarme()$alerta)
    object      <- isolate(alarme()$object)
    textMessage <- unique(alarme$DESCRICAO_ALARME)

    script  <- jsonlite::fromJSON(unique(alarme$SCRIPT_A))
    logica  <- paste0(logica,collapse = ' ')
    #transformando a logica em mapa de atributoes
    comando     <<- transformePosicaoAtributos(logica,object)
  
    output$textLogica <- renderText({logica})

    output$uiEmail <- renderUI({

      status <- input$checkEmail

      if(status){

        changetextPlaceHolder()

        emails.tmp <- emails %>% filter((CD_ID_CONTATO %in% contatos$CD_ID_CONTATO) & (CD_ID_EMAIL %in% contatos$CD_ID_EMAIL))
        
        emailsLista <- NULL
        if(nrow(contatos) > 0){
          emailsLista <- paste0(contatos$NAME_CONTATO,' - ',contatos$ADDRESS_EMAIL)
        }

        emails.tmp <- apply(emails.tmp,1, function(x){
          
          contato <- contatos %>% filter(CD_ID_CONTATO == x["CD_ID_CONTATO"])
          
          paste0(contato$NAME_CONTATO,' - ',x["ADDRESS_EMAIL"])
          
        }) 

        tagList(
          multiInput(
            inputId = 'multiEmails',
            width = '100%',
            options = list(
              enable_search = T,
              non_selected_header = "Emails",
              selected_header     = "Ativos"
            ),
            selected = emails.tmp,
            label = "Emails de contatos",
            choices = NULL,
            choiceNames  = unique(lapply(emailsLista, function(x)  tagList(x))),
            choiceValues = unique(lapply(emailsLista, function(x)  x))
          ) %>% tagAppendAttributes(style = ';height: auto; width: 100%;'),
          br()
        )

      }
      else
      {
        NULL
      }
    })

    output$uiPhones <- renderUI({

      status <- input$checkPhones

      if(status){

        changetextPlaceHolder()

        fones.tmp <- phones %>% filter((CD_ID_CONTATO %in% contatos$CD_ID_CONTATO) & (CD_ID_PHONE %in% contatos$CD_ID_PHONE))
        
        phonesLista <- NULL
        if(nrow(contatos) > 0){
          phonesLista <- paste0(contatos$NAME_CONTATO,' - ',contatos$NUMBER_PHONE)
        }
        
        fones.tmp <- apply(fones.tmp,1, function(x){
          
          contato <- contatos %>% filter(CD_ID_CONTATO == x["CD_ID_CONTATO"])
          
          paste0(contato$NAME_CONTATO,' - ',x["NUMBER_PHONE"])
          
        }) 

        tagList(
          multiInput(
            inputId = 'multiPhones',
            width = '100%',
            options = list(
              enable_search = T,
              non_selected_header = "Celulares",
              selected_header     = "Ativos"
            ),
            selected = fones.tmp,
            label = "Numeros de contatos",
            choices = NULL,
            choiceNames  = unique(lapply(phonesLista, function(x)  tagList(x))),
            choiceValues = unique(lapply(phonesLista, function(x)  x))
          ) %>% tagAppendAttributes(style = ';height: auto; width: 100%;'),
          br()
        )

      }
      else
      {
        NULL
      }
    })
    
    output$painelAgendamento <- renderUI({

      agenda  <- input$radioAgendamento
      freq    <- agendamentos$freq$NAME_CF
      posicao <- which(freq == agenda)

      if(init){
        posicao <- script$frequencia
        init <<- FALSE
      }

      if(posicao == 1) #once
      {
        fluidRow(
          column(12,
                 splitLayout(
                   dateInput('agendaDateDe','Data de início',width = 'auto',value = Sys.Date()  + lubridate::days(1),format = "dd/mm/yyyy",language = 'pt-BR'),
                   timeInput(inputId = 'agendaTimeDe','HH:MM',value = strptime("00:00:00", "%T"),seconds = F),
                   cellWidths = 'auto'
                 )

          ))
      }
      else if(posicao == 2) #meses
      {
        fluidRow(
          column(12,
                 timeInput(inputId = 'agendaTimeDe','HH:MM',value = strptime("00:00:00", "%T"),seconds = F)),
          column(12,
                 selectInput(
                   inputId = "comboAgenda",
                   label = "Quais são os mesês?",
                   choices = agendamentos$meses$NAME_CM,
                   multiple = T,
                   selected = agendamentos$meses$NAME_CM
                 )
          ))
      }
      else if(posicao == 3) #semana
      {
        fluidRow(
          column(12,
                 timeInput(inputId = 'agendaTimeDe','HH:MM',value = strptime("00:00:00", "%T"),seconds = F)),
          column(12,
                 selectInput(
                   inputId = "comboAgenda",
                   label = "Quais são os dias das semanas?",
                   choices = agendamentos$dias$NAME_CD,
                   multiple = T,
                   selected = agendamentos$dias$NAME_CD
                 )
          ))
      }

      else if(posicao == 4) #dia a dia
      {
        fluidRow(
          column(12,
                 timeInput(inputId = 'agendaTimeDe','HH:MM',value = strptime("00:00:00", "%T"),seconds = F))
        )
      }else{
        NULL
      }
    })

    obs2$add(observeEvent(input$textoMessage,{

      textMessage <<- input$textoMessage

    },ignoreInit = T))

    output$containerMessage <- renderUI({

      req(input$checkEmail || input$checkPhones || input$checkMessageAlerta)

      tagList(
        shinyjs::inlineCSS(paste0("#",paste0('textoMessage')," {text-transform: uppercase;}")),
        textAreaInput('textoMessage',
                      'Mensagem',
                      value = textMessage,
                      placeholder = 'Escreve uma mensagem para esse alarme',
                      height = '100px',
                      resize = "none") %>%
          shiny::tagAppendAttributes(style = 'width: 100%; font-size: 18px; font-weight: bold;')
      )

    })

    output$imageNiveis <- shiny::renderUI({

      icon               <-  c("skull-crossbones",  "exclamation","info","check")
      index              <- which(input$comboNiveis == niveis)

      shiny::span(shiny::icon(icon[index]),style = paste0('color: ',colorNiveis[index],'; top: 30px; position: relative; font-size: 18px;'))

    })

    div(
      style = ' padding-5px;',
      fluidRow(
        column(6,
               shinyjs::inlineCSS(paste0("#",paste0('textoNomeAlarme')," {text-transform: uppercase;}")),
               textInput("textoNomeAlarme","Nome Alarme",placeholder = "Digite o nome do alarme",value = unique(alarme$NAME_ALARME))
        ),
        column(6,
               shiny::splitLayout(
                 shiny::uiOutput('imageNiveis'),
                 selectInput(inputId = "comboNiveis",
                             label = "Niveis",
                             choices = niveis,
                             selected = unique(alarme$STATUS)
                 ),
                 cellWidths = c('18px','90%'),
                 cellArgs   = list(style = "padding-left: 2px")
               )
        )
      ),
      br(),
      panelTitle(title = "Agendamento",
                 background.color.title = 'white',
                 title.color = 'black',
                 border.color = 'lightgray',
                 children = fluidRow(
                   style = 'padding-top: 10px; padding-left: 15px; padding-right: 15px;',
                   column(3,
                          shinyWidgets::prettyRadioButtons(
                            inputId = "radioAgendamento",
                            label = "Frequência",
                            choices = agendamentos$freq$NAME_CF,
                            selected = agendamentos$freq$NAME_CF[script$frequencia]
                          )),
                   column(9,uiOutput('painelAgendamento',style = 'padding-left: 15px; padding-right: 15px;'))

                 )),
      br(),
      panelTitle(title = "Tipo de Ações",
                 background.color.title = 'white',
                 title.color = 'black',
                 border.color = 'lightgray',
                 children = div(
                   style = 'padding: 15px;',
                   prettySwitch(
                     inputId = "checkMessageAlerta",
                     label = "Ativar envio de mensagem notificação",
                     status = "success",
                     value = nrow(messages) > 0,
                     fill = TRUE
                   ),
                   prettySwitch(
                     inputId = "checkEmail",
                     label = "Ativar envio email",
                     status = "success",
                     value = nrow(emails) > 0,
                     fill = TRUE
                   ),
                   uiOutput('uiEmail',style = 'padding: 5px;'),
                   prettySwitch(
                     inputId = "checkPhones",
                     label = "Ativar envio celulares",
                     status = "success",
                     value = nrow(phones) > 0,
                     fill = TRUE
                   ),
                   uiOutput('uiPhones',style = 'padding: 5px;'),
                   uiOutput(outputId = 'containerMessage',style = 'padding: 5px;')
                 )
      ),
      br(),
      tagList(
        textAreaInput('textLogica',
                      'Logica',
                      value = logica,
                      height = '100px',
                      resize = "none") %>%
          shiny::tagAppendAttributes(style = 'width: 100%;') %>%
          tagAppendAttributesFind(2,style = 'text-align: center;',readonly = 'readonly'))

    )
  })

  obs$add(observeEvent(input$editPressedStatus,{

    obj    <- input$editPressedStatus
    alarme <- isolate(alarmes()) %>% filter(CD_ID_ALARME == obj$alarme)

    tryResetConnection(con,function(conn){

      con <<- conn
      updateTable(con = con,table = "ALARME",obj = list(FG_ONLINE = obj$status),where = paste0("CD_ID_ALARME = ",obj$alarme))

    })

  },ignoreInit = T))

  obs$add(observeEvent(input$editPressedRow,{

    alarme.tmp <- isolate(alarmes()) %>% filter(CD_ID_ALARME == input$editPressedRow)
    id.object  <- unique(alarme.tmp$CD_ID_OBJECT)

    object <- rlist::list.apply(setores,function(setor){

      x <- rlist::list.filter(setor$OBJETOS,CD_ID_OBJECT == id.object)

      if(length(x) > 0)
        x[[1]]
      else
        NULL

    }) %>% purrr::discard(is.null)

    tryResetConnection(con,function(coon){
      
      con <<- coon
     
      messages <- selectMessageAlarme(con,unique(alarme.tmp %>% select(CD_ID_ALARME)))
      emails   <- selectEmailAlarme(con,unique(alarme.tmp %>% select(CD_ID_ALARME)))
      phones   <- selectPhoneAlarme(con,unique(alarme.tmp %>% select(CD_ID_ALARME)))
      
      alarme(list(alerta = alarme.tmp, 
                  object = object[[1]],
                  messages = messages,
                  emails   = emails,
                  phones   = phones
      ))
      
      swiperSlideNext()
      sliderPosition(swiperPosition)
      
    })

  },ignoreInit = T,ignoreNULL = T))

  obs$add(observeEvent(input$deletePressedRow,{

    alarme <- alarmes %>% filter(CD_ID_ALARME == input$deletePressedRow)

    messageAlerta(input,
                  title   = paste0('Todos os processos ligado a esse alarme será excluido'),
                  message = paste0('Deseja realmente excluir o alarme ',alarme$NAME_ALARME,"?"),
                  callback.no = function(){

                  },
                  callback.yes = function(){

                    tryResetConnection(con,function(conn){

                      con <<- conn
                      #remove Database setor
                      DBI::dbExecute(con,paste0('DELETE FROM ALARME WHERE CD_ID_ALARME = ',alarme$CD_ID_ALARME))

                      alarmes.tmp <- selectAllAlarmesDAO(con)
                      
                      if(nrow(alarmes.tmp) > 0){
                        alarmes(alarmes.tmp)
                      }else{
                        DBI::dbDisconnect(con)
                        obs.comando$destroy()
                        obs$destroy()
                        obs2$destroy()
                        swiperDestroy()
                        removeModal()
                        callback()
                      }


                    })

                  })

  },ignoreInit = T))

  obs$add(observeEvent(input$btActionCancel,{

    current <- swiperPosition

    if(current == 1){

      DBI::dbDisconnect(con)
      obs.comando$destroy()
      obs$destroy()
      obs2$destroy()
      swiperDestroy()
      removeModal()
      callback()
    }
    else if(current == 2){

      shinyjs::delay(1000,{
        alarme(NULL)
      })
      swiperSlidePrevious()
      sliderPosition(swiperPosition)
    }
    else{

      swiperSlidePrevious()
      sliderPosition(swiperPosition)
    }

  },ignoreInit = T))

  obs$add(observeEvent(input$btActionUpdate,{

    current <- swiperPosition

    if(current == 2){

      if(length(isolate(input$multiAtributosEdit)) == 0){
        showNotification("Nenhum atributo foi selecionado!", type = "warning")
        return()
      }

      swiperSlideNext()
      sliderPosition(swiperPosition)

    }else if(current == 3){

      if(length(isolate(input$resultadoLogicaEdit)) == 0){
        showNotification("Nenhuma logica foi constuida!", type = "warning") 
        return()
      }
      else if(!any(isolate(input$multiAtributosEdit) %in% isolate(input$resultadoLogicaEdit))){
        showNotification("Nenhuma atributo está nessa logica!", type = "warning") 
        return()
      }
      logica  <<- isolate(input$resultadoLogicaEdit)
      swiperSlideNext()
      sliderPosition(swiperPosition)

    }
    else if(current == 4){

      tryResetConnection(con,function(conn){
        
        con <<- conn
        nomeAlarme        <- toupper(stringr::str_trim(input$textoNomeAlarme))
        statusEmails      <- input$checkEmail
        statusPhones      <- input$checkPhones
        statusMessage     <- input$checkMessageAlerta
        statusDigitalOut  <- input$checkobject
        message           <- toupper(stringr::str_trim(input$textoMessage))
        
        emails            <- isolate(alarme()$emails)
        phones            <- isolate(alarme()$phones)
        messages          <- isolate(alarme()$messages)
        alarme            <- isolate(alarme()$alerta)
        object            <- isolate(alarme()$object)
        
        if(stringi::stri_isempty(nomeAlarme)){
          showNotification("Campo nome do alarme está vazio!", type = "warning")
          return()
        }
        else if(!any(statusEmails,statusPhones,statusMessage)){
          
          showNotification("Nenhuma ação foi selecionada!", type = "warning")
          return()
        }
        
        emailsAtivos       <- input$multiEmails
        phonesAtivos       <- input$multiPhones
        listaCodigosEmails <- NULL
        listaCodigosPhones <- NULL
        
        if(statusEmails){
          
          if(length(emailsAtivos) == 0){
            
            showNotification("Nenhum email foi selecionado!", type = "warning")
            return()
          }
          
          listaCodigosEmails <- unlist(lapply(emailsAtivos, function(x) unique(contatos %>% filter(stringr::str_detect(x,ADDRESS_EMAIL)) %>% select(CD_ID_EMAIL) %>% pull())))
        }
        
        if(statusPhones){
          
          if(length(phonesAtivos) == 0){
            
            showNotification("Nenhum numero de celular foi selecionado!", type = "warning")
            return()
          }
          
          listaCodigosPhones <- unlist(lapply(phonesAtivos, function(x) unique(contatos %>% filter(stringr::str_detect(x,NUMBER_PHONE)) %>% select(CD_ID_PHONE) %>% pull())))
        }
        
        if(stringi::stri_isempty(message)){
          
          showNotification("Nenhuma mensagem foi escrita!", type = "warning")
          return()
        }
        
        status <- tryTransation(con,{
          
          #inserir Alarme
          id <- unique(alarme$CD_ID_ALARME)
          
          updateTable(con,'ALARME',
          paste0('CD_ID_ALARME = ',id),            
          list(
            NAME_ALARME      = nomeAlarme,
            LOGICA           = paste0(comando,collapse = ' '),
            DESCRICAO_ALARME = message,
            STATUS           = which(niveis == isolate(input$comboNiveis)),
            CD_ID_OBJECT     = object$CD_ID_OBJECT,
            ACTIVE_REVERSE   = 0
          ))
          
          #insere um novo agendamento
          updateTable(con,'AGENDAMENTO_ALARME',
          paste0('CD_ID_A = ',unique(alarme$CD_ID_A)),
          list(
            SCRIPT_A     = buildScriptAgendamento()
          ))
          
          #inserir atributoes alarmes
          sapply(input$multiAtributosEdit, function(x){
            
            x <- rlist::list.find(object$ATRIBUTOS,NAME_ATRIBUTO == x)
            
            if(is_empty(x)) return(NULL)
            
            if(!(x[[1]]$NAME_ATRIBUTO %in% alarme$NAME_ATRIBUTO))
            {
              insertTable(con,'ATRIBUTO_ALARME',list(
                CD_ID_ALARME   = id,
                CD_ID_ATRIBUTO = x[[1]]$CD_ID_ATRIBUTO
              ))
            }
            
          })
          
          #remove atributos is not used
          apply(alarme %>% filter(!(NAME_ATRIBUTO %in% input$multiAtributosEdit)),1,function(x){
            DBI::dbExecute(
              con,
              'DELETE FROM ATRIBUTO_ALARME WHERE CD_ID_ATRIBUTO = ? AND CD_ID_ALARME = ?',
              params = list(x["CD_ID_ATRIBUTO"], id)
            )
          })
          
          #insert email if it was checked
          if(statusEmails){
            
            sapply(listaCodigosEmails, function(x){
              
              if(!(x %in% unique(emails$CD_ID_EMAIL)))
              {
                insertTable(con,'EMAIL_ALARME',list(
                  CD_ID_ALARME  = id,
                  CD_ID_EMAIL   = x
                ))
              }
            })
            
            #remove atributos is not used
            apply(emails %>% filter(!(CD_ID_EMAIL %in% listaCodigosEmails)),1,function(x){
              DBI::dbExecute(con,'DELETE FROM EMAIL_ALARME WHERE CD_ID_EA = ? AND CD_ID_ALARME = ?',params = list(x["CD_ID_EA"],id))
            })
            
          }
          else{
            #remove atributos is not used
            apply(emails,1,function(x){
              DBI::dbExecute(con,'DELETE FROM EMAIL_ALARME WHERE CD_ID_EA = ? AND CD_ID_ALARME = ?',params = list(x["CD_ID_EA"],id))
            })
          }
          
          #insert phone if it was checked
          if(statusPhones){
            
            sapply(listaCodigosPhones, function(x){
            
              if(!(x %in% unique(phones$CD_ID_PHONE)))  
              {
                insertTable(con,'PHONE_ALARME',list(
                  CD_ID_ALARME  = id,
                  CD_ID_PHONE   = x
                ))
              }
              
            })
            
            #remove atributos is not used
            apply(phones %>% filter(!(CD_ID_PHONE %in% listaCodigosPhones)),1,function(x){
              DBI::dbExecute(con,'DELETE FROM PHONE_ALARME WHERE CD_ID_PA = ? AND CD_ID_ALARME = ?',params = list(x["CD_ID_PA"],id))
            })
            
          }
          else{
            #remove atributos is not used
            apply(phones,1,function(x){
              DBI::dbExecute(con,'DELETE FROM PHONE_ALARME WHERE CD_ID_PA = ? AND CD_ID_ALARME = ?',params = list(x["CD_ID_PA"],id))
            })
          }
          
          if(statusMessage){
            
            if(nrow(messages) == 0)
            {
              insertTable(con,'MESSAGE_ALARME',list(
                CD_ID_ALARME = id
              ))
            }
          }
          else{
            DBI::dbExecute(con,'DELETE FROM MESSAGE_ALARME WHERE CD_ID_ALARME = ?',params = list(id))
          }
          
        })
        
        if(status){

          alarmes(selectAllAlarmesDAO(con))
          
          alarme(NULL)
          sliderPosition(1)
          swiperSlideTo(index = 0)  

        }
        else{
          showNotification("Não foi possivel executar essa operação!", type = "error") 
        }
        
      })
      
    }


  },ignoreInit = T))

}
