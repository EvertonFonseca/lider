componentHeader <- function(input,output,textoInformacao,size.right = 50 * 3) {
  
  uiHeader <-   renderUI({
    
    div(style = paste0('position: absolute;
                        width: auto;
                        height: 25px;
                        right: ',size.right,'px;
                        top: 25%;'),
        tags$span(style='float: left; color: white; font-size: 15px;',textoInformacao())
    )
  })
  
  return(uiHeader)
}

output$containerHeader <- componentHeader(input,output,function(){
  
  timeReactive()
  span(format(Sys.time(),"%d/%m/%Y %H:%M"))
  
})

output$dropsMensagem <- renderMenu({
  
  dropdownMenu(
    type = "messages",
    badgeStatus = "danger",
    headerText = 'Mensagens dos usurios',
    messageItem(from = 'João',message = 'Teste 1!'),
    messageItem(from = 'João',message = 'Teste 2!')
  )
  
})

output$dropsAlertas <- renderMenu({
  
  dropsNotification <- inputDropsNotification()
  n <- length(dropsNotification)
  
  if(n > 0){
    #play sound notification
    shinyjs::runjs("document.getElementById('soundNotificationOn').play();")
  }
  
  dropdownMenu(
    type = "notifications",
    icon = icon('bell'),
    badgeStatus = "danger",
    headerText = paste0('Você tem ',n,' ',{
      if(n == 0 || n == 1){
        'notificação.'
      }else{
        'notificações'
      }
    }),
    .list = dropsNotification
  )
  
})

