ui <- function(translate){
  
  return(
    dashboardPagePlus(
      title = 'Bind-data',
      header = dashboardHeaderPlus(
        fixed = T,
        enable_rightsidebar = TRUE,
        rightSidebarIcon = "gears",
        title = tagList(
          span(class = "logo-lg", "Bind-data Software"),
          img(src = "favicontitle.png",height = '20px',width = '20px')),
          uiOutput('containerPlay',class = 'dropdown-toggle',style = 'position: absolute; left: 50px; margin-top: 10px;'),
          uiOutput('containerHeader'),
          dropdownMenuOutput('dropsMensagem'),
          dropdownMenuOutput('dropsAlertas')
      ),
      sidebar = dashboardSidebar(
        width = 230,
        uiOutput('sidebarMenu')
      ),
      body = dashboardBody(
        id = 'root',
        includeCleave(country = "BR"),
        useShinyjs(),
        use_vov(),
        includeCSS('www/css/swiper.min.css'),
        includeScript('www/js/swiper.min.js'),
        includeCSS('www/css/config.css'),
        shinyDashboardThemes(theme = ""),
        tags$head(
          tags$meta(name="viewport", content="initial-scale=1, maximum-scale=1"),
          tags$link(rel = "shortcut icon", href = "favicon.png"),
          tags$script(HTML('
          
          function reportWindowSize() {
            Shiny.setInputValue("onResized",[window.innerWidth,window.innerHeight], {priority: "event"});
          }
  
          window.addEventListener("resize", reportWindowSize);
  
         /* $(function() {
           $(this).bind("contextmenu", function(e) {
            e.preventDefault();
            Shiny.setInputValue("onMouseRightClicked","", {priority: "event"});
            return false;
          });
       });*/ \n

      ')),
          tags$style(
            HTML(" 
            body{
                 font-family: 'Segoe UI', serif;
            }
            .shiny-split-layout > div {overflow: visible;}
           
            .form-control[disabled], .form-control[readonly], fieldset[disabled] .form-control {
              background-color: white;
              color: #696767;
              opacity: 1;
            }
            
            .selectize-control.single .selectize-input:after {
               right: 5px!important;
           }
        
            .tabbable > .nav > li > a {color: gray;}
            
            .tabbable > .nav > li > a:hover{color: gray;}
            
            .skin-blue .main-header .navbar .sidebar-toggle{
        
               color: white;
            }
            
            //.tab-content{margin-top: -30px !important;}
            
            .skin-blue .main-header .navbar .sidebar-toggle:hover{
        
               color: gray;
             }
              .box-header {
                  margin-left: 25px;
              }
              
              .recalculating {
               opacity: 1!important;
               }
              .js-plotly-plot .plotly .modebar {
                left: 2px;
               }
             /*.shiny-notification {
               position:fixed;
               top: 10px;
               right: 5px;
             }*/
             .main-footer{
              color: gray;
              border-top-style: solid;
              background-color: white;
             }
             .skin-blue .sidebar-menu > li > .treeview-menu {
              background: rgb(52,62,72)!important;
             }

             "
            )
          )
        ),
        # Set up shinyjs
        tags$head(tags$title("Bind-data")),
        tags$head(tags$link(rel = "shortcut icon", href = "favicon.png")),
        uiOutput('painelTabSetores'),
        tagList(
          tags$audio(id ='soundNotificationOn',src = "sounds/bell_warning.wav", type = "audio/wav", controls = NA, style="display:none;"),
          tags$audio(id ='soundLoginOn',src = "sounds/login_on.wav", type = "audio/wav", controls = NA, style="display:none;"),
          tags$audio(id ='soundSessionDialog',src = "sounds/dialog_open.mp3", type = "audio/mp3", controls = NA, style="display:none;")
        ),
        br()
      ), 
       rightsidebar = rightSidebar(
        background = "dark",
        rightSidebarTabContent(
          id = 1,
          title = "Sistema",
          icon = "desktop",
          active = TRUE,
          prettySwitch(
            inputId = "checkBoxActiveRealTimer",
            label   = "Ativar Monitoramento", 
            status  = "success",
            value = FALSE,
            fill = TRUE
          )
        ),
        rightSidebarTabContent(
          id = 2,
          title = "Tab 2",
          textInput("caption", "Caption", "Data Summary")
        ),
        rightSidebarTabContent(
          id = 3,
          icon = "paint-brush",
          title = "Tab 3",
          numericInput("obs", "Observations:", 10, min = 1, max = 100)
        )
      ),
      footer = dashboardFooter(
        left_text = "Version 1.0.0",
        right_text = tags$i(style = 'color: gray; font-size: 12px;',paste0("Copyright © 2020-",format(Sys.Date(),'%Y')," YEMG Softwares, All Rights Reserved."))
      )
    )  %>% tagAppendAttributes(class = 'sidebar-collapse')
  )
}
