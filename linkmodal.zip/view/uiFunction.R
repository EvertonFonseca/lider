uiFunctionNew <- function(con,input,output,estruturas,callback){

  source('model/SmartObserve.R',local = T)
  obs            <- newObserve()
  obs1           <- newObserve()
  obs2           <- newObserve()
  resete         <- reactiveVal()
  sliderPosition <- reactiveVal(1)
  structure <- NULL
  atributos <- NULL
  
  id <- 'dialogObj'
  cssStyle <- list()
  cssStyle[[paste0(' #parent',id,' .modal-dialog')]]  <- paste0('height: auto !important;')
  cssStyle[[paste0(' #parent',id,' .modal-content')]] <- paste0('width: 100% !important; height: 100% !important;')
  cssStyle[[paste0(' #parent',id,' .modal-body')]]    <- paste0('width: 100% !important; height: calc(100% - 57px - 65px) !important; overflow-y: hidden;')
  
  showModal(
    shiny::div(
      id = paste0('parent', id),
      style = paste0("height: 100%;"),
      shinyjs::inlineCSS(cssStyle),
      dialogModal(
        title = dialogTitleClose('Nova Função',function(){
          
          #destroy all observe events
          DBI::dbDisconnect(con)
          obs$destroy()
          obs1$destroy()
          obs2$destroy()
          removeModal()
          callback()
          
        }),
        size = 'm',
        swiper(id = 'swiperMain',
               parent.style = 'height: 100%; width: 100%;',
               width = '100%',height = '100%',
               swiperSlide(
                 style = 'height: 100%; width: 100%;  overflow-y: hidden; overflow-x: hidden; padding: 5px;',
                 uiOutput('slider1',style = 'height: 100%; width: 100%;')
               ),
               swiperSlide(
                 style = 'height: 100%; width: 100%; overflow-y: hidden; overflow-x: hidden; padding: 5px;',
                 uiOutput('slider2',style = 'height: 100%; width: 100%;')
               )
        ),
        footer = uiOutput('uiFooter'))))


  output$uiFooter <- renderUI({
    
    current <- sliderPosition()
    
    if(current == 1){
      tagList(actionButton('btActionSair', label = "Sair"),actionButton('btActionTeste', label = "Validar"),actionButton('btActionSalvar', label = "Salvar"))
    }
    else{
      tagList(actionButton('btActionSair', label = "Voltar"))
    }
    
    
  })
  
  output$slider1 <- renderUI({
    
    resete()
    obs1$clear()
    obs1$add(observeEvent(input$importFile,{
      
      tryCatch({
        file <- input$importFile$datapath
        updateTextAreaInput(inputId = 'textoScript',value = readr::read_file(file))
      },error = function(e) print(e))
      
    },ignoreInit = TRUE))

    obs1$add(observeEvent(input$comboEstrutura,{
      
      tryResetConnection(con,function(coon){
        
        con <<- coon
        structure <<-  estruturas %>% filter(NAME_STRUCT == input$comboEstrutura)
        atributos <<-  selectAllAtributoOfStructFunction(con,structure)
        
        updateSelectInput(inputId = 'comboAtributo',choices = atributos$NAME_ATRIBUTO)
        
      })
    
    },ignoreInit = F))
    
    output$bodyfunction <- renderUI({
      
      name <- input$comboAtributo
      
      updateTextAreaInput(inputId = 'textoScript',placeholder = paste0('Exemplo: ',tolower(name),' + 100'))
      tags$span(paste0("function(",tolower(name),"){"),style = 'font-weight: bold;')
    })
    
    div(
      style = 'width: 100%; height: auto;',
      fluidRow(
        shinyjs::inlineCSS("#textFunction {text-transform: uppercase;}"),
        column(12,textInput('textFunction',label = "Nome",placeholder = 'Digite o nome para função')),
        column(6,selectInput('comboEstrutura','Estrutura',choices = estruturas$NAME_STRUCT)),
        column(6,selectInput('comboAtributo','Atributo',choices   = ''))
      ),
      tagList(
        uiOutput('bodyfunction'),
        textAreaInput('textoScript',
                      '',
                      value = '',
                      height = '100%',
                      resize = "none") %>% 
          shiny::tagAppendAttributes(style = 'width: 100%; font-weight: bold; height: 250px; padding-left: 10px; margin-top: -20px;'),
        tags$span("}",style = 'font-weight: bold;'),
        fileInput(inputId = "importFile",label = "Arquivo javascript",multiple = F,accept = c('.js'),placeholder = 'Seleciona o arquivo',width = '100%'),
      ))
    
  })

  output$slider2 <- renderUI({
    
    req(sliderPosition() == 2)
    
    obs2$clear()
    
    obs2$add(observeEvent(input$btTeste,{

      script    <- isolate(input$textoScript)
      variavel  <- paste0("var ",tolower(isolate(input$comboAtributo))," = ",isolate(input$textFuncTest),";\n")
      resultado <- 'Error contexto!'
      
      tryCatch({
        resultado <- js::js_eval(paste0(variavel,script))
      },error = function(e){})
      
      updateTextAreaInput(inputId = 'textoSaida',value = resultado)
      
    },ignoreInit = TRUE))
    
    div(
      fluidRow(
        column(6,textInput('textFuncTest',label = tolower(isolate(input$comboAtributo)),value = '',placeholder = 'Entre com valor da variavel')),
        column(6,actionButton('btTeste','Testar',icon = icon('vial'),style = 'position: relative; top: 25px;',width = '100%'))
      ),
      textAreaInput('textoSaida',
                    'Saída da função',
                    value = '',
                    height = '100%',
                    resize = "none") %>% 
      shiny::tagAppendAttributes(style = 'width: 100%; font-weight: bold; height: 100px;') %>%
      tagAppendAttributesFind(2,readonly = 'readonly'),
      br()
    )
    
  })
  
  obs$add(observeEvent(input$btActionTeste,{
    
    sliderPosition(2)
    swiperSlideNext()
    sliderPosition(swiperPosition)
    
  },ignoreInit = T))
  
  obs$add(observeEvent(input$btActionSalvar,{
  
     nome   <- toupper(isolate(input$textFunction))
     script <- isolate(input$textoScript)
    
    if(stringi::stri_isempty(stringr::str_trim(nome))){
      
      showNotification("O nome não foi preenchido!", type = "error")
      
      return()
    }
     
    if(stringi::stri_isempty(stringr::str_trim(script))){
       
       showNotification("O corpo da função não foi preenchida!", type = "error")
       
       return()
    }

      tryResetConnection(con,function(coon){
        
        con <<- coon

        if(checkifExistNameFunction(con,nome)){
          
          showNotification("O nome já possui nos registros!", type = "error")
          return()
        }

        atributo  <- atributos %>% filter(NAME_ATRIBUTO == isolate(input$comboAtributo))
        
        insertTable(con,'FUNCTION_ATRIBUTO',list(
          CD_ID_ATRIBUTO = atributo$CD_ID_ATRIBUTO,
          NAME_FUNCTION  = nome,
          BODY_FUNCTION  = script
        ))
        
        keys <- systemCache$keys()
        keys <- keys[stringr::str_starts(systemCache$keys(),'dataplotcache')]
        sapply(keys, function(x) systemCache$remove(x))
        
        dialogConfirm(
          title = 'Função criado com sucesso!',
          text = 'Deseja criar novamente uma nova função?',
          callback = function(status) {
            
            if(!status){
              DBI::dbDisconnect(con)
              obs$destroy()
              obs1$destroy()
              obs2$destroy()
              removeModal()
              callback()
            }
            else
              resete(Sys.time())
          })
        
      })
    
  },ignoreInit = T))
  
  obs$add(observeEvent(input$btActionSair,{
    
    current <- swiperPosition
    
    if(current == 1){
      
      #destroy all observe events
      DBI::dbDisconnect(con)
      obs$destroy()
      obs1$destroy()
      obs2$destroy()
      removeModal()
      callback()
      
    }else{
      sliderPosition(1)
      swiperSlidePrevious()
      sliderPosition(swiperPosition)
    }

    
  },ignoreInit = T))
  
}

uiFunctionTable <- function(con,input,output,estruturas,funcoes,callback){
  
  source('model/SmartObserve.R',local = T)
  obs            <- newObserve()
  obs1           <- newObserve()
  obs2           <- newObserve()
  resete         <- reactiveVal()
  funcoes        <- reactiveVal(funcoes)
  funcao         <- NULL
  sliderPosition <- reactiveVal(1)
  structure <- NULL
  atributos <- NULL
  
  id <- 'dialogObj'
  cssStyle <- list()
  cssStyle[[paste0(' #parent',id,' .modal-dialog')]]  <- paste0('height: 690px !important;')
  cssStyle[[paste0(' #parent',id,' .modal-content')]] <- paste0('width: 100% !important; height: 100% !important;')
  cssStyle[[paste0(' #parent',id,' .modal-body')]]    <- paste0('width: 100% !important; height: calc(100% - 57px - 65px) !important; overflow-y: hidden;')
  
  showModal(
    shiny::div(
      id = paste0('parent', id),
      style = paste0("height: 100%;"),
      shinyjs::inlineCSS(cssStyle),
      dialogModal(
        title = dialogTitleClose('Registro Funções',function(){
          
          #destroy all observe events
          DBI::dbDisconnect(con)
          obs$destroy()
          obs1$destroy()
          obs2$destroy()
          removeModal()
          callback()
          
        }),
        size = 'm',
        swiper(id = 'swiperMain',
               parent.style = 'height: 100%; width: 100%;',
               width = '100%',height = '100%',
               swiperSlide(
                 style = 'height: 100%; width: 100%;  overflow-y: hidden; overflow-x: hidden; padding: 5px;',
                 uiOutput('slider1',style = 'height: 100%; width: 100%;')
               ),
               swiperSlide(
                 style = 'height: 100%; width: 100%; overflow-y: hidden; overflow-x: hidden; padding: 5px;',
                 uiOutput('slider2',style = 'height: 100%; width: 100%;')
               ),
               swiperSlide(
                 style = 'height: 100%; width: 100%; overflow-y: hidden; overflow-x: hidden; padding: 5px;',
                 uiOutput('slider3',style = 'height: 100%; width: 100%;')
               )
        ),
        footer = uiOutput('uiFooter'),
        callback = function(size){onResizedWindows(list(height = size$height))}
        )))
  
  
  output$uiFooter <- renderUI({
    
    current <- sliderPosition()
    
    if(current == 1){
      tagList(actionButton('btActionSair', label = "Voltar"))
    }
    else if(current == 2){
      tagList(actionButton('btActionSair', label = "Sair"),actionButton('btActionTeste', label = "Validar"),actionButton('btActionSalvar', label = "Salvar"))
    }
    else{
      tagList(actionButton('btActionSair', label = "Voltar"))
    }
    
    
  })
  
  output$slider1 <- renderUI({
    
    output$tableDinamica <- DT::renderDataTable({
      
      # future({
      dataset  <-  funcoes()
      
      if(length(dataset) == 0) return(NULL)
      
      colunaNames <- c('LINHA','FUNÇÃO','ESTRUTURA','ATRIBUTO','ATIVO','VISUALIZAR / EDITAR','REMOVER')
      
      DT::datatable({
        
        dataset %>% 
          mutate_if(is.POSIXct,function(x){ format(x,'%d/%m/%Y %H:%M:%S')})  %>% 
          mutate_if(is.Date,function(x){ format(x,'%d/%m/%Y')}) %>% 
          mutate_if(is.character,toupper) %>% 
          mutate(!!colunaNames[1] :=  1:nrow(dataset),
                 !!colunaNames[2] :=  dataset$NAME_FUNCTION,
                 !!colunaNames[3] :=  dataset$NAME_STRUCT,
                 !!colunaNames[4] :=  dataset$NAME_ATRIBUTO,
                 !!colunaNames[5] :=  apply(dataset,1, function(x) {
                   
                   x <- as.list(x)
                   
                   json <- paste0('{"object":"',x$CD_ID_FUNCTION,'","status":document.getElementById("',paste0("checkBoxActive",x$CD_ID_FUNCTION),'").checked}')  
                   
                   as.character( div(
                     style = "width: auto; height: auto;",
                     prettyToggle(
                       inputId = paste0("checkBoxActive",x$CD_ID_FUNCTION),
                       label_on = "Sim",
                       label_off = "Não", 
                       outline = TRUE,
                       plain = TRUE,
                       value = as.logical(as.integer(x$FG_ACTIVE_FUNCTION)),
                       icon_on = icon("thumbs-up"),
                       icon_off = icon("thumbs-down"),
                       bigger = T,
                       width = 'auto'
                     ),
                     onclick = paste0('Shiny.setInputValue(\"editPressedStatus\",',json,',{priority: "event"})')
                   ))
                   
                 }),
                 !!colunaNames[6] :=  sapply(dataset$CD_ID_FUNCTION, function (x) {
                   
                   as.character(
                     actionButton(
                       paste0('btEdit'),
                       label = '',
                       icon = icon('eye'),
                       onclick = paste0('Shiny.setInputValue(\"editPressedRow\","',x,'",{priority: "event"})'),
                       #style = 'background-color: transparent; color: lightblue; border-solid: none;'
                     )
                   )
                 }),
                 !!colunaNames[7] := sapply(dataset$CD_ID_FUNCTION, function(x){
                   
                   as.character(
                     actionButton(
                       paste0('btRemove'),
                       label = '',
                       icon = icon('trash'),
                       onclick = paste0('Shiny.setInputValue(\"deletePressedRow\","',x,'",{priority: "event"})'),
                       #style = 'background-color: transparent; color: lightblue; border-solid: none;'
                     )
                   )
                   
                 })
                 
          ) %>% select(colunaNames) %>% arrange(colunaNames[2])
      }, 
      class = 'cell-border stripe',
      extensions = 'Scroller',
      options = list(
        language = list(url = 'js/table/translate.json'),
        dom = 't',
        bSort=FALSE,
        columnDefs = list(list(visible=FALSE, targets=c(0)),list(className = 'dt-center', targets = "_all")),
        deferRender = TRUE,
        scroller = TRUE,
        fixedHeader = TRUE,
        scrollX = TRUE,
        scrollY = '400px'
      ),
      escape = F,
      selection = 'none',
      )  %>% DT::formatStyle(colnames(result), cursor = 'pointer')
      
    })
    
    div(
      style = 'border-style: solid; border-color: white; border-width: 1px; overflow-x: auto;',
      DT::dataTableOutput(outputId = 'tableDinamica')
    )
    
  })
  
  output$slider2 <- renderUI({
    
    resete()
    req(funcao)
    
    obs1$clear()
    
    obs1$add(observeEvent(input$importFile,{
      
      tryCatch({
        file <- input$importFile$datapath
        updateTextAreaInput(inputId = 'textoScript',value = readr::read_file(file))
      },error = function(e) print(e))
      
    },ignoreInit = TRUE))
    
    obs1$add(observeEvent(input$comboEstrutura,{
      
      tryResetConnection(con,function(coon){
        
        con <<- coon
        structure <<-  estruturas %>% filter(NAME_STRUCT == input$comboEstrutura)
        atributos <<-  selectAllAtributoOfStructFunction(con,structure)
        
        updateSelectInput(inputId = 'comboAtributo',choices = atributos$NAME_ATRIBUTO,selected = funcao$NAME_ATRIBUTO)
        
      })
      
    },ignoreInit = F))
    
    output$bodyfunction <- renderUI({
      
      name <- input$comboAtributo
      
      updateTextAreaInput(inputId = 'textoScript',placeholder = paste0('Exemplo: ',tolower(name),' + 100'))
      tags$span(paste0("function(",tolower(name),"){"),style = 'font-weight: bold;')
    })
    
    div(
      style = 'width: 100%; height: auto;',
      fluidRow(
        shinyjs::inlineCSS("#textFunction {text-transform: uppercase;}"),
        column(12,textInput('textFunction',label = "Nome",placeholder = 'Digite o nome para função',value = funcao$NAME_FUNCTION)),
        column(6,selectInput('comboEstrutura','Estrutura',choices = estruturas$NAME_STRUCT,selected = funcao$NAME_STRUCT)),
        column(6,selectInput('comboAtributo','Atributo',choices   = ''))
      ),
      tagList(
        uiOutput('bodyfunction'),
        textAreaInput('textoScript',
                      '',
                      value = funcao$BODY_FUNCTION,
                      placeholder = 'Digite o corpo da função.',
                      height = '100%',
                      resize = "none") %>% 
          shiny::tagAppendAttributes(style = 'width: 100%; font-weight: bold; height: 250px; padding-left: 10px; margin-top: -20px;'),
        tags$span("}",style = 'font-weight: bold;'),
        fileInput(inputId = "importFile",label = "Arquivo javascript",multiple = F,accept = c('.js'),placeholder = 'Seleciona o arquivo',width = '100%'),
      ))
    
  })
  
  output$slider3 <- renderUI({
    
    req(sliderPosition() == 3)
    
    obs2$clear()
    
    obs2$add(observeEvent(input$btTeste,{

      script    <- isolate(input$textoScript)
      variavel  <- paste0("var ",tolower(isolate(input$comboAtributo))," = ",isolate(input$textFuncTest),";\n")
      resultado <- 'Error contexto!'
      
      tryCatch({
        resultado <- js::js_eval(paste0(variavel,script))
      },error = function(e){})
      
      updateTextAreaInput(inputId = 'textoSaida',value = resultado)
      
    },ignoreInit = TRUE))
    
    div(
      fluidRow(
        column(6,textInput('textFuncTest',label = tolower(isolate(input$comboAtributo)),value = '',placeholder = 'Entre com valor da variavel')),
        column(6,actionButton('btTeste','Testar',icon = icon('vial'),style = 'position: relative; top: 25px;',width = '100%'))
      ),
      textAreaInput('textoSaida',
                    'Saída da função',
                    value = '',
                    height = '100%',
                    resize = "none") %>% 
        shiny::tagAppendAttributes(style = 'width: 100%; font-weight: bold; height: 100px;') %>%
        tagAppendAttributesFind(2,readonly = 'readonly'),
      br()
    )
    
  })
  
  obs$add(observeEvent(input$editPressedStatus,{
    
    obj  <- input$editPressedStatus
    
    tryResetConnection(con,function(coon){
      
      con <<- coon
      updateTable(con,'FUNCTION_ATRIBUTO',paste0('CD_ID_FUNCTION = ',obj$object),list(FG_ACTIVE_FUNCTION = as.integer(obj$status)))

    })
    
  },ignoreInit = T))
  
  obs$add(observeEvent(input$editPressedRow,{
    
    funcao <<- isolate(funcoes()) %>% filter(CD_ID_FUNCTION == input$editPressedRow)
    
    resete(Sys.time())
    swiperSlideNext()
    sliderPosition(swiperPosition)
    
  },ignoreInit = T))
  
  obs$add(observeEvent(input$deletePressedRow,{
    
    funcao <- isolate(funcoes()) %>% filter(CD_ID_FUNCTION == input$deletePressedRow)
    
    messageAlerta(input,
                  title   = paste0('Todos os processos ligado a esse objeto será excluido'),
                  message = paste0('Deseja realmente excluir a função ',funcao$NAME_FUNCTION,"?"),
                  callback.no = function(){
                    
                  },
                  callback.yes = function(){
                    
                    tryResetConnection(con,function(conn){
                      
                      con <<- conn
                      DBI::dbExecute(con,"DELETE FROM FUNCTION_ATRIBUTO WHERE CD_ID_FUNCTION = ?",params = list(funcao$CD_ID_FUNCTION))
                      
                      funcaoes.tmp <- selectAllFuncao(con)
                     
                      if(nrow(funcaoes.tmp) > 0){
                        funcoes(funcaoes.tmp)
                      }
                      else{
                        #destroy all observe events
                        DBI::dbDisconnect(con)
                        obs$destroy()
                        obs1$destroy()
                        obs2$destroy()
                        removeModal()
                        callback()
                      }
                      
                    })
                    
                    
                  })
    
  },ignoreInit = T))
  
  obs$add(observeEvent(input$btActionTeste,{

    sliderPosition(3)
    swiperSlideNext()
    sliderPosition(swiperPosition)
    
  },ignoreInit = T))
  
  obs$add(observeEvent(input$btActionSalvar,{
    
    nome   <- toupper(isolate(input$textFunction))
    script <- isolate(input$textoScript)
    
    if(stringi::stri_isempty(stringr::str_trim(nome))){
      
      showNotification("O nome não foi preenchido!", type = "error")
      
      return()
    }
    
    if(stringi::stri_isempty(stringr::str_trim(script))){
      
      showNotification("O corpo da função não foi preenchida!", type = "error")
      
      return()
    }
    
    tryResetConnection(con,function(coon){
      
      con <<- coon
      
      if(checkifExistNameFunctionEdit(con,funcao$CD_ID_FUNCTION,nome)){
        
        showNotification("O nome já possui nos registros!", type = "error")
        return()
      }
      
      atributo  <- atributos %>% filter(NAME_ATRIBUTO == isolate(input$comboAtributo))

      updateTable(con,'FUNCTION_ATRIBUTO',paste0('CD_ID_FUNCTION = ',funcao$CD_ID_FUNCTION),
      list(
        CD_ID_ATRIBUTO = atributo$CD_ID_ATRIBUTO,
        NAME_FUNCTION  = nome,
        BODY_FUNCTION  = script
      ))
      
      keys <- systemCache$keys()
      keys <- keys[stringr::str_starts(systemCache$keys(),'dataplotcache')]
      sapply(keys, function(x) systemCache$remove(x))
      
      funcao <<- NULL
      funcoes(selectAllFuncao(con))
      sliderPosition(1)
      swiperSlideTo(index = 0)
      sliderPosition(swiperPosition)
      
    })
    
  },ignoreInit = T))
  
  obs$add(observeEvent(input$btActionSair,{
    
    current <- swiperPosition
    
    if(current == 1){
      
      #destroy all observe events
      DBI::dbDisconnect(con)
      obs$destroy()
      obs1$destroy()
      obs2$destroy()
      removeModal()
      callback()
      
    }else{
      sliderPosition(1)
      swiperSlidePrevious()
      sliderPosition(swiperPosition)
    }
    
    
  },ignoreInit = T))
  
}