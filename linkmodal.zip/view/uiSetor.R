uiSetorNew <- function(con,input,output,user,callback,callback.exit){
  
  source('model/SmartObserve.R',local = T)
  obs <- newObserve()
  
  showModal(
    dialogModal(
      title = dialogTitleClose('Novo Setor',function(){
        
        #destroy all observe events
        DBI::dbDisconnect(con)
        obs$destroy()
        removeModal()
        callback.exit()
        
      }),
      size = 'm',
      div(
        shinyjs::inlineCSS("#textNameSetor {text-transform: uppercase;}"),
        textInput('textNameSetor',label = 'Nome',placeholder = 'Digite o nome para o setor'),
        br(),
        panelTitle(title = "Momento",
                   background.color.title = 'white',
                   title.color = 'black',
                   border.color = 'lightgray',
                   children = fluidRow(
                     style = 'padding-top: 10px; padding-left: 15px; padding-right: 15px;',
                     column(6,selectInput('comboTimer',label     = 'Tempo da Reativar',choices = 1:59,selected = 1)),
                     column(6,selectInput('comboUnit', label     = 'Unidade',choices = c("Minuto","Hora"),selected = "Minuto")),
                     column(6,selectInput('comboTimerLook',label = 'Tempo do Passado',choices = 1:59,selected = 10)),
                     column(6,selectInput('comboUnitLook', label = 'Unidade',choices = c("Minuto","Hora","Dia"),selected = "Minuto"))
                   )
        )
      ),
      footer = tagList(shiny::actionButton(inputId = "btSair","Sair"),actionButton('btSalvar','Salvar')))
  )
  
  obs$add(observeEvent(input$btSair,{
    
    #destroy all observe events
    DBI::dbDisconnect(con)
    obs$destroy()
    removeModal()
    callback.exit()
    
  },ignoreInit = T,ignoreNULL = T))
  
  obs$add(observeEvent(input$btSalvar,{
    
    nomeSetor <- toupper(input$textNameSetor)
    
    if(stringi::stri_isempty(stringr::str_trim(nomeSetor))){
      
      showNotification("O nome do setor não foi preenchido!", type = "warning")
      
      return()
    }
    
    if(checkIfexistSetor(con = con,user = user,name = nomeSetor)){
      
      showNotification("O nome do setor já possui nos registros!", type = "warning")
    }
    else{
      
      tryResetConnection(con,function(coon){
        
        con <<- coon
        #check if it has already data of setor
        obj <- list()
        obj$NAME_SETOR                   <- nomeSetor
        obj$TEMPO_REATIVAR_SETOR         <- input$comboTimer
        obj$TEMPO_REATIVAR_UNIDADE_SETOR <- input$comboUnit
        obj$TEMPO_PASSADO_SETOR          <- input$comboTimerLook
        obj$TEMPO_PASSADO_UNIDADE_SETOR  <- input$comboUnitLook
        obj$CD_ID_USER                   <- user$CD_ID_USER
        obj$CHIPS                        <- list()
        obj$CD_ID_SETOR                  <- insertNewSetor(con,user,obj)
        
        #configu novo setor
        callback(obj)
        
        dialogConfirm(
          title = 'Setor criado com sucesso!',
          text = 'Deseja criar novamente um novo Setor?',
          callback = function(status) {
            
            updateTextInput(getDefaultReactiveDomain(),inputId = 'textNameSetor',value = '')
            
            if(!status){
              DBI::dbDisconnect(con)
              obs$destroy()
              callback.exit()
              removeModal()
            }
            
          })
        
      })
    }
    
    
  },ignoreInit = T,ignoreNULL = T))
  
}

uiSetorTable <- function(input,output,user,con,setores,processos,callback){
  
  source('model/SmartObserve.R',local = T)
  obs  <- newObserve()
  
  setor          <- reactiveVal(NULL)
  observeEvents  <- list()
  setores        <- reactiveVal(setores)
  sliderPosition <- reactiveVal(1)
  
  #Modal para Dialog
  showModal(dialogModal(
    title = dialogTitleClose('Registro Setores',function(){
      
      #destroy all observe events
      DBI::dbDisconnect(con)
      obs$destroy()
      swiperDestroy()
      removeModal()
      callback(isolate(setores()))
      
    }),
    size = 'm',
    swiper(id = 'swiperMain',width = '100%',height = '450px',
           swiperSlide(
             style = 'height: 100%; width: 100%; overflow-y: hidden; padding: 5px;',
             uiOutput('slider1')
           ),
           swiperSlide(
             uiOutput('slider2') %>% shinycssloaders::withSpinner(color = 'lightblue')
           )
    ),
    footer = uiOutput('uiFooter'),
    callback = function(size){onResizedWindows(list(height = size$height))}
  ))
  
  output$uiFooter <- renderUI({
    
    current <- sliderPosition()
    
    if(current == 1){
      tagList(actionButton('btActionCancel', label = "Sair"))
    }
    else{
      tagList(actionButton('btActionCancel', label = "Voltar"),actionButton('btActionUpdate', label = "Atualizar"))
    }
    
    
  })
  
  output$slider1 <- renderUI({
    
    output$tableDinamica <- DT::renderDataTable({
      
      # future({
      dataset  <-  setores()
      
      if(length(dataset) == 0) return(NULL)
      
      colunaNames <- c('LINHA','SETOR','VISUALIZAR / EDITAR','REMOVER')
      
      DT::datatable({
        
        dataset %>% 
          mutate_if(is.POSIXct,function(x){ format(x,'%d/%m/%Y %H:%M:%S')})  %>% 
          mutate_if(is.Date,function(x){ format(x,'%d/%m/%Y')}) %>% 
          mutate_if(is.character,toupper) %>% 
          mutate(!!colunaNames[1] := 1:nrow(dataset),
                 !!colunaNames[2] :=  dataset$NAME_SETOR,
                 !!colunaNames[3] :=  sapply(dataset$CD_ID_SETOR, function (x) {
                   
                   as.character(
                     actionButton(
                       paste0('btEdit'),
                       label = '',
                       icon = icon('eye'),
                       onclick = paste0('Shiny.setInputValue(\"editPressedRow\","',x,'",{priority: "event"})'),
                       #style = 'background-color: transparent; color: lightblue; border-solid: none;'
                     )
                   )
                 }),
                 !!colunaNames[4] := sapply(dataset$CD_ID_SETOR, function(x){
                   
                   as.character(
                     actionButton(
                       paste0('btRemove'),
                       label = '',
                       icon = icon('trash'),
                       onclick = paste0('Shiny.setInputValue(\"deletePressedRow\","',x,'",{priority: "event"})'),
                       #style = 'background-color: transparent; color: lightblue; border-solid: none;'
                     )
                   )
                   
                 })
                 
          ) %>% select(colunaNames) %>% arrange(colunaNames[2])
      }, 
      class = 'cell-border stripe',
      extensions = 'Scroller',
      options = list(
        language = list(url = 'js/table/translate.json'),
        dom = 't',
        bSort=FALSE,
        columnDefs = list(list(visible=FALSE, targets=c(0)),list(className = 'dt-center', targets = "_all"),list(width = '75px',targets = c(1,4)),list(width = 'autos',targets = c(3))),
        deferRender = TRUE,
        scroller = FALSE,
        fixedHeader = TRUE,
        scrollX = TRUE,
        scrollY = '380px'
      ),
      escape = F,
      selection = 'none',
      )  %>% DT::formatStyle(colnames(result), cursor = 'pointer')
      
    })
    
    div(
      style = 'border-style: solid; border-color: white; border-width: 1px; overflow-x: auto;',
      DT::dataTableOutput(outputId = 'tableDinamica')
    )
    
  })
  
  output$slider2 <- renderUI({
    
    req(setor())
    
    setor <- setor()
    
    tagList(
      h4('Edição'),
      shinyjs::inlineCSS("#textNameSetor {text-transform: uppercase;}"),
      textInput('textNameSetor',label = 'Nome',value = setor$NAME_SETOR,placeholder = 'Digite o nome para o setor'),
      br(),
      panelTitle(title = "Momento",
                 background.color.title = 'white',
                 title.color = 'black',
                 border.color = 'lightgray',
                 children = fluidRow(
                   style = 'padding-top: 10px; padding-left: 15px; padding-right: 15px;',
                   column(6,selectInput('comboTimer',label     = 'Tempo da Reativar',choices = 1:60,selected = setor$TEMPO_REATIVAR_SETOR)),
                   column(6,selectInput('comboUnit', label     = 'Unidade',choices = c("Minuto","Hora"),selected = setor$TEMPO_REATIVAR_UNIDADE_SETOR)),
                   column(6,selectInput('comboTimerLook',label = 'Tempo do Passado',choices = 1:60,selected = setor$TEMPO_PASSADO_SETOR)),
                   column(6,selectInput('comboUnitLook', label = 'Unidade',choices = c("Minuto","Hora","Dia"),selected = setor$TEMPO_PASSADO_UNIDADE_SETOR))
                 )
      )
    )
    
  })
  
  obs$add(observeEvent(input$editPressedRow,{
    
    setor(isolate(setores()) %>% filter(CD_ID_SETOR == input$editPressedRow))

    swiperSlideNext()
    sliderPosition(swiperPosition)
    
  },ignoreInit = T))
  
  obs$add(observeEvent(input$deletePressedRow,{
    
    setor <- isolate(setores()) %>% filter(CD_ID_SETOR == input$deletePressedRow)

    messageAlerta(input,
                  title   = paste0('Todos os processos ligado a esse setor será excluido'),
                  message = paste0('Deseja realmente excluir o setor ',setor$NAME_SETOR,"?"),
                  callback.no = function(){
                    
                  },
                  callback.yes = function(){
                    
                    tryResetConnection(con,function(conn){
                      
                      con <<- conn
                      #remove Database setor
                      DBI::dbExecute(con,paste0('DELETE FROM SETOR WHERE CD_ID_SETOR = ',setor$CD_ID_SETOR))
                     
                      setores.aux <- setores() %>% filter(CD_ID_SETOR != setor$CD_ID_SETOR)
                      
                      #Destroi o processo do setor
                      process <- rlist::list.filter(processos,id == setor$CD_ID_SETOR)[[1]]
                      process$destroy(TRUE)
                      
                      #remove tab dos dashboard dos setores
                      removeTab(inputId = 'tabsetSetor',target = as.character(setor$CD_ID_SETOR))
                      
                      if(length(setores.aux) > 0){
                        
                        setores(setores.aux)
                      }
                      else{
                        #destroy all observe events
                        DBI::dbDisconnect(con)
                        #exit do dialog
                        obs$destroy()
                        removeModal()
                        callback(NULL)
                      }
                      
                      
                    })
                    
                    
                  })
    
  },ignoreInit = T))
  
  obs$add(observeEvent(input$btActionCancel,{
    
    current <- swiperPosition
    
    if(current == 1){
      #destroy all observe events
      DBI::dbDisconnect(con)
      obs$destroy()
      swiperDestroy()
      removeModal()
      callback(isolate(setores()))
    }
    else{
      
      shinyjs::delay(1000,{
        setor(NULL)
      })
      
      swiperSlidePrevious()
      sliderPosition(swiperPosition)
    }
    
  },ignoreInit = T))
  
  obs$add(observeEvent(input$btActionUpdate,{
    
    setor                              <- setor()
    setor$NAME_SETOR                   <- toupper(input$textNameSetor)
    setor$TEMPO_REATIVAR_SETOR         <- input$comboTimer
    setor$TEMPO_REATIVAR_UNIDADE_SETOR <- input$comboUnit
    setor$TEMPO_PASSADO_SETOR          <- input$comboTimerLook
    setor$TEMPO_PASSADO_UNIDADE_SETOR  <- input$comboUnitLook
    
    tryResetConnection(con,function(conn){
      
      con <<- conn
      
      updateSetor(conn,setor)
      #load todos os setores
      setores(selectSetoresOnly(conn,user))
      
      process <- rlist::list.filter(processos,id == setor$CD_ID_SETOR)[[1]]
      process$update(setor)
      
      swiperSlidePrevious()
      sliderPosition(swiperPosition)
      
    })
    
  },ignoreInit = T))
  
}

uiLayout <- function(con,input,output,setores,plots,callback){
  
  source('model/SmartObserve.R',local = T)
  obs <- newObserve()
  
  selectplot   <- NULL
  setor        <- NULL
  namesSetores <- setores$NAME_SETOR

  if(nrow(plots) > 0){
    
    showModal(
      dialogModal(
        title = dialogTitleClose('Layout Setor',function(){
          
          #destroy all observe events
          DBI::dbDisconnect(con)
          obs$destroy()
          removeModal()
          callback(NULL,0)
          
        }),
        size = 's',
        div(
          selectInput('comboSetorLayout',label = 'Setor',choices = namesSetores),
          uiOutput(
            outputId = 'containerPlot',
            style = 'padding-left: 15px; padding-right: 15px;',
          )
        ),
        footer = tagList(actionButton(inputId = "btSair","Sair"),actionButton('btSalvar','Salvar')))
    )
    
    output$containerPlot <- renderUI({
      
      setor      <<- setores %>% filter(NAME_SETOR == input$comboSetorLayout)
      selectplot <<- plots %>% filter(CD_ID_SETOR == setor$CD_ID_SETOR)
      namesPlot  <-  selectplot$TITLE_PLOT
      names(namesPlot) <- selectplot$CD_ID_PLOT
      
      sortable::bucket_list(
        header = "Layout Posicao grafico",
        orientation = 'horizontal',
        sortable::add_rank_list(
          input_id = 'posicaoPlots',
          text   = "Ordenação",
          labels =  namesPlot
        )
      )
      
    })
    
    obs$add(observeEvent(input$btSair,{
      
      #destroy all observe events
      DBI::dbDisconnect(con)
      obs$destroy()
      removeModal()
      callback(NULL,0)
      
    },ignoreInit = T))
    
    obs$add(observeEvent(input$btSalvar,{
      
      ordenPlot  <- isolate(input$posicaoPlots)
      plot.ordem <- foreach(
        ordem = ordenPlot,
        .combine = rbind,
        .inorder = TRUE
      ) %do%{
        selectplot %>% filter(CD_ID_PLOT == ordem)
      }
      
      tryResetConnection(con,function(conn){
        
        con <<- conn
        
        for (index in 1:nrow(plot.ordem)) {
          
          plot <- plot.ordem[index,]
          #update ordem
          updateTable(con,'PLOT',paste0("CD_ID_PLOT = ",plot$CD_ID_PLOT),list(ORDEM_PLOT = index))
        }
        
        showNotification("Layout foi salvo com sucesso!", type = "message")
        callback(list(CD_ID_SETOR = plot$CD_ID_SETOR,plot = plot.ordem$CD_ID_PLOT),1)
        
      })
      
    },ignoreInit = T))
    
  }else{
    callback(NULL,-1)
  }
  
}
