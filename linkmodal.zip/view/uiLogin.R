
uiLogin <- function(input,
                    output,
                    session,
                    translate,
                    callback,
                    btCancel = F) {
  
  source('model/SmartObserve.R',local = T)
  obs <- newObserve()
  
  btExist <- NULL

  if(btCancel)
    btExist <- actionButton('loginBtSair', label = "Cancelar")
  
  showModal(modalDialog(
    title = 'Login',
    size = "s",
    div(
      shinyjs::inlineCSS("#loginEditNome {text-transform: uppercase;}"),
      style = "height: auto;",
      shiny::textInput("loginEditNome", label = "Nome",value = 'MASTER',placeholder = 'DIGITE USUÁRIO'),
      shiny::passwordInput("loginEditPassword", label = "Senha",value = 'master',placeholder = 'DIGITE A SENHA')
    ),
    footer = tagList(btExist,actionButton('loginBtLogar', label = "Entrar"))
  ))
  
  enterLogin <- function(){
    
    source('control/Database.R',encoding  = "UTF-8",local = T)
    
    con <- newConnection()
    
    tryResetConnection(con,function(con){
      
      nome  <- toupper(input$loginEditNome)
      senha <- input$loginEditPassword
      
      if (stringi::stri_isempty(stringr::str_trim(nome))) {
        #showNotification(translate$t("O campo do nome esta vázio!"),action = NULL, type = "warnning")
        showNotification(translate$t("O campo do nome esta vázio!"),
                         action = NULL,
                         type = 'warning')
        return(NULL)
      }
      else if (stringi::stri_isempty(stringr::str_trim(senha))) {
        showNotification(translate$t("O campo da senha esta vázio!"), type = "warning")
        return(NULL)
      }
      
      user <- loginUser(con,nome,senha)
      
      if(is.null(user))
      {
        showNotification(translate$t("Permissão de autenticação negada!"), type = "warning")
        return(NULL)
      }
      else if (nrow(user) == 0) {
        showNotification(translate$t("Permissão de autenticação negada!"), type = "warning")
        return(NULL)
      }
      # else if (user$FG_ONLINE_USER == 1) {
      #   showNotification(translate$t("Usuário já esta logado!"), type = "warning")
      #   return(NULL)
      # }
      
      shinyjs::runjs("var audio = document.getElementById('soundLoginOn');
                     audio.volume = 0.2;
                     audio.play();")
      
      # #render meny by user type
      # if(user$CD_ID_TIPO == 1) #MASTER
      #   configMenuMaster(output)
      # else if(user$CD_ID_TIPO == 2) # Administrador
      #   configMenuAdministrador(output)
      # else # Analista
      #   configMenuAnalista(output)
      
      configMenuAdministrador(output)
      
      obs$destroy()
      removeModal()
      
      actionWebUser(function(){
        
        callback(con,user)
        updateUserOnline(con,user,TRUE)
        DBI::dbDisconnect(con)
        shinyjs::delay(1000,showNotification(translate$t("Login foi sucedido com sucesso!"), type = "warning"))
        
        
      },auto.remove = T)
      
    })
    
  }
  
  obs$add(observeEvent(input$loginBtLogar,{
    
    enterLogin()
    
  },ignoreInit = T))
  
  obs$add(observeEvent(input$loginBtSair,{
    
    obs$destroy()
    removeModal()
    
  },ignoreInit = T))

  
}

configMenuMaster <- function(output){
  
  output$sidebarMenu <- renderUI({
    
    tagList(
      sidebarMenu(
        id = 'tabCerebro',
        menuItem(
          translate$t("Condição logica"),
          icon = icon('brain'),
          menuItem(
            text = 'Protocolo',
            icon = icon('box'),
            MenuSubItem(id = 'protocoloNew',text  = translate$t("Novo")),
            MenuSubItem(id = 'protocoloTable',text  = translate$t("Lista"))
          ),
          menuItem(
            text = 'Modelo',
            icon = icon('puzzle-piece'),
            MenuSubItem(id = 'modeloNew',text  = translate$t("Novo")),
            MenuSubItem(id = 'modeloTable',text  = translate$t("Lista"))
          ),
          menuItem(
            text = 'Função',
            icon = icon('square-root-alt'),
            MenuSubItem(id = 'funcaoNew',text  = translate$t("Novo")),
            MenuSubItem(id = 'funcaoTable',text  = translate$t("Lista"))
          )
        )
      ),
      sidebarMenu(
        menuItem(
          translate$t("Usuário"),
          icon = icon('user'),
          MenuSubItem(id = 'userPerfiel',text = 'Perfil'),
          MenuSubItem(id = 'userNew',text  = translate$t("Novo")),
          MenuSubItem(id = 'userLista',text  = translate$t("Lista"))
        )
      ),
      sidebarMenu(
        id = 'menuLogout',
        MenuItem(
          id   = 'menulogout',
          text = 'Logout',
          icon = icon('sign-out-alt')
        )
      )
    )
    
  })
  
  output$painelTabSetores  <- NULL
  
}

configMenuAdministrador <- function(output){
  
  output$sidebarMenu <- renderUI({
    
    tagList(
      # sidebarMenu(
      #   id = 'tabs',
      #   menuItem(
      #     'Dashboard',
      #     icon = icon('tachometer-alt'),
      #     MenuSubItem(id = 'dashCentral',text = 'Central',tabName   = 'tabCentral',selected = T),
      #     MenuSubItem(id = 'dashSetores',text = 'Setores',tabName   = 'tabSetor')
      #   )),
      sidebarMenu(
        menuItem(
          text = 'Setores',
          icon = icon('server'),
          menuItem(
            text = 'Registro',
            icon = icon('table'),
            MenuSubItem(id = 'setorNew',text  = translate$t("Novo")),
            MenuSubItem(id = 'setorTable',text  = translate$t("Lista")),
            MenuSubItem(id = 'setorLayout',text  = translate$t("Layout"))
          )
        ) %>% tagAppendAttributes(style = 'z-index: 999999;')
      ),
      sidebarMenu(
        menuItem(
          text = 'Grafico',
          icon = icon('chart-line'),
          menuItem(
            text = 'Registro',
            icon = icon('table'),
            MenuSubItem(id = 'plotNew',text  = translate$t("Novo")),
            MenuSubItem(id = 'plotTable',text  = translate$t("Lista")),
            MenuSubItem(id = 'plotTools',text  = translate$t("Ferramenta"))
          )
        )
      ),
      sidebarMenu(
        menuItem(
          text = 'Objetos e Estruturas',
          icon = icon('cubes'),
          menuItem(
            text = 'Objeto',
            icon = icon('cube'),
            MenuSubItem(id = 'objetoNew',text  = translate$t("Novo")),
            MenuSubItem(id = 'objetoTable',text  = translate$t("Lista"))
          ),
          menuItem(
            text = 'Estrutura',
            icon = icon('puzzle-piece'),
            MenuSubItem(id = 'modeloNew',text   = translate$t("Novo")),
            MenuSubItem(id = 'modeloTable',text  = translate$t("Lista"))
          )
        )
      ),
      sidebarMenu(
        menuItem(
          text = 'Servidores',
          icon = icon('database'),
          menuItem(
            text = 'Servidor',
            icon = icon('server'),
            MenuSubItem(id = 'serverNew',text  = translate$t("Novo")),
            MenuSubItem(id = 'serverTable',text  = translate$t("Lista"))
          )
        )
      ),
      sidebarMenu(
        menuItem(
          text = 'Sistema',
          icon = icon('desktop'),
          menuItem(
            text = 'Alarme',
            icon = icon('bell'),
            MenuSubItem(id = 'alarmeNew',text  = translate$t("Novo")),
            MenuSubItem(id = 'alarmeTable',text  = translate$t("Lista"))
          ),
          menuItem(
            text = 'Função',
            icon = icon('square-root-alt'),
            MenuSubItem(id = 'funcaoNew',text  = translate$t("Novo")),
            MenuSubItem(id = 'funcaoTable',text  = translate$t("Lista"))
          )
        )
      ),
      sidebarMenu(
        menuItem(
          translate$t("Usuário"),
          icon = icon('user'),
          MenuSubItem(id = 'userPerfiel',text = 'Perfil'),
          MenuSubItem(id = 'userNew',text  = translate$t("Novo")),
          MenuSubItem(id = 'userTable',text  = translate$t("Lista"))
        ),
        menuItem(
          text = 'Contatos',
          icon = icon('users'),
          menuItem(
            text = 'Registro',
            icon = icon('table'),
            MenuSubItem(id = 'contatoNew',text   = translate$t("Novo")),
            MenuSubItem(id = 'contatoTable',text  = translate$t("Lista"))
          )
        )
      ),
      sidebarMenu(
        id = 'menuLogout',
        MenuItem(
          id   = 'menulogout',
          text = 'Logout',
          tabName = 'logoutuser',
          icon = icon('sign-out-alt')
        )
      )
    )
    
  })
  
  output$painelTabSetores  <- renderUI({
    
    # div(style = 'padding: 5px; padding-top: 50px;',
    #     tabItems(
    #       tabItem(tabName = 'tabCentral',h4("Teste.......")),
    #       tabItem(tabName ='tabSetor',tabsetPanel(id = 'tabsetSetor'))
    #     ))
    div(style = 'padding: 5px; padding-top: 50px;',tabsetPanel(id = 'tabsetSetor'))
  })
  
}

configMenuAnalista <- function(output){
  
  output$sidebarMenu <- renderUI({
    
    tagList(
      # sidebarMenu(
      #   menuItem(
      #     'Dashboard',
      #     icon = icon('tachometer-alt'),
      #     #MenuSubItem(id = 'dashCentral',text = 'Central',tabName   = 'tabCentral'),
      #     MenuSubItem(id = 'dashSetores',text = 'Setores',tabName   = 'tabSetor',selected = T)
      #   )),
      sidebarMenu(
        menuItem(
          translate$t("Usuário"),
          icon = icon('user'),
          MenuSubItem(translate$t("Perfil"),text = 'perfil')
        )
      ),
      sidebarMenu(
        id = 'menuLogout',
        MenuItem(
          id   = 'menulogout',
          text = 'Logout',
          tabName = 'logoutuser',
          icon = icon('sign-out-alt')
        )
      )
    )})
  
  output$painelTabSetores  <- renderUI({
    
    div(style = 'padding: 5px; padding-top: 50px;',
        tabsetPanel(id = 'tabsetSetor',selected = T)
    )
    
  })
  
}
