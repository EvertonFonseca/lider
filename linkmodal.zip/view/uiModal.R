uiEstruturaNew <- function(con,input,output,servers,typedatas,timezones,callback){
  
  source('model/SmartObserve.R',local = T)
  obs             <- newObserve()
  obsModal        <- newObserve()
  position        <- reactiveVal(1)
  con.server      <- NULL
  atributo        <- reactiveVal()
  object.dataset  <- list(colunas = NULL,tipo.data = NULL)
  vetorLogica     <- getVetorLogico()
  listUpdateTable <- list()
  atributo.tmp    <- NULL
  resete          <- reactiveVal()
  step.2          <- reactiveVal()
  logicas         <- selectAllCondicaoQualitativa(con)
  
  id <- 'dialogObj'
  cssStyle <- list()
  cssStyle[[paste0(' #parent',id,' .modal-dialog')]]  <- paste0('height: 80% !important;')
  cssStyle[[paste0(' #parent',id,' .modal-content')]] <- paste0('width: 100% !important; height: 100% !important;')
  cssStyle[[paste0(' #parent',id,' .modal-body')]]    <- paste0('width: 100% !important; height: calc(100% - 57px - 65px) !important; overflow-y: hidden;')
  
  showModal(
    shiny::div(
      id = paste0('parent', id),
      style = paste0("height: 90%;"),
      shinyjs::inlineCSS(cssStyle),
      dialogModal(
        title = dialogTitleClose('Nova Estrutura',function(){
          
          #destroy all observe events
          DBI::dbDisconnect(con)
          
          if(!is.null(con.server))
            DBI::dbDisconnect(con.server)
          
          obs$destroy()
          obsModal$destroy()
          removeModal()
          callback()
          
        }),
        size = 'm',
        swiper(id = 'swiperMainModal',
               parent.style = 'height: 100%; width: 100%;',
               width = '100%',
               height = '100%',
               swiperSlideUi(
                 outputId = 'slider1',
                 style = 'height: 100%; width: 100%; overflow-y: hidden; overflow-x: hidden;',
                 uiOutput('slider1',style = 'width: 100%; height: 100%; padding: 5px;')
               ),
               swiperSlideUi(
                 outputId = 'slider2',
                 style = 'height: 100%; width: 100%; overflow-y: hidden; overflow-x: hidden;',
                 uiOutput('slider2',style = 'width: 100%; height: 100%; padding: 5px; display: none;  overflow-y: hidden; overflow-x: hidden;')
               ),
               swiperSlideUi(
                 outputId = 'slider3',
                 style = 'height: 100%; width: 100%;',
                 uiOutput('slider3',style = 'height: 100%; width: 100%; overflow-y: auto; display: none;') 
               )
        ),
        footer = uiOutput('uiFooter'))))
  
  output$uiFooter <- renderUI({
    
    current <- position()
    
    if(current == 1){
      tagList(actionButton(inputId = "btSair","Sair"),actionButton('btSalvar','Avançar'))
    }
    else{
      tagList(actionButton(inputId = "btSair","Voltar"),actionButton('btSalvar','Inserir'))
    }
    
  })
  
  obs$add(observeEvent(input$btSalvar,{
    
    current <- swiperPosition
    
    if(current == 1){
      
      tryResetConnection(con,function(coon){
        
        con <<- coon
        
        name <- toupper(isolate(input$textModal))
        
        if(stringi::stri_isempty(stringr::str_trim(name))){
          
          showNotification("O nome da estrutura não foi preenchido!", type = "error")
          return()
        }
        else if(checkifExistNameModel(con,name)){
          showNotification("O nome da estrutura já existe nos registros!", type = "error")
          return()
        }
        
        server <- servers %>% filter(TITLE_DB == isolate(input$comboServer))
        
        actionWebUser(function(){
          
          driver   <- server$NAME_DRIVER
          host     <- server$HOST_DB
          port     <- server$PORT_DB
          user     <- server$USER_DB
          pass     <- server$PASS_DB
          dbname   <- server$NAME_DB
          
          con.server <<- connectarDatabase(
            driver = driver,
            host   = host,
            port   = port,
            dbname = dbname,
            user   = user,
            pass   = pass
          )
          
          if(!is.null(con.server)){
            
            tryCatch({
              
              df <- DBI::dbGetQuery(con.server,isolate(input$textoQuery),n = 1)
              
              object.dataset$atributos <<- colnames(df)
              object.dataset$tipo.data <<- listTypeDataStr(con.server,df)
              object.dataset$length    <<- length(object.dataset$atributos)
              
              #remove
              remove(df)
              
              step.2(Sys.time())
              swiperSlideNext()
              position(swiperPosition)
              
            },error = function(e){
              
              showNotification(as.character(e), type = "error")
              
            })
          }
          else{
            showNotification("Autenticação não foi valida!", type = "error")
          }
          
        },auto.remove = TRUE)
        
      })
      
    }else if(current == 2){
      
      #save all struct
      name          <- toupper(isolate(input$textModal))
      query         <- isolate(input$textoQuery)
      id.principal  <- isolate(input$comboKey)
      id.timeline   <- isolate(input$comboTimeline)
      server        <- servers %>% filter(TITLE_DB    == isolate(input$comboServer))
      timezone      <- isolate(input$comboTimezone)
      
      if(!checkIfTimelineIsValid(input,object.dataset,id.timeline)){
        showNotification("Atributo timeline não é um tipo de dado DATE ou TIMESTAMP!", type = "error")
        return()
      }
      
      status <- tryTransation(con,{
        
        #id
        id <- nextSequenciaID(con,'OBJECT_STRUCT')
        
        #insert struct
        insertTable(con,'OBJECT_STRUCT',list(
          CD_ID_STRUCT  = id,
          NAME_STRUCT   = name,
          ID_ATRIBUTO   = id.principal,
          TIME_ATRIBUTO = id.timeline,
          CD_ID_DB      = server$CD_ID_DB,
          QUERY_STRUCT  = query,
          TIME_ZONE     = timezone
        ))
        
        #loop by every attribute
        for (i in 1:object.dataset$length) {
          
          id.atribute  <- nextSequenciaID(con,'ATRIBUTO')
          atributo     <- input[[paste0('atributo_',i)]]
          typedata     <- typedatas %>% filter(NAME_DATA == isolate(input[[paste0('comboTipodados_',i)]]))
          logicas      <- listUpdateTable[[i]]() %>% drop_na()
          n            <- nrow(logicas)
          status       <- input[[paste0('checkboxAtributoAtivo_',i)]]
          
          insertTable(con,'ATRIBUTO',list(
            CD_ID_ATRIBUTO    = id.atribute,
            CD_ID_STRUCT      = id,
            CD_ID_DATA        = typedata$CD_ID_DATA,
            NAME_ATRIBUTO     = atributo,
            POSITION_ATRIBUTO = i,
            FG_ATIVO          = status
          ))
          
          if(n == 0) next
          
          for(k in 1:n)
          {
            insertTable(con,'ATRIBUTO_QUALITATIVO',list(
              COMANDO_QUAT    = logicas$LOGICA[k],
              CLASSE_QUAT     = logicas$CLASSE[k],
              CD_ID_ATRIBUTO  = id.atribute
            ))
          }
          
        }# end for
        
      })
      
      if(status){
        
        dialogConfirm(
          title = 'Estrutura criado com sucesso!',
          text = 'Deseja criar novamente um novo estrutura?',
          callback = function(status) {
            
            if(!status){
              #destroy all observe events
              DBI::dbDisconnect(con)
              if(!is.null(con.server))
                DBI::dbDisconnect(con.server)
              
              obs$destroy()
              obsModal$destroy()
              removeModal()
              callback()
            }
            else
            {
              if(!is.null(con.server))
                DBI::dbDisconnect(con.server)
              
              resete(Sys.time())
              con.server <<- NULL
              position(1)
              swiperSlideTo(index = 0)  
            }
            
          })
        
      }
      else{
        showNotification("Não foi possivel realizar essa operação falha na conexão!", type = "error")
      }
      
    }
    else if(current == 3){
      
      if(length(input$resultado) == 0){
        showNotification("Nenhuma logica foi construida!", type = "error")
        return()
      }
      if(stringi::stri_isempty(stringr::str_trim(input$textClassificacao))){
        showNotification("Nenhuma classe foi preenchida!", type = "error")
        return()
      }
      
      atributo.tmp$comandos <<- input$resultado
      atributo.tmp$classe   <<- toupper(input$textClassificacao)
      atributo.tmp$reactive(as.numeric(Sys.time()))
      
      position(position() - 1)
      swiperSlidePrevious()  
    }
    
  },ignoreInit = T))
  
  obs$add(observeEvent(input$btSair,{
    
    current <- swiperPosition
    
    if(current == 1){
      
      #destroy all observe events
      DBI::dbDisconnect(con)
      if(!is.null(con.server))
        DBI::dbDisconnect(con.server)
      
      obs$destroy()
      obsModal$destroy()
      removeModal()
      callback()
      
    }else if(current == 2){
      
      if(!is.null(con.server))
        DBI::dbDisconnect(con.server)
      
      con.server <<- NULL
      position(1)
      swiperSlidePrevious()   
      
    }
    else{
      
      atributo(NULL)
      position(2)
      swiperSlidePrevious()  
    }
    
  },ignoreInit = T))
  
  obs$add(observeEvent(input$importFile,{
    
    tryCatch({
      file <- input$importFile$datapath
      updateTextAreaInput(inputId = 'textoQuery',value = readr::read_file(file))
    },error = function(e) print(e))
    
  },ignoreInit = TRUE))
  
  output$slider1  <- renderUI({
    
    resete()
    
    div(
      style = 'width: 100%; height: 90%;',
      fluidRow(
        shinyjs::inlineCSS(paste0("#textModal"," {text-transform: uppercase;}")),
        column(6,textInput('textModal',label = "Nome",placeholder = 'Digite o nome para modelo')),
        column(6,selectInput('comboServer','Servidor',choices = servers$TITLE_DB))
      ),
      tagList(
        fileInput(inputId = "importFile",label = "Arquivo Query",multiple = F,accept = c('.sql'),placeholder = 'Seleciona o arquivo',width = '100%'),
        textAreaInput('textoQuery',
                      'Estrutura Query',
                      value = '',
                      placeholder = 'Entre com estrutura da quary.',
                      height = '100%',
                      resize = "none") %>% 
          shiny::tagAppendAttributes(style = 'width: 100%; font-weight: bold; height: 65%;')
      ))
    
  })
  
  output$slider2  <- renderUI({
    
    req(step.2())
    
    ID_ROW   <- NULL
    obsModal$clear()
    #lista update
    listUpdateTable <<- list()
    
    output$renderInputs <- renderUI({
      
      lapply(1:object.dataset$length, function(i){
        
        atributo.data <- object.dataset$atributos[i]
        tipoDado.data <- object.dataset$tipo.data[i]
        updateTable   <- reactiveVal(NULL)
        ID_ROW        <- NULL
        
        tabelasLogicas   <- reactiveVal(data.frame(
          CD_ID_LOGIC = NA,
          FLAG   = NA,
          ID     = NA,
          ATRIBUTO = NA,
          LINHA  = NA,
          LOGICA = NA,
          CLASSE = NA,
          REMOVER = NA
          
        ))
        
        #add global
        listUpdateTable <<- listUpdateTable %>% rlist::list.append(tabelasLogicas)
        
        #render tabela logica
        output[[paste0('container_',i)]] <-  renderUI({
          
          req(updateTable())
          
          if(updateTable() > -1){
            
            atributo <- atributo.tmp
            #reativa a render
            comando  <- atributo$comandos
            comandos <- paste(comando,collapse = ' ')
            classe   <- atributo$classe
            
            if(!atributo$editable){
              
              ID       <- list()
              ID       <- paste0(i,address(ID))
              
              table   <- isolate(tabelasLogicas())
              table   <- table %>% drop_na()
              
              linha   <- ifelse(is.null(table), 1, nrow(table) + 1)
              #update table
              tabelasLogicas(rbind(table,
                                   data.frame(
                                     CD_ID_LOGIC = 0,
                                     FLAG   = FALSE,
                                     ID     = ID,
                                     ATRIBUTO = i,
                                     LINHA  = linha,
                                     LOGICA = comandos,
                                     CLASSE = classe,
                                     EDITAR = as.character(
                                       actionButton(
                                         paste0('btEditar',i,ID),
                                         label = '',
                                         icon = icon('edit'),
                                         onclick = paste0('Shiny.setInputValue("',paste0("editarPressedRow",i),'","',ID,'");'),
                                         #style = 'background-color: transparent; color: lightblue; border-solid: none;'
                                       )
                                     ),
                                     REMOVER = as.character(
                                       actionButton(
                                         paste0('btRemove',i,ID),
                                         label = '',
                                         icon = icon('trash'),
                                         onclick = paste0('Shiny.setInputValue("',paste0("deletePressedRow",i),'","',ID,'");'),
                                         #style = 'background-color: transparent; color: lightblue; border-solid: none;'
                                       )
                                     )
                                     
                                   )))
              
              #destroy obj tmp ATRIBUTO
              atributo.tmp <<- NULL
              
            }else{
              
              #Editable row of table logicas
              table     <- isolate(tabelasLogicas())
              aux       <- table %>% filter(ID == ID_ROW) %>% mutate(LOGICA = comandos,CLASSE = classe)
              table[which(table$ID == ID_ROW),] <- aux
              
              freezeReactiveValue(input,"tabelasLogicas")
              tabelasLogicas(table)
            }
            
            ID_ROW   <<- NULL
            
          }
          
          output[[paste0('logictable',i)]] <- DT::renderDataTable({
            
            df   <- tabelasLogicas()
            df   <- df %>% drop_na()
            
            if(nrow(df) == 0)
            {
              shinyjs::hide(paste0('logictable',i))
            }
            else{
              shinyjs::show(paste0('logictable',i))
            }
            
            if(!is.null(df))
              df <- tabelasLogicas() %>% select(-CD_ID_LOGIC,-FLAG,-ATRIBUTO,-ID)
            
            DT::datatable(df,
                          class = 'cell-border stripe',
                          extensions = 'Scroller',
                          options = list(
                            dom = 't',
                            bSort=FALSE,
                            columnDefs = list(list(visible=FALSE, targets=c(0)),list(className = 'dt-center', targets = "_all")),
                            deferRender = TRUE,
                            scroller = FALSE
                          ),
                          escape = F,
                          selection = 'none',
            )  %>% DT::formatStyle(colnames(result), cursor = 'pointer')
            
          })
          
          fluidRow(
            column(12,div(
              style = 'border-style: solid; border-color: white; border-width: 1px;',
              DT::dataTableOutput(paste0('logictable',i))
            )),
            column(12,br())
          )
          
        })#end
        
        #events qualitativos
        obsModal$add(observeEvent(input[[paste0('atributoLogic',i)]],{
          
          nameatributo <- toupper(isolate(input[[paste0('atributo_', i)]]))
          
          if(nrow(logicas) > 0)
            logicas <- logicas %>%
                         mutate(
                           COMANDO_QUAT = stringr::str_replace_all(
                             COMANDO_QUAT,
                             changeAnotherNameSensorLogica(COMANDO_QUAT, vetorLogica),
                             nameatributo
                           )
                         )
          
          atributo.tmp <<- list(
            name = toupper(input[[paste0('atributo_', i)]]),
            logicas = c('NENHUMA LOGICA',logicas$COMANDO_QUAT),
            index = i,
            editable = FALSE,
            classe = '',
            reactive = updateTable
          )
          
          swiperSlideNext()
          position(swiperPosition)
          
        },ignoreInit = T))
        
        obsModal$add(observeEvent(input[[paste0("editarPressedRow",i)]],{
          
          req(tabelasLogicas(),input[[paste0("editarPressedRow",i)]])
          
          ID_ROW      <<- isolate(input[[paste0("editarPressedRow",i)]])
          
          nameatributo <- toupper(isolate(input[[paste0('atributo_', i)]]))
          
          table        <- isolate(tabelasLogicas())
          aux          <- table %>% filter(ID == ID_ROW)
          comando      <- stringr::str_split(aux$LOGICA,' ')[[1]]
          
          if(!is.null(atributo.tmp))
            remove(atributo.tmp)

          if(nrow(logicas) > 0)
            logicas <- logicas %>%
            mutate(
              COMANDO_QUAT = stringr::str_replace_all(
                COMANDO_QUAT,
                changeAnotherNameSensorLogica(COMANDO_QUAT, vetorLogica),
                nameatributo
              )
            )
          
          atributo.tmp <<- list(
            name     = nameatributo,
            logicas  = c('NENHUMA LOGICA',logicas$COMANDO_QUAT),
            index    = i,
            editable = TRUE,
            classe   = aux$CLASSE,
            comandos = comando,
            reactive = updateTable
          )
          
          position(3)
          swiperSlideNext()
          shinySetInputValue(paste0("editarPressedRow",i),NULL)
          
        },ignoreInit = T,ignoreNULL = T))
        
        obsModal$add(observeEvent(input[[paste0("deletePressedRow",i)]],{
          
          req(tabelasLogicas(),input[[paste0("deletePressedRow",i)]])
          
          ID_ROW    <- isolate(input[[paste0("deletePressedRow",i)]])
          table     <- isolate(tabelasLogicas())
          aux       <- table %>% filter(ID == ID_ROW)
          
          messageAlerta(input,
                        title   = paste0('A linha ',aux$LINHA,' será removida da tabela de condições!'),
                        message = paste0('Deseja realmente remover a linha ',aux$LINHA,"?"),
                        callback.no = function(){
                          
                        },
                        callback.yes = function(){
                          
                          table <- table[-which(ID_ROW == table$ID),]
                          
                          if(nrow(table) == 0)
                            tabelasLogicas(data.frame(
                              ID     = NA,
                              ATRIBUTO = NA,
                              LINHA  = NA,
                              LOGICA = NA,
                              CLASSE = NA,
                              REMOVER = NA
                            ))
                          else
                            tabelasLogicas(table)
                        })
          
          freezeReactiveValue(input,paste0("deletePressedRow",i))
          shinyjs::runjs(paste0("Shiny.setInputValue('",paste0("deletePressedRow",i),"',null);"))
          
        },ignoreInit = T,ignoreNULL = T))
        
        #component
        fluidRow(
          shinyjs::inlineCSS(paste0("#",paste0('Atributo_',i)," {text-transform: uppercase;}")),
          column(12,splitLayout(
            tagList(
              tags$label('Ativar',style = 'font-size: 15px;'),
              prettyToggle(
                inputId = paste0('checkboxAtributoAtivo_',i),
                label_on = "Sim",
                label_off = "Não", 
                outline = TRUE,
                plain = TRUE,
                value = TRUE,
                icon_on = icon("thumbs-up"),
                icon_off = icon("thumbs-down"),
                bigger = T,
                width = 'auto'
              )
            ),
            textInput(inputId = paste0('atributo_',i),label = paste0('Atributo: ',i),value   = atributo.data,width = '100%') %>% tagAppendAttributesFind(2,readonly = 'true'),
            selectInput(paste0('comboTipodados_',i),label = 'Tipo dado',choices = typedatas$NAME_DATA,selected = tipoDado.data),
            actionButton(paste0('atributoLogic',i),label = '',icon = icon('lightbulb'),style = 'margin-top: 25px;'),
            cellWidths = c('50px','255px','150px','50px')
          )),
          column(12,uiOutput(paste0('container_',i),style = 'padding: 5px;'))
        )
        
      })
      
    })
    
    #render
    div(
      style = 'padding: 15px; height: 100%;',
      selectInput('comboKey',label = 'Atributo ID',choices = object.dataset$atributos,width = '100%'),
      fluidRow(
        column(6,selectInput('comboTimeline',label = 'Atributo Timeline',choices = object.dataset$atributos,width = '100%')),
        column(6,selectInput('comboTimezone',label = 'Time Zone',choices = timezones$NAME_ZONE,selected = 'America/Sao_Paulo'))
      ),
      uiOutput('renderInputs',style = 'height: 68%; width: 100%; overflow-y: auto; overflow-x: hidden;')
    ) 
  })
  
  output$slider3 <- renderUI({
    
    req(position() == 3)
 
    atributo.name <- atributo.tmp$name
    logicas       <- atributo.tmp$logicas
    logicas       <- logicas[!duplicated(logicas)]
    init.status   <- TRUE
    init.text     <- TRUE
    text.logica   <- ''
    
    output[[paste0('atributoCondicaoLogic')]] <- renderUI({
      
      comandos <- input[['resultado']]
      
      if(!is.null(comandos))
      {
         valor  <- as.character(isolate(input[[paste0('textNumeric')]]))
        
        if(!(!is.na(as.numeric(valor)))){
          valor <- paste0('"',valor,'"')
        }
                 
        comandos <- stringr::str_replace(comandos,'Valor',valor)
        comandos <- comandos[is.na(comandos) == F] # remove os valores NA
      }
      
      vetorescomandos <- list(atributo.name,textInput(paste0('textNumeric'),'Valor',value = 0))
      sapply(vetorLogica, function(x)  vetorescomandos <<- rlist::list.append(vetorescomandos,x))
      
      logicas <- input[[paste0('comboLobica')]]
      
      if(!is.null(logicas))
      {
        if(logicas != "NENHUMA LOGICA" && text.logica != logicas){
          
          comandos <- transformWords(logicas)
          text.logica  <<- logicas
          init.text    <<- TRUE
          
        }else if(logicas == "NENHUMA LOGICA" && init.text){
          
          comandos <- NULL
          text.logica <<- ''
          init.text   <<- FALSE
        }
      }
      
      if(init.status){
        comandos    <- if(atributo.tmp$editable) atributo.tmp$comandos else NULL
        init.status <<- FALSE
      }
      
      #resete valores
      input$comandos
      
      sortable::bucket_list(
        header = "Contrui a condicao para atributo",
        orientation = 'horizontal',
        sortable::add_rank_list(
          input_id = 'comandos',
          text = "Comandos",
          labels = vetorescomandos
        ),
        sortable::add_rank_list(
          input_id = 'resultado',
          text = "Logica",
          labels = comandos
        )
      )
      
    })
    
    div(
      shinyjs::inlineCSS(paste0("#textClassificacao"," {text-transform: uppercase;}")),
      div(style = "margin-left: 15px;",selectInput('comboLobica','Registros de Logicas',choices = logicas,width = '100%')),
      uiOutput(paste0('atributoCondicaoLogic')),
      div(style = "margin-left: 15px;",textInput(paste0('textClassificacao'),'Classeficação',atributo.tmp$classe,placeholder = 'Digite a classificao para essa logica',width = '100%'))
    )
    
  })
  
  
}

uiEstruturaTable <- function(con,input,output,servers,typedatas,estruturas,timezones,callback){
  
  source('model/SmartObserve.R',local = T)
  obs  <- newObserve()
  
  obs             <- newObserve()
  obs2            <- newObserve()
  obsModal        <- newObserve()
  position        <- reactiveVal(1)
  estruturas      <- reactiveVal(estruturas)
  step3.position  <- reactiveVal(Sys.time())
  atributo        <- reactiveVal()
  con.server      <- NULL
  object.dataset  <- list(colunas = NULL,tipo.data = NULL)
  vetorLogica     <- getVetorLogico()
  logicas         <- selectAllCondicaoQualitativa(con)
  listUpdateTable <- list()
  atributo.tmp    <- NULL
  estrutura       <- NULL
  atributos       <- NULL
  
  
  id <- 'dialogObj'
  cssStyle <- list()
  cssStyle[[paste0(' #parent',id,' .modal-dialog')]]  <- paste0('height: 80% !important;')
  cssStyle[[paste0(' #parent',id,' .modal-content')]] <- paste0('width: 100% !important; height: 100% !important;')
  cssStyle[[paste0(' #parent',id,' .modal-body')]]    <- paste0('width: 100% !important; height: calc(100% - 57px - 65px) !important; overflow-y: hidden;')
  
  #Modal para Dialog
  showModal(div(
    id = paste0('parent', id),
    style = paste0("height: 100%;"),
    shinyjs::inlineCSS(cssStyle),
    dialogModal(
      title = dialogTitleClose('Registro Estrutura',function(){
        
        obs$destroy()
        obs2$destroy()
        obsModal$destroy()
        removeModal()
        callback()
        
      }),
      size = 'l',
      swiper(id = 'swiperMain',width = '100%',height = '100%',
             parent.style = 'height: 100%; width: 100%;',
             swiperSlideUi(
               outputId = 'slider1',
               style = 'height: 100%; width: 100%; overflow-y: auto; padding: 5px;',
               uiOutput('slider1')
             ),
             swiperSlideUi(
               outputId = 'slider2',
               style = 'height: 100%; width: 100%; overflow-y: hidden; overflow-x: hidden;',
               uiOutput('slider2',style = 'width: 100%; height: 100%; padding: 5px; display: none;')
             ),
             swiperSlideUi(
               outputId = 'slider3',
               style = 'height: 100%; width: 100%; overflow-y: hidden; overflow-x: hidden;',
               uiOutput('slider3',style = 'width: 100%; height: 100%; padding: 5px; display: none;  overflow-y: hidden; overflow-x: hidden;')
             ),
             swiperSlideUi(
               outputId = 'slider4',
               style = 'height: 100%; width: 100%;',
               uiOutput('slider4',style = 'height: 100%; width: 100%; overflow-y: auto; display: none;') 
             )
      ),
      footer = uiOutput('uiFooter'),
      callback = function(size){onResizedWindows(list(height = size$height))}
    )
  ))
  
  output$uiFooter <- renderUI({
    
    current <- position()
    
    if(current == 1){
      tagList(actionButton('btSair', label = "Sair"))
    }
    else if(current == 2) {
      tagList(actionButton('btSair', label = "Voltar"),actionButton('btSalvar', label = "Avançar"))
    }
    else if(current == 3) {
      tagList(actionButton('btSair', label = "Voltar"),actionButton('btSalvar', label = "Atualizar"))
    }
    else{
      tagList(actionButton('btSair', label = "Voltar"),actionButton('btSalvar', label = "Inserir"))
    }
    
    
  })
  
  obs$add(observeEvent(input$editPressedRow,{
    
    tryResetConnection(con,function(coon){
      
      con <<- coon
      
      estrutura <<- isolate(estruturas()) %>% filter(CD_ID_STRUCT == input$editPressedRow)
      atributos <<- selectAllAtributoOfStruct(con,estrutura)
      
      swiperSlideNext()
      position(swiperPosition)
      
    })
    
  },ignoreInit = T))
  
  obs$add(observeEvent(input$deletePressedRow,{
    
    estrutura <- isolate(estruturas()) %>% filter(CD_ID_STRUCT == input$deletePressedRow)
    
    messageAlerta(input,
                  title   = paste0('Todos os processos ligado a estrutura será removido!'),
                  message = paste0('Deseja realmente excluir a estrutura ',estrutura$NAME_SCTRUCT,"?"),
                  callback.no = function(){
                    
                  },
                  callback.yes = function(){
                    
                    tryResetConnection(con,function(conn){
                      
                      con <<- conn
                      #remove Database setor
                      DBI::dbExecute(con,paste0('DELETE FROM OBJECT_STRUCT WHERE CD_ID_SCTRUCT = ?'),params = estrutura$CD_ID_SCTRUCT)
                      
                      estruturas.aux <- selectAllEstruturas(con)
                      
                      if(nrow(estruturas.aux) > 0)
                        estruturas(estruturas.aux)
                      else
                      {
                        DBI::dbDisconnect(con)
                        obs$destroy()
                        obs2$destroy()
                        obsModa$destroy()
                        removeModal()
                        callback()
                      }
                    })
                    
                    
                  })
    
  },ignoreInit = T))
  
  obs$add(observeEvent(input$btSalvar,{
    
    current <- swiperPosition
    
    if(current == 2){
      
      tryResetConnection(con,function(coon){
        
        con <<- coon
        
        name <- toupper(isolate(input$textModalEdit))
        
        if(stringi::stri_isempty(stringr::str_trim(name))){
          
          showNotification("O nome da estrutura não foi preenchido!", type = "error")
          return()
        }
        else if(checkifExistNameModelEdit(con,estrutura$CD_ID_STRUCT,name)){
          showNotification("O nome da estrutura já existe nos registros!", type = "error")
          return()
        }
        
        server <- servers %>% filter(TITLE_DB == isolate(input$comboServerEdit))
        
        actionWebUser(function(){
          
          driver   <- server$NAME_DRIVER
          host     <- server$HOST_DB
          port     <- server$PORT_DB
          user     <- server$USER_DB
          pass     <- server$PASS_DB
          dbname   <- server$NAME_DB
          
          con.server <<- connectarDatabase(
            driver = driver,
            host   = host,
            port   = port,
            dbname = dbname,
            user   = user,
            pass   = pass
          )
          
          if(!is.null(con.server)){
            
            tryCatch({
              
              df <- DBI::dbGetQuery(con.server,isolate(input$textoQueryEdit),n = 1)
              
              object.dataset$atributos <<- colnames(df)
              object.dataset$tipo.data <<- listTypeDataStr(con.server,df)
              object.dataset$length    <<- length(object.dataset$atributos)
              
              #remove
              remove(df)
              #atualiza a page 3
              step3.position(Sys.time())
              
              swiperSlideNext()
              position(swiperPosition)
              
            },error = function(e){
              
              showNotification(as.character(e), type = "error")
              
            })
          }
          else{
            showNotification("Autenticação não foi valida!", type = "error")
          }
          
        },auto.remove = TRUE)
        
      })
      
    }else if(current == 3){
      
      #save all struct
      name          <- toupper(isolate(input$textModalEdit))
      query         <- isolate(input$textoQueryEdit)
      id.principal  <- isolate(input$comboKey)
      id.timeline   <- isolate(input$comboTimeline)
      server        <- servers %>% filter(TITLE_DB == isolate(input$comboServerEdit))
      timezone      <- isolate(input$comboTimezone)
      
      if(!checkIfTimelineIsValid(input,object.dataset,id.timeline)){
        showNotification("Atributo timeline não é um tipo de dado DATE ou TIMESTAMP!", type = "error")
        return()
      }
      
      actionWebUser(function(){
        
        status <- tryTransation(con,{
          
          #insert struct
          updateTable(con,'OBJECT_STRUCT',paste0('CD_ID_STRUCT = ',estrutura$CD_ID_STRUCT),
                      list(
                        NAME_STRUCT   = name,
                        ID_ATRIBUTO   = id.principal,
                        TIME_ATRIBUTO = id.timeline,
                        CD_ID_DB      = server$CD_ID_DB,
                        QUERY_STRUCT  = query,
                        TIME_ZONE     = timezone
                      ))
          
          #loop by every attribute
          for (i in 1:object.dataset$length) {
            
            atributo     <- object.dataset$atributos[i]
            atributo.tmp <- atributos %>% filter(NAME_ATRIBUTO == atributo)
            id.atribute  <- 0
            
            if(nrow(atributo.tmp) > 0){
              
              id.atribute  <- unique(atributo.tmp$CD_ID_ATRIBUTO)
              typedata     <- typedatas %>% filter(NAME_DATA == isolate(input[[paste0('comboTipodados_',i)]]))
              logicas      <- listUpdateTable[[i]]() %>% drop_na()
              n            <- nrow(logicas)
              status       <- input[[paste0('checkboxAtributoAtivo_',i)]]
              
              updateTable(con,'ATRIBUTO',paste0('CD_ID_ATRIBUTO = ',id.atribute),
                          list(
                            CD_ID_DATA        = typedata$CD_ID_DATA,
                            NAME_ATRIBUTO     = atributo,
                            POSITION_ATRIBUTO = i,
                            FG_ATIVO          = status
                          ))
              
              if(n > 0)
              {
                
                for(k in 1:n)
                {
                  if(logicas$FLAG[k])
                  {
                    updateTable(con,'ATRIBUTO_QUALITATIVO',paste0('CD_ID_QUAT = ',logicas$CD_ID_LOGIC[k]),
                                list(
                                  COMANDO_QUAT    = logicas$LOGICA[k],
                                  CLASSE_QUAT     = logicas$CLASSE[k]
                                ))
                  }else{
                    
                    insertTable(con,'ATRIBUTO_QUALITATIVO',list(
                      COMANDO_QUAT    = logicas$LOGICA[k],
                      CLASSE_QUAT     = logicas$CLASSE[k],
                      CD_ID_ATRIBUTO  = id.atribute
                    ))
                  }
                }
              }
              atributos <<- atributos %>% filter(CD_ID_ATRIBUTO != unique(atributo.tmp$CD_ID_ATRIBUTO))
              
            }else{
              
              id.atribute  <- nextSequenciaID(con,'ATRIBUTO')
              typedata     <- typedatas %>% filter(NAME_DATA == isolate(input[[paste0('comboTipodados_',i)]]))
              logicas      <- listUpdateTable[[i]]() %>% drop_na()
              n            <- nrow(logicas)
              status       <- input[[paste0('checkboxAtributoAtivo_',i)]]
              
              insertTable(con,'ATRIBUTO',list(
                CD_ID_ATRIBUTO    = id.atribute,
                CD_ID_STRUCT      = estrutura$CD_ID_STRUCT,
                CD_ID_DATA        = typedata$CD_ID_DATA,
                NAME_ATRIBUTO     = atributo,
                POSITION_ATRIBUTO = i,
                FG_ATIVO          = status
              ))
              
              if(n == 0) next
              
              for(k in 1:n)
              {
                insertTable(con,'ATRIBUTO_QUALITATIVO',list(
                  COMANDO_QUAT    = logicas$LOGICA[k],
                  CLASSE_QUAT     = logicas$CLASSE[k],
                  CD_ID_ATRIBUTO  = id.atribute
                ))
              }
              
            }
            
            
          }# end for
          
          #remove todos atributos da estrutura
          sapply(atributos$CD_ID_ATRIBUTO, function(x) DBI::dbGetQuery(con,'DELETE FROM ATRIBUTO WHERE CD_ID_ATRIBUTO = ?',params = x))
          atributos <<- NULL
        })
        
        if(status){
          
          #remove todos plot cache
          keys <- systemCache$keys()
          keys <- keys[stringr::str_starts(systemCache$keys(),'dataplotcache')]
          sapply(keys, function(x) systemCache$remove(x))
          
          estruturas(selectAllEstruturas(con))
          
          if(!is.null(con.server))
            DBI::dbDisconnect(con.server)
          
          con.server <<- NULL
          position(1)
          swiperSlideTo(index = 0)  
          
        }
        else{
          showNotification("Não foi possivel realizar essa operação falha na conexão!", type = "error")
        }
        
      },auto.remove = TRUE)
      
    }
    else if(current == 4){
      
      if(length(input$resultado) == 0){
        showNotification("Nenhuma logica foi construida!", type = "error")
        return()
      }
      if(stringi::stri_isempty(stringr::str_trim(input$textClassificacao))){
        showNotification("Nenhuma classe foi preenchida!", type = "error")
        return()
      }
      
      atributo.tmp$comandos <<- input$resultado
      atributo.tmp$classe   <<- toupper(input$textClassificacao)
      atributo.tmp$reactive(as.numeric(Sys.time()))
      
      position(position() - 1)
      swiperSlidePrevious()  
    }
    
  },ignoreInit = T))
  
  obs$add(observeEvent(input$btSair,{
    
    current <- swiperPosition
    
    if(current == 1){
      
      #destroy all observe events
      DBI::dbDisconnect(con)
      if(!is.null(con.server))
        DBI::dbDisconnect(con.server)
      
      obs$destroy()
      obs2$destroy()
      obsModal$destroy()
      removeModal()
      callback()
      
    }
    else if(current == 2){
      
      if(!is.null(con.server))
        DBI::dbDisconnect(con.server)
      
      position(position() - 1)
      swiperSlidePrevious()
      
    }else if(current == 3){
      
      if(!is.null(con.server))
        DBI::dbDisconnect(con.server)
      
      con.server <<- NULL
      position(position() - 1)
      swiperSlidePrevious()   
      
    }
    else{
      
      atributo(NULL)
      position(position() - 1)
      swiperSlidePrevious()  
    }
    
  },ignoreInit = T))
  
  output$slider1 <- renderUI({
    
    output$tableDinamica <- DT::renderDataTable({
      
      dataset <-  estruturas()
      
      if(length(dataset) == 0) return(NULL)
      
      colunaNames <- c('LINHA','ESTRUTRUA','SERVIDOR','DRIVER','VISUALIZAR / EDITAR','REMOVER')
      
      height <- (onResizedWindows()$height * 0.70)  - (200)
      
      DT::datatable({
        
        dataset %>% 
          mutate_if(is.POSIXct,function(x){ format(x,'%d/%m/%Y %H:%M:%S')})  %>% 
          mutate_if(is.Date,function(x){ format(x,'%d/%m/%Y')}) %>% 
          mutate_if(is.character,toupper) %>% 
          mutate(
            !!colunaNames[1] := 1:nrow(dataset),
            !!colunaNames[2] :=  dataset$NAME_STRUCT,
            !!colunaNames[3] :=  dataset$TITLE_DB,
            !!colunaNames[4] :=  dataset$NAME_DRIVER,
            !!colunaNames[5] :=  sapply(dataset$CD_ID_STRUCT, function (x) {
              
              as.character(
                actionButton(
                  paste0('btEdit'),
                  label = '',
                  icon = icon('eye'),
                  onclick = paste0('Shiny.setInputValue(\"editPressedRow\","',x,'",{priority: "event"})'),
                  #style = 'background-color: transparent; color: lightblue; border-solid: none;'
                )
              )
            }),
            !!colunaNames[6] :=  sapply(dataset$CD_ID_STRUCT, function(x){
              
              as.character(
                actionButton(
                  paste0('btRemove'),
                  label = '',
                  icon = icon('trash'),
                  onclick = paste0('Shiny.setInputValue(\"deletePressedRow\","',x,'",{priority: "event"})'),
                  #style = 'background-color: transparent; color: lightblue; border-solid: none;'
                )
              )
              
            })
            
          ) %>% select(colunaNames) %>% arrange(colunaNames[2])
      }, 
      class = 'cell-border stripe',
      extensions = 'Scroller',
      options = list(
        language = list(url = 'js/table/translate.json'),
        dom = 't',
        bSort=FALSE,
        columnDefs = list(list(visible=FALSE, targets=c(0)),list(className = 'dt-center', targets = "_all")),
        deferRender = TRUE,
        scroller = TRUE,
        fixedHeader = TRUE,
        scrollX = TRUE,
        scrollY = paste0(height,"px")
      ),
      escape = F,
      selection = 'none',
      )  %>% DT::formatStyle(colnames(result), cursor = 'pointer')
      
    })
    
    div(
      style = 'border-style: solid; border-color: white; border-width: 1px; overflow-x: auto;',
      DT::dataTableOutput(outputId = 'tableDinamica')
    )
    
  })
  
  output$slider2  <- renderUI({
    
    req(position() == 2)
    
    obs2$clear()
    
    obs2$add(observeEvent(input$importFileEdit,{
      
      tryCatch({
        file <- input$importFileEdit$datapath
        updateTextAreaInput(inputId = 'textoQueryEdit',value = readr::read_file(file))
      },error = function(e) print(e))
      
    },ignoreInit = TRUE))
    
    div(
      style = 'width: 100%; height: 90%;',
      fluidRow(
        shinyjs::inlineCSS(paste0("#textModalEdit"," {text-transform: uppercase;}")),
        column(6,textInput('textModalEdit',label = "Nome",placeholder = 'Digite o nome para modelo',estrutura$NAME_STRUCT)),
        column(6,selectInput('comboServerEdit','Servidor',choices = servers$TITLE_DB,selected = estrutura$TITLE_DB))
      ),
      tagList(
        fileInput(inputId = "importFileEdit",label = "Arquivo Query",multiple = F,accept = c('.sql'),placeholder = 'Seleciona o arquivo',width = '100%'),
        textAreaInput('textoQueryEdit',
                      'Estrutura Query',
                      value = estrutura$QUERY_STRUCT,
                      placeholder = 'Entre com estrutura da quary.',
                      height = '100%',
                      resize = "none") %>% 
          shiny::tagAppendAttributes(style = 'width: 100%; font-weight: bold; height: 65%;')
      ))
    
  })
  
  output$slider3  <- renderUI({
    
    req(step3.position())
    
    ID_ROW   <- NULL
    obsModal$clear()
    #lista update
    listUpdateTable <<- list()
    
    output$renderInputsEdit <- renderUI({
      
      lapply(1:object.dataset$length, function(i){
        
        atributo.data    <- object.dataset$atributos[i]
        tipoDado.data    <- object.dataset$tipo.data[i]
        ID_ROW           <- NULL
        attribute        <- tabelasLogicEdit(i,atributos,atributo.data)
        updateTable      <- reactiveVal({ if(nrow(isolate(attribute$table()) %>% drop_na()) == 0) NULL  else -1 })
        tabelasLogicas   <- attribute$table
        #add global
        listUpdateTable <<- listUpdateTable %>% rlist::list.append(attribute$table)
        
        #render tabela logica
        output[[paste0('containerEdit_',i)]] <-  renderUI({
          
          req(updateTable())
          
          if(updateTable() > -1){
            
            atributo <- atributo.tmp
            #reativa a render
            comando  <- atributo$comandos
            comandos <- paste(comando,collapse = ' ')
            classe   <- atributo$classe
            
            if(!atributo$editable){
              
              ID       <- list()
              ID       <- paste0(i,address(ID))
              
              table   <- isolate(tabelasLogicas())
              table   <- table %>% drop_na()
              
              linha   <- ifelse(is.null(table), 1, nrow(table) + 1)
              #update table
              tabelasLogicas(rbind(table,
                                   data.frame(
                                     CD_ID_LOGIC = 0,
                                     FLAG   = FALSE,
                                     ID     = ID,
                                     ATRIBUTO = i,
                                     LINHA  = linha,
                                     LOGICA = comandos,
                                     CLASSE = classe,
                                     EDITAR = as.character(
                                       actionButton(
                                         paste0('btEditar',i,ID),
                                         label = '',
                                         icon = icon('edit'),
                                         onclick = paste0('Shiny.setInputValue("',paste0("editarPressedRow",i),'","',ID,'");'),
                                         #style = 'background-color: transparent; color: lightblue; border-solid: none;'
                                       )
                                     ),
                                     REMOVER = as.character(
                                       actionButton(
                                         paste0('btRemove',i,ID),
                                         label = '',
                                         icon = icon('trash'),
                                         onclick = paste0('Shiny.setInputValue("',paste0("deletePressedRow",i),'","',ID,'");'),
                                         #style = 'background-color: transparent; color: lightblue; border-solid: none;'
                                       )
                                     )
                                     
                                   )))
              
              #destroy obj tmp ATRIBUTO
              atributo.tmp <<- NULL
              
            }else{
              
              #Editable row of table logicas
              table     <- isolate(tabelasLogicas())
              aux       <- table %>% filter(ID == ID_ROW) %>% mutate(LOGICA = comandos,CLASSE = classe)
              table[which(table$ID == ID_ROW),] <- aux
              
              freezeReactiveValue(input,"tabelasLogicas")
              tabelasLogicas(table)
            }
            
            ID_ROW   <<- NULL
            
          }
          
          output[[paste0('logictable',i)]] <- DT::renderDataTable({
            
            df   <- tabelasLogicas()
            df   <- df %>% drop_na()
            
            if(nrow(df) == 0)
            {
              shinyjs::hide(paste0('logictable',i))
            }
            else{
              shinyjs::show(paste0('logictable',i))
            }
            
            if(!is.null(df))
              df <- tabelasLogicas() %>% select(-CD_ID_LOGIC,-FLAG,-ATRIBUTO,-ID)
            
            DT::datatable(df,
                          class = 'cell-border stripe',
                          extensions = 'Scroller',
                          options = list(
                            dom = 't',
                            bSort=FALSE,
                            columnDefs = list(list(visible=FALSE, targets=c(0)),list(className = 'dt-center', targets = "_all")),
                            deferRender = TRUE,
                            scroller = FALSE
                          ),
                          escape = F,
                          selection = 'none',
            )  %>% DT::formatStyle(colnames(result), cursor = 'pointer')
            
          })
          
          fluidRow(
            column(12,div(
              style = 'border-style: solid; border-color: white; border-width: 1px;',
              DT::dataTableOutput(paste0('logictable',i))
            )),
            column(12,br())
          )
          
        })#end
        
        #events qualitativos
        obsModal$add(observeEvent(input[[paste0('atributoLogicEdit',i)]],{
          
          nameatributo <- toupper(isolate(input[[paste0('atributoEdit_', i)]]))
          
          if(nrow(logicas) > 0)
            logicas <- logicas %>%
              mutate(
                COMANDO_QUAT = stringr::str_replace_all(
                  COMANDO_QUAT,
                  changeAnotherNameSensorLogica(COMANDO_QUAT, vetorLogica),
                  nameatributo
                )
              )
          
          atributo.tmp <<- list(
            name = nameatributo,
            logicas = c('NENHUMA LOGICA',logicas$COMANDO_QUAT),
            index = i,
            editable = FALSE,
            classe = '',
            reactive = updateTable
          )
          
          
          swiperSlideNext()
          position(swiperPosition)
          
        },ignoreInit = T))
        
        obsModal$add(observeEvent(input[[paste0("editarPressedRow",i)]],{
          
          req(tabelasLogicas(),input[[paste0("editarPressedRow",i)]])
          
          ID_ROW    <<- isolate(input[[paste0("editarPressedRow",i)]])
          
          nameatributo <- toupper(isolate(input[[paste0('atributoEdit_', i)]]))
          table        <- isolate(tabelasLogicas())
          aux          <- table %>% filter(ID == ID_ROW)
          comando      <- stringr::str_split(aux$LOGICA,' ')[[1]]
          
          if(!is.null(atributo.tmp))
            remove(atributo.tmp)
          
          if(nrow(logicas) > 0)
            logicas <- logicas %>%
            mutate(
              COMANDO_QUAT = stringr::str_replace_all(
                COMANDO_QUAT,
                changeAnotherNameSensorLogica(COMANDO_QUAT, vetorLogica),
                nameatributo
              )
            )
          
          atributo.tmp <<- list(
            name     = nameatributo,
            logicas  = c('NENHUMA LOGICA',logicas$COMANDO_QUAT),
            index    = i,
            editable = TRUE,
            classe   = aux$CLASSE,
            comandos = comando,
            reactive = updateTable
          )
          
          position(4)
          swiperSlideNext()
          shinySetInputValue(paste0("editarPressedRow",i),NULL)
          
        },ignoreInit = T,ignoreNULL = T))
        
        obsModal$add(observeEvent(input[[paste0("deletePressedRow",i)]],{
          
          req(tabelasLogicas(),input[[paste0("deletePressedRow",i)]])
          
          ID_ROW    <- isolate(input[[paste0("deletePressedRow",i)]])
          table     <- isolate(tabelasLogicas())
          aux       <- table %>% filter(ID == ID_ROW)
          
          messageAlerta(input,
                        title   = paste0('A linha ',aux$LINHA,' será removida da tabela de condições!'),
                        message = paste0('Deseja realmente remover a linha ',aux$LINHA,"?"),
                        callback.no = function(){
                          
                        },
                        callback.yes = function(){
                          
                          table <- table[-which(ID_ROW == table$ID),]
                          
                          if(nrow(table) == 0)
                            tabelasLogicas(data.frame(
                              ID     = NA,
                              ATRIBUTO = NA,
                              LINHA  = NA,
                              LOGICA = NA,
                              CLASSE = NA,
                              REMOVER = NA
                              
                            ))
                          else
                            tabelasLogicas(table)
                        })
          
          freezeReactiveValue(input,paste0("deletePressedRow",i))
          shinyjs::runjs(paste0("Shiny.setInputValue('",paste0("deletePressedRow",i),"',null);"))
          
        },ignoreInit = T,ignoreNULL = T))
        
        #component
        fluidRow(
          shinyjs::inlineCSS(paste0("#",paste0('Atributo_',i)," {text-transform: uppercase;}")),
          column(12,splitLayout(
            tagList(
              tags$label('Ativar',style = 'font-size: 15px;'),
              prettyToggle(
                inputId = paste0('checkboxAtributoAtivo_',i),
                label_on = "Sim",
                label_off = "Não", 
                outline = TRUE,
                plain = TRUE,
                value = TRUE,
                icon_on = icon("thumbs-up"),
                icon_off = icon("thumbs-down"),
                bigger = T,
                width = 'auto'
              )
            ),
            textInput(inputId = paste0('atributoEdit_',i),label = paste0('Atributo: ',i),value   = atributo.data,width = '100%') %>% tagAppendAttributesFind(2,readonly = 'true'),
            selectInput(paste0('comboTipodados_',i),label = 'Tipo dado',choices = typedatas$NAME_DATA,selected = attribute$attribute$NAME_DATA),
            actionButton(paste0('atributoLogicEdit',i),label = '',icon = icon('lightbulb'),style = 'margin-top: 25px;'),
            cellWidths = c('50px','255px','150px','50px')
          )),
          column(12,uiOutput(paste0('containerEdit_',i),style = 'padding: 5px;'))
        )
        
      })
      
    })
    
    #render
    div(
      style = 'padding: 15px; height: 100%;',
      selectInput('comboKey',label = 'Atributo ID',selected = estrutura$ID_ATRIBUTO,choices = object.dataset$atributos,width = '100%'),
      fluidRow(
        column(6,selectInput('comboTimeline',label = 'Atributo Timeline',selected = estrutura$TIME_ATRIBUTO,choices = object.dataset$atributos,width = '100%')),
        column(6,selectInput('comboTimezone',label = 'Time Zone',choices = timezones$NAME_ZONE,selected = estrutura$TIME_ZONE))
      ),
      uiOutput('renderInputsEdit',style = 'height: 68%; width: 100%; overflow-y: auto; overflow-x: hidden;')
    ) 
  })
  
  output$slider4 <- renderUI({
    
    req(position() == 4)
    
    atributo.name <- atributo.tmp$name
    logicas       <- atributo.tmp$logicas
    logicas       <- logicas[!duplicated(logicas)]
    init.status   <- TRUE
    init.text     <- TRUE
    text.logica   <- ''
    
    output[[paste0('atributoCondicaoLogicEdit')]] <- renderUI({
      
      comandos <- input[['resultado']]
      
      if(!is.null(comandos))
      {
        valor    <- as.character(isolate(input[[paste0('textNumeric')]]))
        
        if(!(!is.na(as.numeric(valor)))){
          valor <- paste0('"',valor,'"')
        }
        
        comandos <- stringr::str_replace(comandos,'Valor',valor)
        comandos <- comandos[is.na(comandos) == F] # remove os valores NA
      }
      
      vetorescomandos <- list(atributo.name,textInput(paste0('textNumeric'),'Valor',value = 0))
      sapply(vetorLogica, function(x)  vetorescomandos <<- rlist::list.append(vetorescomandos,x))
      
      logicas <- input[[paste0('comboLobica')]]
      
      if(!is.null(logicas))
      {
        if(logicas != "NENHUMA LOGICA" && text.logica != logicas){
          
          comandos <- transformWords(logicas)
          text.logica  <<- logicas
          init.text    <<- TRUE
          
        }else if(logicas == "NENHUMA LOGICA" && init.text){
          
          comandos <- NULL
          text.logica <<- ''
          init.text   <<- FALSE
        }
      }
      
      if(init.status){
        
        comandos    <- if(atributo.tmp$editable) atributo.tmp$comandos else NULL
        init.status <<- FALSE
      }
      
      #resete valores
      input$comandos
      
      sortable::bucket_list(
        header = "Contrui a condicao para atributo",
        orientation = 'horizontal',
        sortable::add_rank_list(
          input_id = 'comandos',
          text = "Comandos",
          labels = vetorescomandos
        ),
        sortable::add_rank_list(
          input_id = 'resultado',
          text = "Logica",
          labels = comandos
        )
      )
      
    })
    
    div(
      shinyjs::inlineCSS(paste0("#textClassificacao"," {text-transform: uppercase;}")),
      div(style = "margin-left: 15px;",selectInput('comboLobica','Registros de Logicas',choices = logicas,width = '100%')),
      uiOutput(paste0('atributoCondicaoLogicEdit')),
      div(style = "margin-left: 15px;",textInput(paste0('textClassificacao'),'Classeficação',atributo.tmp$classe,placeholder = 'Digite a classificao para essa logica',width = '100%'))
    )
    
  })
  
}

listTypeDataStr <- function(con.server,dataset){
  
  sapply(1:ncol(dataset), function(x) setNames(DBI::dbDataType(con.server,dataset[x]),NULL))
}

tabelasLogicEdit <- function(index,atributos,atributo.data){
  
  attribute      <- atributos %>% filter(NAME_ATRIBUTO == atributo.data)
  tabelasLogicas <- NULL
  
  if(!all(is.na(attribute$CD_ID_QUAT))){
    
    dataframe <- NULL
    
    for (i in 1:nrow(attribute)) {
      
      ID        <- paste0(i,address(ID))
      linha     <- i
      att       <- attribute[i,]
      dataframe <- rbind(dataframe,data.frame(
        CD_ID_LOGIC = att$CD_ID_QUAT,
        FLAG     = TRUE,
        ID       = ID,
        ATRIBUTO = i,
        LINHA    = linha,
        LOGICA   = att$COMANDO_QUAT,
        CLASSE   = att$CLASSE_QUAT,
        EDITAR = as.character(
          actionButton(
            paste0('btEditar',i,ID),
            label = '',
            icon = icon('edit'),
            onclick = paste0('Shiny.setInputValue("',paste0("editarPressedRow",index),'","',ID,'");'),
            #style = 'background-color: transparent; color: lightblue; border-solid: none;'
          )
        ),
        REMOVER = as.character(
          actionButton(
            paste0('btRemove',i,ID),
            label = '',
            icon = icon('trash'),
            onclick = paste0('Shiny.setInputValue("',paste0("deletePressedRow",index),'","',ID,'");'),
            #style = 'background-color: transparent; color: lightblue; border-solid: none;'
          )
        )))
      
    }
    
    tabelasLogicas   <- reactiveVal(dataframe)
  }
  else{
    
    tabelasLogicas   <- reactiveVal(data.frame(
      CD_ID_LOGIC = NA,
      FLAG   = NA,
      ID     = NA,
      ATRIBUTO = NA,
      LINHA  = NA,
      LOGICA = NA,
      CLASSE = NA,
      REMOVER = NA
      
    ))
    
  }
  
  return(list(attribute = unique(attribute %>% select(CD_ID_ATRIBUTO,NAME_ATRIBUTO,FG_ATIVO,POSITION_ATRIBUTO,NAME_DATA,R_DATA)),table = tabelasLogicas))
}


checkIfTimelineIsValid <- function(input,object.dataset,timeline){
  
  timeline <- isolate(input[[paste0('comboTipodados_',which(object.dataset$atributos == timeline))]])
  
  return(any(timeline %in% c("DATE",'TIMESTAMP')))
}
