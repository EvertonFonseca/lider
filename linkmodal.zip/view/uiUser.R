uiUserNew   <- function(con,input,output,user,setores,callback){
  
  source('model/SmartObserve.R',local = T)
  obs <- newObserve()
  
  usuarios.tmp     <- NULL
  textReactivePass <- reactiveVal(passwordInput('textSenha',label = 'Senha',placeholder = 'DIGITE A SENHA'))
  is.hide          <- TRUE
  setores          <- reactiveVal(setores)
  admin            <- NULL
  
  if(user$CD_ID_TIPO == 1) # master
  {
    usuarios.tmp <- DBI::dbGetQuery(con,'SELECT * FROM users WHERE CD_ID_TIPO = 2')
    
    if(nrow(usuarios.tmp) == 0)
      usuarios.tmp <- NULL
  }
  
  tiposUsers <- DBI::dbGetQuery(con,'SELECT * FROM users_tipo WHERE CD_ID_UT != 1')
  
  
  id <- 'dialogObj'
  cssStyle <- list()
  cssStyle[[paste0(' #parent',id,' .modal-dialog')]]  <- paste0('height: 80% !important;')
  cssStyle[[paste0(' #parent',id,' .modal-content')]] <- paste0('width: 100% !important; height: 100% !important;')
  cssStyle[[paste0(' #parent',id,' .modal-body')]]    <- paste0('width: 100% !important; height: calc(100% - 57px - 65px) !important; overflow-y: hidden;')
  
  showModal(
    shiny::div(
      id = paste0('parent', id),
      style = paste0("height: 90%;"),
      shinyjs::inlineCSS(cssStyle),
      dialogModal(
        title = dialogTitleClose('Novo Usuário',function(){
          
          #destroy all observe events
          DBI::dbDisconnect(con)
          obs$destroy()
          removeModal()
          callback()
          
        }),
        size = 'm',
        div(
          id    = 'containerCenter',
          style = 'height: 100%; width: 100%; overflow-y: auto; padding: 5px;',
          shinyjs::inlineCSS("#textNameUser {text-transform: uppercase;}"),
          textInput('textNameUser',label = 'Nome',placeholder = 'Digite o nome'),
          splitLayout(uiOutput('containerSenha'),
                      actionButton('btHidePass',label = '',icon = icon('eye'),style = 'background-color: white; margin-top: 25px;'),
                      cellWidths = 'auto'),
          if(!is.null(usuarios.tmp))
            uiOutput('containerAdmin'),
          selectInput('comboTipoUser','Permissão',choices =  tiposUsers$NAME_UT),
          uiOutput('containerUserSetores')
        ),
        footer = tagList(shiny::actionButton(inputId = "btSair","Sair"),actionButton('btSalvar','Salvar')))
    ))
  
  output$containerAdmin <- renderUI({
    
    tipo <- toupper(input$comboTipoUser)
    
    req(which(tiposUsers$NAME_UT == tipo) == 2)
    
    selectInput('comboAdmin','Administrador Responsavel',choices =  usuarios.tmp$NAME_USER)
  })
  
  output$containerUserSetores <- renderUI({
    
    tipo <- toupper(input$comboTipoUser)

    if(which(tiposUsers$NAME_UT == tipo) == 2)
    {
      
      changetextPlaceHolder()
      
      multiInput(
        inputId = 'multiSetores',
        width = '100%',
        options = list(
          enable_search = T,
          non_selected_header = "Setores não selecionados",
          selected_header     = "Setores selecionados"
        ),
        selected = NULL,
        label = "Setores de acesso",
        choices = NULL,
        choiceNames  = apply(setores(),1, function(x)  tagList(x["NAME_SETOR"])),
        choiceValues = apply(setores(),1, function(x)  x["NAME_SETOR"])
      ) %>% tagAppendAttributes(style = ';height: auto; width: 100%;')
    }
    else{
      
      admin <<- NULL
      NULL
    }
    
  })
  
  output$containerSenha       <- renderUI({
    
    req(textReactivePass())
    
    textReactivePass()
  })
  
  obs$add(observeEvent(input$comboAdmin,{
    
    req(input$comboAdmin)
    req(!stringi::stri_isempty(input$comboAdmin))
    
    #obtem user
    admin <<- usuarios.tmp %>% filter(NAME_USER == input$comboAdmin)
    
    tryResetConnection(con,function(coon){
      
      con <<- coon
      setores(selectSetores(con,admin))
      
    })
    
  },ignoreInit = T,ignoreNULL = T))
  
  obs$add(observeEvent(input$btHidePass,{
    
    is.hide <<- !is.hide
    
    if(is.hide)
    {
      updateActionButton(getDefaultReactiveDomain(),inputId = 'btHidePass',icon = icon('eye'))
      textReactivePass(passwordInput('textSenha',label = 'Senha',placeholder = 'DIGITE A SENHA',value = input$textSenha))
    }
    else{
      
      updateActionButton(getDefaultReactiveDomain(),inputId = 'btHidePass',icon = icon('eye-slash'))
      textReactivePass(textInput('textSenha',label = 'Senha',placeholder = 'DIGITE A SENHA',value = input$textSenha))
    }
    
    
  },ignoreInit = T,ignoreNULL = T))
  
  obs$add(observeEvent(input$btSair,{
    
    #destroy all observe events
    DBI::dbDisconnect(con)
    obs$destroy()
    removeModal()
    callback()
    
  },ignoreInit = T,ignoreNULL = T))
  
  obs$add(observeEvent(input$btSalvar,{
    
    name           <- toupper(input$textNameUser)
    senha          <- input$textSenha
    tipo           <- toupper(input$comboTipoUser)
    codigosSetores <- NULL
    
    if(stringi::stri_isempty(stringr::str_trim(name))){
      
      showNotification("O nome do usuário não foi preenchido!", type = "warning")
      return()
    }
    
    if(stringi::stri_isempty(stringr::str_trim(senha))){
      
      showNotification("O senha do usuário não foi preenchido!", type = "warning")
      return()
    }
    
    #check if type users is analista
    if(which(tiposUsers$NAME_UT == tipo) == 2){
      
      setoresSelection <- input$multiSetores
      
      #there not exist any setor selected
      if(length(setoresSelection) == 0){
        
        showNotification("Nenhum setor foi selecionado para analista!", type = "warning")
        return()
      }

      #which are setores 
      codigosSetores <- setores() %>% filter(NAME_SETOR %in% setoresSelection) %>% select(CD_ID_SETOR) %>% pull()
      codigosSetores <- jsonlite::toJSON(codigosSetores,auto_unbox = T)
    }
    
    tryResetConnection(con,function(coon){
      
      con <<- coon
      
      #check que se existe usarios com o mesmo nome
      status <- DBI::dbGetQuery(con,"SELECT COUNT(*) FROM USERS WHERE NAME_USER = ?",params = toupper(name)) %>% pull()
      
      #existe
      if(status > 0){
        showNotification("O nome do usuário já possui nos registros!", type = "warning")
        return()
      }
      
      if(!is.null(codigosSetores))
      {
        insertTable(con,'USERS',list(
          NAME_USER      = name,
          PASS_USER      = senha,
          CD_ID_TIPO     = tiposUsers %>% filter(NAME_UT == tipo) %>% select(CD_ID_UT) %>% pull(),
          CD_ID_PARENT   = ifelse(is.null(admin),user$CD_ID_USER,admin$CD_ID_USER),
          SETORES_ACESSO = codigosSetores
        ))
      }
      else{
        insertTable(con,'USERS',list(
          NAME_USER      = name,
          PASS_USER      = senha,
          CD_ID_TIPO     = tiposUsers %>% filter(NAME_UT == tipo) %>% select(CD_ID_UT) %>% pull(),
          CD_ID_PARENT   = ifelse(is.null(admin),user$CD_ID_USER,admin$CD_ID_USER)
        ))
      }
      
      #recarrega os adminstradores
      if(user$CD_ID_TIPO == 1) # master
      {
        usuarios.tmp <<- DBI::dbGetQuery(con,'SELECT * FROM users WHERE CD_ID_TIPO = 2')
        
        if(nrow(usuarios.tmp) == 0)
          usuarios.tmp <<- NULL
      }
      
      dialogConfirm(
        title = 'Usuário criado com sucesso!',
        text = 'Deseja criar novamente um novo usuário?',
        callback = function(status) {
          
          is.hide <<- TRUE
          admin   <<- NULL
          shinyjs::reset('containerCenter')
          
          if(!status){
            DBI::dbDisconnect(con)
            obs$destroy()
            callback()
            removeModal()
          }
          
        })
      
    })
    
  },ignoreInit = T,ignoreNULL = T))
  
}

uiUserTable <- function(con,input,output,setores,user,usuarios,callback){
  
  source('model/SmartObserve.R',local = T)
  obs   <- newObserve()
  obs2  <- newObserve()
  
  usuario          <- reactiveVal(NULL)
  observeEvents    <- list()
  usuarios         <- reactiveVal(usuarios)
  sliderPosition   <- reactiveVal(1)
  usuarios.tmp     <- NULL
  textReactivePass <- reactiveVal(passwordInput('textSenha',label = 'Senha',placeholder = 'DIGITE A SENHA'))
  is.hide          <- TRUE
  setores          <- reactiveVal(setores)
  admin            <- NULL
  tiposUsers       <- DBI::dbGetQuery(con,'SELECT * FROM users_tipo WHERE CD_ID_UT != 1')
  
  id <- 'dialogObj'
  cssStyle <- list()
  cssStyle[[paste0(' #parent',id,' .modal-dialog')]]  <- paste0('height: 80% !important;')
  cssStyle[[paste0(' #parent',id,' .modal-content')]] <- paste0('width: 100% !important; height: 100% !important;')
  cssStyle[[paste0(' #parent',id,' .modal-body')]]    <- paste0('width: 100% !important; height: calc(100% - 57px - 65px) !important; overflow-y: hidden;')
  
  #Modal para Dialog
  showModal(div(
    id = paste0('parent', id),
    style = paste0("height: 90%;"),
    shinyjs::inlineCSS(cssStyle),
    dialogModal(
      title = dialogTitleClose('Registro Usuarios',function(){
        
        #destroy all observe events
        DBI::dbDisconnect(con)
        obs$destroy()
        obs2$destroy()
        swiperDestroy()
        removeModal()
        callback()
        
      }),
      size = 'm',
      swiper(id = 'swiperMainModal',
             parent.style = 'height: 100%; width: 100%;',
             width = '100%',
             height = '100%',
             swiperSlide(
               style = 'height: 100%; width: 100%; overflow-y: hidden; overflow-x: hidden;',
               uiOutput('slider1',style = 'width: 100%; height: 100%; padding: 5px;')
             ),
             swiperSlide(
               style = 'height: 100%; width: 100%;',
               uiOutput('slider2',style = 'height: 100%; width: 100%; overflow-y: auto;') 
             )
      ),
      footer = uiOutput('uiFooter'),
      callback = function(size){onResizedWindows(list(height = size$height))}s
    )))
  
  
  output$uiFooter <- renderUI({
    
    current <- sliderPosition()
    
    if(current == 1){
      tagList(actionButton('btActionCancel', label = "Sair"))
    }
    else{
      tagList(actionButton('btActionCancel', label = "Voltar"),actionButton('btActionUpdate', label = "Atualizar"))
    }
    
    
  })
  
  output$slider1 <- renderUI({
    
    output$tableDinamica <- DT::renderDataTable({
      
      # future({
      dataset <-  usuarios()
      
      if(nrow(dataset) == 0) return(NULL)
      
      colunaNames <- c('LINHA','USUARIO','TIPO','ONLINE','VISUALIZAR / EDITAR','REMOVER')
      
      
      height <- (onResizedWindows()$height* 0.65) - 200
      
      
      DT::datatable({
        
        dataset %>% 
          mutate_if(is.POSIXct,function(x){ format(x,'%d/%m/%Y %H:%M:%S')})  %>% 
          mutate_if(is.Date,function(x){ format(x,'%d/%m/%Y')}) %>% 
          mutate_if(is.character,toupper) %>% 
          mutate(
            !!colunaNames[1] := 1:nrow(dataset),
            !!colunaNames[2] := dataset$NAME_USER,
            !!colunaNames[3] := dataset$NAME_UT,
            !!colunaNames[4] := ifelse(dataset$FG_ONLINE_USER,'SIM','NÃO'),
            !!colunaNames[5] := sapply(CD_ID_USER, function (x) {
              
              as.character(
                actionButton(
                  paste0('btEdit'),
                  label = '',
                  icon = icon('eye'),
                  onclick = paste0('Shiny.setInputValue(\"editPressedRow\","',x,'",{priority: "event"})'),
                  #style = 'background-color: transparent; color: lightblue; border-solid: none;'
                )
              )
            }),
            !!colunaNames[6] := sapply(CD_ID_USER, function(x){
              
              as.character(
                actionButton(
                  paste0('btRemove'),
                  label = '',
                  icon = icon('trash'),
                  onclick = paste0('Shiny.setInputValue(\"deletePressedRow\","',x,'",{priority: "event"})'),
                  #style = 'background-color: transparent; color: lightblue; border-solid: none;'
                )
              )
              
            })
            
          ) %>% select(colunaNames)
      }, 
      class = 'cell-border stripe',
      extensions = 'Scroller',
      options = list(
        language = list(url = 'js/table/translate.json'),
        dom = 't',
        bSort=FALSE,
        columnDefs = list(list(visible=FALSE, targets=c(0)),list(className = 'dt-center', targets = "_all"),list(width = '75px',targets = c(1,4)),list(width = 'autos',targets = c(3))),
        deferRender = TRUE,
        scroller = TRUE,
        fixedHeader = TRUE,
        scrollX = TRUE,
        scrollY = paste0(height,"px")
      ),
      escape = F,
      selection = 'none',
      )  %>% DT::formatStyle(colnames(result), cursor = 'pointer')
      
    })
    
    div(
      style = 'border-style: solid; border-color: white; border-width: 1px; overflow-x: auto;',
      DT::dataTableOutput(outputId = 'tableDinamica')
    )
    
  })
  
  output$slider2 <- renderUI({
    
    req(usuario())
    
    obs2$clear()
    
    obs2$add(observeEvent(input$comboAdmin,{
      
      req(input$comboAdmin)
      req(!stringi::stri_isempty(input$comboAdmin))
      
      #obtem user
      admin <<- usuarios.tmp %>% filter(NAME_USER == input$comboAdmin)
      
      tryResetConnection(con,function(coon){
        
        con <<- coon
        setores(selectSetoresOnly(con,admin))
        
      })
      
    },ignoreInit = T,ignoreNULL = T))
    
    div(
      id    = 'containerCenter',
      style = 'height: 100%; width: 100%; overflow-y: auto; padding: 5px;',
      shinyjs::inlineCSS("#textNameUser {text-transform: uppercase;}"),
      textInput('textNameUser',label = 'Nome',placeholder = 'Digite o nome',usuario()$NAME_USER),
      textInput('textSenha',label = 'Senha',placeholder = 'DIGITE A SENHA',value = usuario()$PASS_USER),
      if(!is.null(usuarios.tmp))
        uiOutput('containerAdmin'),
      selectInput('comboTipoUser','Permissão',choices =  tiposUsers$NAME_UT,selected = usuario()$NAME_UT),
      uiOutput('containerUserSetores')
    )
    
  })
  
  obs$add(observeEvent(input$editPressedRow,{
    
    usuario(usuarios() %>% filter(CD_ID_USER == input$editPressedRow))
    
    tryResetConnection(con,function(coon){
      
      con <<- coon
      
      if(usuario()$CD_ID_TIPO == 1) # master
      {
        usuarios.tmp <<- DBI::dbGetQuery(con,'SELECT * FROM users WHERE CD_ID_TIPO = 2')
        
        if(nrow(usuarios.tmp) == 0)
          usuarios.tmp <<- NULL
      }
      
      swiperSlideNext()
      sliderPosition(swiperPosition)
      
    })
    
  },ignoreInit = T))
  
  obs$add(observeEvent(input$deletePressedRow,{
    
    usuario <- isolate(usuarios) %>% filter(CD_ID_USER == input$deletePressedRow)
    
    messageAlerta(input,
                  title   = paste0('Todos os processos ligado a esse usuario será excluido'),
                  message = paste0('Deseja realmente excluir o usuario',usuario$NAME_USER,"?"),
                  callback.no = function(){
                    
                  },
                  callback.yes = function(){
                    
                    tryResetConnection(con,function(conn){
                      
                      con <<- conn
                      
                      #close all children if he is online
                      updateAllChildrenSession(con,usuario)
                      #remove Database setor
                      DBI::dbExecute(con,paste0('DELETE FROM USERS WHERE CD_ID_USER = ',usuario$CD_ID_USER))
                      
                      user.aux <- usuarios()
                      user.aux <- user.aux %>% filter(CD_ID_USER != usuario$CD_ID_USER)
                      
                      if(nrow(user.aux) > 0){
                        
                        usuarios(user.aux)
                      }
                      else{
                        #destroy all observe events
                        DBI::dbDisconnect(con)
                        #exit do dialog
                        obs$destroy()
                        obs2$destroy()
                        removeModal()
                        callback()
                      }
                      
                      
                    })
                    
                    
                  })
    
  },ignoreInit = T))
  
  obs$add(observeEvent(input$btActionCancel,{
    
    current <- swiperPosition
    
    if(current == 1){
      #destroy all observe events
      DBI::dbDisconnect(con)
      obs$destroy()
      obs2$destroy()
      swiperDestroy()
      removeModal()
      callback()
    }
    else{
      
      shinyjs::delay(1000,{
        usuario(NULL)
      })
      
      swiperSlidePrevious()
      sliderPosition(swiperPosition)
    }
    
  },ignoreInit = T))
  
  obs$add(observeEvent(input$btActionUpdate,{
    
    
  },ignoreInit = T))
  
  
}
