uiContatoNew <- function(con,input,output,user,callback){
  
  source('model/SmartObserve.R',local = T)
  obs  <- newObserve()
  
  eventos         <- list()
  tabelasEmails   <- reactiveVal(NULL)
  tabelasPhones   <- reactiveVal(NULL)
  flag.insert     <- 0
  currentPosition <- reactiveVal(1)
  
  showModal(
    dialogModal(
      title = dialogTitleClose('Novo Cadastro de contatos',function(){
        
        DBI::dbDisconnect(con)
        obs$destroy()
        removeModal()
        callback()
        
      }),
      size = 'm',
      swiper(id = 'swiperMain',
             parent.style = 'height: 450px; width: 100%;',
             width = '100%',
             height = '100%',
             swiperSlide(
               style = 'height: 100%; width: 100%; overflow-y: auto;',
               uiOutput('slider1',style = 'height: 100%; width: 100%;')
             ),
             swiperSlide(
               style = 'height: 100%; width: 100%;',
               uiOutput('slider2',style = 'height: 100%; width: 100%;')
             )
      ),
      footer = tagList(shiny::actionButton(inputId = "btSair","Sair"),actionButton('btSalvarContato','Salvar'))))
  
  
  insertTables <- function(flag){
    
    table   <- NA
    data   <- NA
    if(flag == 1){
      
      email <- input$textEmail
      
      if(stringi::stri_isempty(stringr::str_trim(email))){
        showNotification("O campo Endereço de email não foi preenchido!", type = "warning") 
        return(FALSE)
      }
      
      
      if(!isValidEmail(email)){
        showNotification("Endereço de email invalido!", type = "warning")  
        return(FALSE)
      }
      
      table   <- isolate(tabelasEmails())
      
      if(any(sapply(table[,2], function(x) { x == email}))){
        
        showNotification("Ja existe esse endereço de email nos registros!", type = "warning")  
        return(FALSE)
      }
      
      
      linha   <- ifelse(is.null(table), 1, nrow(table) + 1)
      
      data <- data.frame(
        'LINHA' = linha,
        'ENDEREÇO_EMAIL' = email,
        'REMOVER' = as.character(
          actionButton(
            paste0('btRemove',linha),
            label = '',
            icon = icon('trash'),
            onclick = paste0('Shiny.setInputValue(\"emailDeletePressedRow\","',email,'",{priority: "event"})'),
            #style = 'background-color: transparent; color: lightblue; border-solid: none;'
          )
        )
        
      )
    }
    else{
      
      fone    <- input$textPhone
      
      if(stringi::stri_isempty(stringr::str_trim(fone))){
        showNotification("O campo numero do telefone não foi preenchido!", type = "warning") 
        return(FALSE)
      }
      
      table   <- isolate(tabelasPhones())
      
      if(any(sapply(table[,2], function(x) { x == fone}))){
        
        showNotification("Ja existe esse numero de celular nos registros!", type = "warning")  
        return(FALSE)
      }
      
      linha   <- ifelse(is.null(table), 1, nrow(table) + 1)
      
      data <- data.frame(
        'LINHA' = linha,
        'NUMERO_CELULAR' = fone,
        'REMOVER' = as.character(
          actionButton(
            paste0('btRemove',linha),
            label = '',
            icon = icon('trash'),
            onclick = paste0('Shiny.setInputValue(\"foneDeletePressedRow\","',fone,'",{priority: "event"})'),
            #style = 'background-color: transparent; color: lightblue; border-solid: none;'
          )
        )
        
      )
    }
    
    #update table
    if(flag == 1)
      tabelasEmails(rbind(table,data))
    else
      tabelasPhones(rbind(table,data))
    
    return(TRUE)
  }

  output$slider1 <- renderUI({
    
    req(currentPosition() == 1)
    
    output$divtableEmails <- DT::renderDataTable({
      
      req(tabelasEmails())
      
      table <- tabelasEmails()
      
      if(is.null(table)){
        
        table <- data.frame(
          LINHA  = '',
          ENDEREÇO_EMAIL =  '',
          REMOVER = ''
        )
      }
      
      DT::datatable(table,
                    class = 'cell-border stripe',
                    extensions = 'Scroller',
                    options = list(
                      dom = 't',
                      bSort=FALSE,
                      columnDefs = list(list(visible=FALSE, targets=c(0)),list(className = 'dt-center', targets = "_all")),
                      deferRender = TRUE,
                      scroller = FALSE
                    ),
                    escape = F,
                    selection = 'none',
      )  %>% DT::formatStyle(colnames(result), cursor = 'pointer')
      
    })
    
    output$divtablePhones <- DT::renderDataTable({
      
      req(tabelasPhones())
      
      table <- tabelasPhones()
      
      if(is.null(table)){
        
        table <- data.frame(
          LINHA  = '',
          NUMERO_CELULAR =  '',
          REMOVER = ''
        )
      }
      
      DT::datatable(table,
                    class = 'cell-border stripe',
                    extensions = 'Scroller',
                    options = list(
                      dom = 't',
                      bSort=FALSE,
                      columnDefs = list(list(visible=FALSE, targets=c(0)),list(className = 'dt-center', targets = "_all")),
                      deferRender = TRUE,
                      scroller = FALSE
                    ),
                    escape = F,
                    selection = 'none',
      )  %>% DT::formatStyle(colnames(result), cursor = 'pointer')
      
    })
    
    div(
      shiny::splitLayout(
        shinyjs::inlineCSS("#textNome {text-transform: uppercase;}"),
        textInput('textNome',label = 'Nome',placeholder = 'Digite o nome da pessoa',value = isolate(input$textNome)),
        div(style = 'margin-top: 25px; margin-left: 5px;',actionButton('btNovoEmail','Novo',icon = icon('envelope'))),
        div(style = 'margin-top: 25px; margin-left: 5px;',actionButton('btNovoFone','Novo',icon = icon('mobile'))),
        cellWidths = 'auto'
      ),
      DT::dataTableOutput("divtableEmails"),
      DT::dataTableOutput("divtablePhones")
    )
    
  })
  
  output$slider2 <- renderUI({
    
    req(currentPosition() == 2)
    
    tagList(
      uiOutput("divConfiguracaoEmailPhone")
    )
  })
  
  obs$add(observeEvent(input$emailDeletePressedRow,{
    
    email <- input$emailDeletePressedRow
    table <- isolate(tabelasEmails())
    table <- table %>% filter('ENDEREÇO_EMAIL' != email)
    
    if(nrow(table) > 0){
      tabelasEmails(table  %>% mutate(LINHA = 1:nrow(table)))
    }
    else{
      tabelasEmails(NULL)
    }
    
  },ignoreInit = T))
  
  obs$add(observeEvent(input$foneDeletePressedRow,{
    
    fone   <- input$foneDeletePressedRow
    table  <- isolate(tabelasPhones())
    table  <- table %>% filter(NUMERO_CELULAR != fone)
    
    if(nrow(table) > 0){
      tabelasPhones(table  %>% mutate(LINHA = 1:nrow(table)))
    }
    else{
      tabelasPhones(NULL)
    }
    
  },ignoreInit = T))
  
  obs$add(observeEvent(input$btNovoEmail,{
    
    updateActionButton(getDefaultReactiveDomain(),'btSair',label = "Voltar")
    updateActionButton(getDefaultReactiveDomain(),'btSalvarContato',label = "Inserir")
    flag.insert <<- 1
    
    output$divConfiguracaoEmailPhone <- renderUI({
      
      tagList(
        h4("Digite o endereço de email"),
        br(),
        textInput('textEmail',label = 'Endereço Email',placeholder = 'exemplo: email@hotmail.com')
      )
      
    })
    
    swiperSlideNext()
    currentPosition(swiperPosition)
    
  },ignoreInit = T))
  
  obs$add(observeEvent(input$btNovoFone,{
    
    updateActionButton(getDefaultReactiveDomain(),'btSair',label = "Voltar")
    updateActionButton(getDefaultReactiveDomain(),'btSalvarContato',label = "Inserir")
    
    flag.insert <<- 2
    
    output$divConfiguracaoEmailPhone <- renderUI({
      
      delay(100,{
        cleave(getDefaultReactiveDomain(), "#textPhone", list(
          phone = TRUE,
          phoneRegionCode = "BR"
        ))
      })
      
      tagList(
        h4("Digite o numero do telefone"),
        br(),
        phoneInput("textPhone","Telefone:",placeholder = "ex: 99 99999 9999")
      )
      
    })
    
    swiperSlideNext()
    currentPosition(swiperPosition)
    
  },ignoreInit = T))
  
  obs$add(observeEvent(input$btSair,{
    
    current <- swiperPosition
    
    if(current == 2){
      
      updateActionButton(getDefaultReactiveDomain(),'btSair',label = "Sair")
      updateActionButton(getDefaultReactiveDomain(),'btSalvarContato',label = "Salvar")
      flag.insert <<- 0
      
      swiperSlidePrevious()
      currentPosition(swiperPosition)
      
    }else{
      
      DBI::dbDisconnect(con)
      obs$destroy()
      removeModal()
      callback()
      
    }
    
  },ignoreInit = T))
  
  obs$add(observeEvent(input$btSalvarContato,{
    
    current <- swiperPosition
    
    if(current == 2){
      
      updateActionButton(getDefaultReactiveDomain(),'btSair',label = "Sair")
      updateActionButton(getDefaultReactiveDomain(),'btSalvarContato',label = "Salvar")
      
      if(!insertTables(flag.insert)) return()
      
      flag.insert <<- 0
      swiperSlidePrevious()
      currentPosition(swiperPosition)
      return()
    }
    
    #check if name isn't empty
    nome <- isolate(input$textNome)
    
    if(stringi::stri_isempty(stringr::str_trim(nome))){
      showNotification("O campo do nome não foi preenchido!", type = "warning") 
      return()
    }
    
    emails <- isolate(tabelasEmails())
    fones  <- isolate(tabelasPhones())
    
    id <- nextSequenciaID(con,"CONTATOS_USER")
    #insert new email
    insertTable(con,"CONTATOS_USER",list(
      CD_ID_CONTATO = id,
      NAME_CONTATO  = toupper(nome),
      CD_ID_USER    = user$CD_ID_USER
    ))
    
    #Insert all register of the emails
    sapply(emails[,2],function(email){
      
      insertTable(con,"EMAILS",list(
        ADDRESS_EMAIL = email,
        CD_ID_CONTATO = id
      ))
      
    })
    
    #Insert all register of the fones
    sapply(fones[,2],function(fone){
      
      insertTable(con,"PHONES",list(
        NUMBER_PHONE  = stringr::str_replace_all(fone," ",""),
        CD_ID_CONTATO = id
      ))
      
    })
    
    updateTextInput(getDefaultReactiveDomain(),inputId = "textNome",value = "")
    
    dialogConfirm(
      title = 'Contato criado com sucesso!',
      text = 'Deseja criar novamente um novo Contato?',
      callback = function(status) {
        
        if(!status){
          DBI::dbDisconnect(con)
          obs$destroy()
          removeModal()
          callback()
        }
        else{ 
          tabelasEmails(NULL)
          tabelasPhones(NULL)
          flag.insert   <<- 0
          currentPosition(1)
        }
        
      })
    
    
  },ignoreInit = T))
}

uiContatoTable <- function(input,output,user,con,contatos,callback){
  
  source('model/SmartObserve.R',local = T)
  obs  <- newObserve()
  
  contato         <- NULL
  observeEvents   <- list()
  contatos        <- reactiveVal(contatos)
  tabelasEmails   <- reactiveVal(NULL)
  tabelasPhones   <- reactiveVal(NULL)
  editable        <- FALSE
  currentPosition <- reactiveVal(1)
  tipoEdicao      <- NA
  
  
  #Modal para Dialog
  showModal(dialogModal(
    title = dialogTitleClose('Registro Contatos',function(){
      
      DBI::dbDisconnect(con)
      obs$destroy()
      removeModal()
      callback()
      
    }),
    size = 'l',
    swiper(id = 'swiperMain',
           parent.style = 'height: 450px; width: 100%;',
           width = '100%',
           height = '100%',
           swiperSlide(
             style = 'height: 100%; width: 100%; overflow-y: auto;',
             uiOutput('slider1',style = 'height: 100%; width: 100%;')
           ),
           swiperSlide(
             style = 'height: 100%; width: 100%;',
             uiOutput('slider2',style = 'height: 100%; width: 100%;')
           )
    ),
    footer = uiOutput('uiFooter'),
    callback = function(size){onResizedWindows(list(height = size$height))}
  ))
  
  output$uiFooter <- renderUI({
    
    current <- currentPosition()
    
    if(current == 1){
      tagList(actionButton('btActionCancel', label = "Sair"))
    }
    else{
      tagList(actionButton('btActionCancel', label = "Voltar"),actionButton('btActionUpdate', label = "Atualizar"))
    }
    
    
  })
  
  output$slider1 <- renderUI({
    
    req(currentPosition() == 1)
    
    output$divtableEmails <- DT::renderDataTable({
      
      req(length(tabelasEmails()) > 0)
      
      table <- tabelasEmails()
      
      shiny::req(table)
      
      colunaNames <- c('LINHA','ENDEREÇO EMAIL','VISUALIZAR / EDITAR','REMOVER')
  
      DT::datatable(table %>% mutate(
        !!colunaNames[1] :=  1:nrow(table),
        !!colunaNames[2] :=  table$ADDRESS_EMAIL,
        !!colunaNames[3] :=  apply(table,1,function (x) {
          
          as.character(
            actionButton(
              paste0('btEdit'),
              label = '',
              icon = icon('eye'),
              onclick = paste0('Shiny.setInputValue(\"editPressedRow\",',jsonlite::toJSON(list(tipo = 0x00,data = x),auto_unbox = T),',{priority: "event"})'),
              #style = 'background-color: transparent; color: lightblue; border-solid: none;'
            )
          )
        }),
        !!colunaNames[4] := apply(table,1, function (x) {
          
          as.character(
            actionButton(
              paste0('btRemove'),
              label = '',
              icon = icon('trash'),
              onclick = paste0('Shiny.setInputValue(\"deletePressedRow\",',jsonlite::toJSON(list(tipo = 0x00,data = x),auto_unbox = T),',{priority: "event"})'),
              #style = 'background-color: transparent; color: lightblue; border-solid: none;'
            )
          )
          
        })
      ) %>% select(colunaNames),
      class = 'cell-border stripe',
      extensions = 'Scroller',
      options = list(
        dom = 't',
        bSort=FALSE,
        columnDefs = list(list(visible=FALSE, targets=c(0)),list(className = 'dt-center', targets = "_all"),list(width = 'autos',targets = c(3))),
        deferRender = TRUE,
        scroller = FALSE
      ),
      escape = F,
      selection = 'none',
      
      )  %>% DT::formatStyle(colnames(result), cursor = 'pointer')
      
    })
    
    output$divtablePhones <- DT::renderDataTable({
      
      req(nrow(tabelasPhones()) > 0)
      
      table <- tabelasPhones()
      
      shiny::req(table)
      
      colunaNames <- c('LINHA','NUMERO CELULAR','VISUALIZAR / EDITAR','REMOVER')
      
      DT::datatable(table %>% mutate(
        !!colunaNames[1] :=  1:nrow(table),
        !!colunaNames[2] :=  table$NUMBER_PHONE,
        !!colunaNames[3] :=  apply(table,1,function (x) {
          
          as.character(
            actionButton(
              paste0('btEdit'),
              label = '',
              icon = icon('eye'),
              onclick = paste0('Shiny.setInputValue(\"editPressedRow\",',jsonlite::toJSON(list(tipo = 0x00,data = x),auto_unbox = T),',{priority: "event"})'),
              #style = 'background-color: transparent; color: lightblue; border-solid: none;'
            )
          )
        }),
        !!colunaNames[4] := apply(table,1, function (x) {
          
          as.character(
            actionButton(
              paste0('btRemove'),
              label = '',
              icon = icon('trash'),
              onclick = paste0('Shiny.setInputValue(\"deletePressedRow\",',jsonlite::toJSON(list(tipo = 0x00,data = x),auto_unbox = T),',{priority: "event"})'),
              #style = 'background-color: transparent; color: lightblue; border-solid: none;'
            )
          )
          
        })
      ) %>% select(colunaNames),
      class = 'cell-border stripe',
      extensions = 'Scroller',
      options = list(
        dom = 't',
        bSort=FALSE,
        columnDefs = list(list(visible=FALSE, targets=c(0)),list(className = 'dt-center', targets = "_all"),list(width = 'autos',targets = c(3))),
        deferRender = TRUE,
        scroller = FALSE
      ),
      escape = F,
      selection = 'none',
      )  %>% DT::formatStyle(colnames(result), cursor = 'pointer')
      
    })
    
    div(
      shiny::splitLayout(
        uiOutput('comboBoxEditable'),
        div(style = 'margin-top: 25px; margin-left: 5px;',actionButton('btEditarContato','Editar',icon = icon('edit'))),
        div(style = 'margin-top: 25px; margin-left: 5px;',actionButton('btRemoveContato','Remover',icon = icon('trash'))),
        cellWidths = 'auto'
      ),
      div(
        style = "border-style: inset; border-width: 1px; border-top: none; border-left:none; border-right: none;",
        DT::dataTableOutput("divtableEmails")
      ),
      div(
        style = "border-style: inset; border-width: 1px; border-top: none; border-left:none; border-right: none;",
        DT::dataTableOutput("divtablePhones")
      )
    )
    
  })
  
  output$slider2 <- renderUI({
    
    req(currentPosition() == 2)
    
    if(tipoEdicao$tipo == 0x00){ #Email
      
      tagList(
        h4("Digite o endereço de email"),
        br(),
        textInput('textEmail',label = 'Endereço Email',placeholder = 'exemplo: email@hotmail.com',value = tipoEdicao$data[[2]])
      )
      
    }else{ #Fone
      
      delay(100,{
        cleave(getDefaultReactiveDomain(), "#textPhone", list(
          phone = TRUE,
          phoneRegionCode = "BR"
        ))
      })
      
      tagList(
        h4("Digite o numero do telefone"),
        br(),
        phoneInput("textPhone","Telefone:",placeholder = "ex: 99 99999 9999",value = tipoEdicao$data[[2]])
      )
      
    }
    
  })
  
  output$comboBoxEditable <- renderUI({
    selectInput('comboContatos',label = 'Seleciona Contato',choices = isolate(contatos())$NAME_CONTATO)
  })
  
  obs$add(observeEvent(input$comboContatos,{
    
    shiny::req(!editable)
    
    tryResetConnection(con,function(coon){
      
      con <<- coon
      
      contato   <<- isolate(contatos()) %>% filter(NAME_CONTATO == input$comboContatos)
      tabelasEmails(selectEmails(con,contato))
      tabelasPhones(selectPhones(con,contato))
      
    })
    
  }))
  
  obs$add(observeEvent(input$btEditarContato,{
    
    editable     <<- !editable
    nome         <- toupper(isolate(input$comboContatos))
    contatosUser <- isolate(contatos())
    
    if(editable){
      
      updateActionButton(getDefaultReactiveDomain(),'btEditarContato',label = 'Salvar')
      updateActionButton(getDefaultReactiveDomain(),'btRemoveContato',label = 'Cancelar',icon = icon("times-circle"))
      
      output$comboBoxEditable <- renderUI({
        
        div(
          shinyjs::inlineCSS("#comboContatos {text-transform: uppercase;}"),
          textInput('comboContatos',label = 'Seleciona Contato',value = nome)
        )
      })
      
    }
    else{
      
      #Salvar
      if(unmatrix(DBI::dbGetQuery(con,"SELECT COUNT(*) FROM CONTATOS_USER WHERE NAME_CONTATO = ?",params = list(nome))) > 0){
        
        showNotification("O nome do contato já existe nos registros!", type = "warning")
        editable     <<- TRUE
        return()
      }
      
      updateTable(con,table = 'CONTATOS_USER',where = paste0("CD_ID_CONTATO = ",contato$CD_ID_CONTATO),obj = list(
        NAME_CONTATO = nome
      ))
      
      updateActionButton(getDefaultReactiveDomain(),'btEditarContato',label = 'Editar')
      updateActionButton(getDefaultReactiveDomain(),'btRemoveContato',label = 'Remover',icon = icon("trash"))
      
      updateContatos <- DBI::dbGetQuery(con,"SELECT * FROM CONTATOS_USER WHERE CD_ID_USER = ?",params = list(user$CD_ID_USER))
      
      output$comboBoxEditable <- renderUI({
        
        selectInput('comboContatos',label = 'Seleciona Contato',choices = updateContatos$NAME_CONTATO)
        
      })
      
      contatos(updateContatos)
    }
    
  },ignoreInit = T))
  
  obs$add(observeEvent(input$btRemoveContato,{
    
    if(editable)
    {
      editable <<- FALSE
      updateActionButton(getDefaultReactiveDomain(),'btEditarContato',label = 'Editar')
      updateActionButton(getDefaultReactiveDomain(),'btRemoveContato',label = 'Remover',icon = icon("trash"))
      
      output$comboBoxEditable <- renderUI({
        
        selectInput('comboContatos',label = 'Seleciona Contato',choices = isolate(contatos())$NAME_CONTATO)
      })
    }
    
    
  },ignoreInit = T))
  
  # 
  obs$add(observeEvent(input$btActionCancel,{
    
    current <- swiperPosition
    
    if(current == 1){
      
      DBI::dbDisconnect(con)
      obs$destroy()
      removeModal()
      callback()
    }
    else{
      swiperSlidePrevious()
      currentPosition(swiperPosition)
    }
    
  },ignoreInit = T))
  
  obs$add(observeEvent(input$btActionUpdate,{
    
    tryResetConnection(con,function(conn){
      
      con <<- conn
      
      if(tipoEdicao$tipo == 0x00){ #Email
        
        obj                <- list()
        obj$ADDRESS_EMAIL  <- input$textEmail
        
        updateTable(con,table = "EMAILS",where = paste0('CD_ID_EMAIL = ',tipoEdicao$data[1]),obj = obj)
        tabelasEmails(DBI::dbGetQuery(con,"SELECT * FROM EMAILS WHERE CD_ID_CONTATO = ?",params = list(tipoEdicao$data[[3]])))
        
        
      }else{ #Fone
        
        obj                <- list()
        obj$NUMBER_PHONE   <- input$textPhone
        
        updateTable(con,table = "PHONES",where = paste0('CD_ID_PHONE = ',tipoEdicao$data[1]),obj = obj)
        tabelasPhones(DBI::dbGetQuery(con,"SELECT * FROM PHONES WHERE CD_ID_CONTATO = ?",params = list(tipoEdicao$data[[3]])))
        
      }
      
      swiperSlidePrevious()
      currentPosition(swiperPosition)
      
    })
    
    
  },ignoreInit = T))
  
  obs$add(observeEvent(input$editPressedRow,{
    
    tipoEdicao <<- input$editPressedRow
    
    swiperSlideNext()
    currentPosition(swiperPosition)
    
  },ignoreInit = T))
  
  obs$add(observeEvent(input$deletePressedRow,{
    
    tipoEdicao <<- input$editPressedRow
    tipo       <-  ifelse(tipoEdicao$tipo == 0x00,'email','telefone')
    
    messageAlerta(input,
                  title   = paste0('Todos os processos ligado a esse registro será excluido'),
                  message = paste0('Deseja realmente excluir o ',tipo,' ',tipoEdicao$data[[2]],"?"),
                  callback.no = function(){},
                  callback.yes = function(){
                    
                    tryResetConnection(con,function(conn){
                      
                      con <<- conn
                      table <- ifelse(tipoEdicao$tipo == 0x00,'EMAILS','PHONES')
                      id    <- ifelse(tipoEdicao$tipo == 0x00,'CD_ID_EMAIL','CD_ID_PHONE')
                      
                      deleteTable(con,table,where = paste0(id," = ",tipoEdicao$data[[1]]))
                      
                      if(tipoEdicao$tipo == 0x00){#EMAIS
                        tabelasEmails(ttabelasEmails() %>% filter(CD_ID_EMAIL != tipoEdicao$data[[1]]))
                      }else{#PHONES
                        tabelasPhones(tabelasPhones() %>% filter(CD_ID_PHONE != tipoEdicao$data[[1]]))
                      }
                      
                    })
                    
                  })
    
  },ignoreInit = T))

}

