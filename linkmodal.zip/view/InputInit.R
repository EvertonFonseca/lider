shinyjs::onclick('dashCentral',{
  
  if(event.click) return(NULL)
  
  event.click <<- TRUE
  
  if (!is.null(processo.now))
  {
    processo.now$stop()
  }

  shinyjs::delay(100,{
    event.click <<- FALSE
    shinyjs::hide(id = 'btStatusProcesso')
  })
  
})

shinyjs::onclick('dashSetores',{
  
  if(event.click) return(NULL)
  
  event.click <<- TRUE
  
  shinyjs::show(id = 'btStatusProcesso')
  
  if (!is.null(processo.now))
  {
    processo.now$start()
  }
  shinyjs::delay(100,{event.click <<- FALSE})
})

shinyjs::onclick('setorNew',{
  
  if(event.click) return(NULL)
  
   event.click <<- TRUE
  
  if (!is.null(processo.now))
  {
    processo.now$stop()
  }
  
  actionWebUser(function() {
    
    env <- environment()
    
    source('control/Database.R',encoding = "UTF-8",env)
    
    con     <- newConnection()
    
    tryResetConnection(con,function(conn){
      
      con <<- conn
      
      source('view/uiSetor.R',encoding = 'UTF-8',env)
      source('model/Dialog.R',encoding = 'UTF-8',env)
      source('model/Swiper.R',encoding = 'UTF-8',env)
      source('control/Setor_DAO.R',env)
 
      # New Dialog
      uiSetorNew(
        con = con,
        input = input,
        output = output,
        user = user,
        callback = function(setor) {
          
          processos   <<- rlist::list.append(processos,uiTabSetor(input,output,setor))
          
        },
        callback.exit = function(){
          
          if(!is.null(processo.now))
          {
            processo.now$start()
          }

          event.click <<- FALSE
          rm(list = ls(all.names = T,envir = env),envir = env)
          gc()
        })
      
    })
  })
  
})

shinyjs::onclick('setorTable',{
  
  if(event.click) return(NULL)
  
  event.click <<- TRUE
  
  if(!is.null(processo.now))
  {
    processo.now$stop()
  }
  
  actionWebUser(function(){
    
    env <- environment()
    
    source('control/Database.R',encoding = "UTF-8",env)
    
    con  <- newConnection()
    
    tryResetConnection(con,function(con){
      
      source('view/uiSetor.R',encoding = 'UTF-8',env)
      source('model/Dialog.R',encoding = 'UTF-8',env)
      source('model/Swiper.R',encoding = 'UTF-8',env)
      source('control/Setor_DAO.R',env)
      
      setores <- selectSetoresOnly(con,user)
      
      if(nrow(setores) == 0){
        
        showNotification("Não foi possivel executar essa operação, nenhum registro de setor foi encontrado!", type = "error")
        
        if (!is.null(processo.now))
        {
          processo.now$start()
        }
        DBI::dbDisconnect(con)
        removeProgressLoader(1000)
        
        event.click <<- FALSE
        rm(list = ls(all.names = T,envir = env),envir = env)
        gc()
        return()
      }
      
      uiSetorTable(input = input,output = output,user = user,con = con,setores = setores,processos,callback = function(setores){
        
        #Todos os setores foram excluidos
        if(is.null(setores)){
          
          processos    <<- list()
          processo.now <<- NULL
        }
        else{
          #remove os setores que foram excluidos
          processos <<- removeProcess(processos,setores)
          
          if(!is.null(processo.now))
          {
            if(!rlist::list.any(processos,id == processo.now$id)){
              
              processo.now <<- NULL
            }
            else{
              processo.now$start()
            }
            
          }
          
        }
        event.click <<- FALSE
        rm(list = ls(all.names = T,envir = env),envir = env)
        gc()
      })
      
    })
  })
})

shinyjs::onclick('setorLayout',{
  
  if(event.click) return(NULL)
  
   event.click <<- TRUE
  
  if(!is.null(processo.now))
  {
    processo.now$stop()
  }
  
  actionWebUser(function(){
    
    env <- environment()
    
    source('control/Database.R',encoding = "UTF-8",env)
    
    con  <- newConnection()
    
    tryResetConnection(con,function(con){
      
      source('view/uiSetor.R',encoding = 'UTF-8',env)
      source('control/Setor_DAO.R',encoding = 'UTF-8',env)
      source('control/Plot_DAO.R',encoding = 'UTF-8',env)
      source('model/Dialog.R',encoding = 'UTF-8',env)
      
      setores <- selectSetoresOnly(con,user)
      plots   <- selelectAllPlots(con)
      
      if(length(setores) == 0){
        
        showNotification("Não foi possivel executar essa operação, nenhum registro de setor foi encontrado!", type = "error")
        
        if (!is.null(processo.now))
        {
          processo.now$start()
        }
        DBI::dbDisconnect(con)
        
        event.click <<- FALSE
        removeProgressLoader(1000)
        rm(list = ls(all.names = T,envir = env),envir = env)
        gc()
        return()
      }
      
      #New Dialog
      uiLayout(con,input,output,setores,plots,function(p,status){
        
        switch (as.character(status),
                '0' = {
                  
                  if (!is.null(processo.now))
                  {
                    processo.now$start()
                  }
                  event.click <<- FALSE
                  DBI::dbDisconnect(con)
                  rm(list = ls(all.names = T,envir = env),envir = env)
                  gc()
                  
                }, #nothingm
                '1' = {
                  
                  if (!is.null(processo.now))
                  {
                    if(p$CD_ID_SETOR == processo.now$id)
                    {
                      actionWebUser(function(){
                        
                        processo.now$updatePlots(p)
                        
                      },auto.remove = T)
                    }
                  }
                  
                }, # update ordem
                '-1' = {
                  
                  showNotification("Não foi possivel executar essa operação, nenhum registro de grafico foi encontrado!", type = "error")
                  if (!is.null(processo.now))
                  {
                    processo.now$start()
                  }
                  DBI::dbDisconnect(con)
                  
                  event.click <<- FALSE
                  removeProgressLoader(1000)
                  rm(list = ls(all.names = T,envir = env),envir = env)
                  gc()
                  
                }# error not plot
        )
        
      })
      
      
    })
    
  })
  
})

shinyjs::onclick('objetoNew',{
  
  if(event.click) return(NULL)
  
    event.click <<- TRUE
  
  if (!is.null(processo.now))
  {
    processo.now$stop()
  }
  
  actionWebUser(function() {
    
    env <- environment()
    
    source('control/Database.R',encoding = "UTF-8",env)
    
    con     <- newConnection()
    
    tryResetConnection(con,function(conn){
      
      con <<- conn
      
      source('view/uiObject.R',encoding = 'UTF-8',env)
      source('model/Dialog.R',encoding = 'UTF-8',env)
      source('model/Swiper.R',encoding = 'UTF-8',env)
      source('control/Model_DAO.R',env)
      source('control/Object_DAO.R',env)
      source('control/Setor_DAO.R',env)
      
      setores    <- selectSetoresOnly(con,user)
      estruturas <- selectAllEstruturas(con)
      
      
      if(nrow(setores) == 0){
        
        showNotification("Não foi possivel executar essa operação, nenhum registro de setor foi encontrado!", type = "error")
        
        if (!is.null(processo.now))
        {
          processo.now$start()
        }
        event.click <<- FALSE
        DBI::dbDisconnect(con)
        removeProgressLoader(1000)
        
        rm(list = ls(all.names = T,envir = env),envir = env)
        gc()
        return()
      }
      
      
      if(nrow(estruturas) == 0){
        
        showNotification("Não foi possivel executar essa operação, nenhum registro de estruturas foi encontrado!", type = "error")
        
        if (!is.null(processo.now))
        {
          processo.now$start()
        }
        event.click <<- FALSE
        DBI::dbDisconnect(con)
        removeProgressLoader(1000)
        
        rm(list = ls(all.names = T,envir = env),envir = env)
        gc()
        return()
      }
      
      uiObjectNew(con, input, output,setores,estruturas,callback = function() {
        
        if (!is.null(processo.now))
        {
          processo.now$start()
        }

        event.click <<- FALSE
        rm(list = ls(all.names = T,envir = env),envir = env)
        gc()
        
      })
      
    })
    
  })
  
})

shinyjs::onclick('objetoTable',{
  
  if(event.click) return(NULL)
  
   event.click <<- TRUE
  
  if (!is.null(processo.now))
  {
    processo.now$stop()
  }
  
  actionWebUser(function() {
    
    env <- environment()
    
    source('control/Database.R',encoding = "UTF-8",env)
    
    con     <- newConnection()
    
    tryResetConnection(con,function(conn){
      
      con <<- conn
      
      source('view/uiObject.R',encoding = 'UTF-8',env)
      source('model/Dialog.R',encoding = 'UTF-8',env)
      source('model/Swiper.R',encoding = 'UTF-8',env)
      source('control/Model_DAO.R',env)
      source('control/Setor_DAO.R',env)
      source('control/Object_DAO.R',env)
      
      setores    <- selectSetoresOnly(con,user)
      estruturas <- selectAllEstruturas(con)
      objetos    <- selectAllObjects(con)
      
      
      if(nrow(setores) == 0){
        
        showNotification("Não foi possivel executar essa operação, nenhum registro de setor foi encontrado!", type = "error")
        
        if (!is.null(processo.now))
        {
          processo.now$start()
        }
        event.click <<- FALSE
        DBI::dbDisconnect(con)
        removeProgressLoader(1000)
        
        rm(list = ls(all.names = T,envir = env),envir = env)
        gc()
        return()
      }
      
      
      if(nrow(estruturas) == 0){
        
        showNotification("Não foi possivel executar essa operação, nenhum registro de estruturas foi encontrado!", type = "error")
        
        if (!is.null(processo.now))
        {
          processo.now$start()
        }
        event.click <<- FALSE
        DBI::dbDisconnect(con)
        removeProgressLoader(1000)
        
        rm(list = ls(all.names = T,envir = env),envir = env)
        gc()
        return()
      }
      
      
      if(nrow(objetos) == 0){
        
        showNotification("Não foi possivel executar essa operação, nenhum registro de objetos foi encontrado!", type = "error")
        
        if (!is.null(processo.now))
        {
          processo.now$start()
        }
        event.click <<- FALSE
        DBI::dbDisconnect(con)
        removeProgressLoader(1000)
        
        rm(list = ls(all.names = T,envir = env),envir = env)
        gc()
        return()
      }
      
      uiObjectTable(con,input, output,setores,estruturas,objetos,callback = function(status) {
        
        if (!is.null(processo.now))
        {
          if(status){
            #remove todos plot cache
            keys <- systemCache$keys()
            keys <- keys[stringr::str_starts(systemCache$keys(),paste0('dataplotcache',processo.now$id))]
            sapply(keys, function(x) systemCache$remove(x))
          }
          
          processo.now$start()
        }
        event.click <<- FALSE
        
        rm(list = ls(all.names = T,envir = env),envir = env)
        gc()
        
      })
      
    })
    
  })
  
})

shinyjs::onclick('serverNew',{
  
  if(event.click) return(NULL)
  
  event.click <<- TRUE
  
  if (!is.null(processo.now))
  {
    processo.now$stop()
  }
  
  actionWebUser(function() {
    
    env <- environment()
    
    source('control/Database.R',encoding = "UTF-8",env)
    
    con     <- newConnection()
    
    tryResetConnection(con,function(conn){
      
      con <<- conn
      
      source('view/uiServer.R',encoding = 'UTF-8',env)
      source('model/Dialog.R',encoding = 'UTF-8',env)
      source('model/Swiper.R',encoding = 'UTF-8',env)
      source('control/Server_DAO.R',env)
      source('control/Driver_DAO.R',env)
      
      driver <- selectAllDrivers(con)
      
      uiServerNew(con, input, output,driver, callback = function() {
        
        if (!is.null(processo.now))
        {
          processo.now$start()
        }
        event.click <<- FALSE
        rm(list = ls(all.names = T,envir = env),envir = env)
        gc()
        
      })
      
    })
  })
})

shinyjs::onclick('serverTable',{
  
  if(event.click) return(NULL)
  
    event.click <<- TRUE
  
  if (!is.null(processo.now))
  {
    processo.now$stop()
  }
  
  actionWebUser(function() {
    
    env <- environment()
    
    source('control/Database.R',encoding = "UTF-8",env)
    
    con     <- newConnection()
    
    tryResetConnection(con,function(conn){
      
      con <<- conn
      
      source('view/uiServer.R',encoding = 'UTF-8',env)
      source('model/Dialog.R',encoding = 'UTF-8',env)
      source('model/Swiper.R',encoding = 'UTF-8',env)
      source('control/Server_DAO.R',env)
      source('control/Driver_DAO.R',env)
      
      driver <- selectAllDrivers(con)
      server <- selectAllServerWithDriver(con)
      driver <- driver %>% filter((NAME_DRIVER %in% server$NAME_DRIVER))
      
      if(nrow(server) == 0){
        
        showNotification("Não foi possivel executar essa operação, nenhum registro de servidores foi encontrado!", type = "error")
        
        if (!is.null(processo.now))
        {
          processo.now$start()
        }
        event.click <<- FALSE
        DBI::dbDisconnect(con)
        removeProgressLoader(1000)
        
        rm(list = ls(all.names = T,envir = env),envir = env)
        gc()
        return()
      }
      
      uiServerTable(con, input, output,server,driver,callback = function() {
        
        if (!is.null(processo.now))
        {
          processo.now$start()
        }
        event.click <<- FALSE
        
        rm(list = ls(all.names = T,envir = env),envir = env)
        gc()
        
      })
      
    })
  })
})

shinyjs::onclick('modeloNew',{
  
  if(event.click) return(NULL)
  
  event.click <<- TRUE
  
  if (!is.null(processo.now))
  {
    processo.now$stop()
  }
  
  actionWebUser(function() {
    
    env <- environment()
    
    source('control/Database.R',encoding = "UTF-8",env)
    
    con     <- newConnection()
    
    tryResetConnection(con,function(conn){
      
      con <<- conn
      
      source('view/uiModal.R',encoding = 'UTF-8',env)
      source('model/Dialog.R',encoding = 'UTF-8',env)
      source('model/Swiper.R',encoding = 'UTF-8',env)
      source('control/Server_DAO.R',env)
      source('control/Driver_DAO.R',env)
      source('control/Model_DAO.R',env)
      
      server    <- selectAllServerWithDriver(con)
      typedatas <- selectAllTypeDatas(con)
      timezones <- selectAllTimezones(con)

      if(nrow(server) == 0){
        
        showNotification("Não foi possivel executar essa operação, nenhum registro de servidores foi encontrado!", type = "error")
        
        if (!is.null(processo.now))
        {
          processo.now$start()
        }
        event.click <<- FALSE
        DBI::dbDisconnect(con)
        removeProgressLoader(1000)
        
        rm(list = ls(all.names = T,envir = env),envir = env)
        gc()
        return()
      }
      
      uiEstruturaNew(con, input, output,server,typedatas,timezones,callback = function() {
        
        if (!is.null(processo.now))
        {
          processo.now$start()
        }
        event.click <<- FALSE
        
        rm(list = ls(all.names = T,envir = env),envir = env)
        gc()
        
      })
      
    })
  })
  
  
})

shinyjs::onclick('modeloTable',{
  
  if(event.click) return(NULL)
  
  event.click <<- TRUE
  
  if (!is.null(processo.now))
  {
    processo.now$stop()
  }
  
  actionWebUser(function() {

    env <- environment()
    
    source('control/Database.R',encoding = "UTF-8",env)
    
    con     <- newConnection()
    
    tryResetConnection(con,function(conn){
      
      con <<- conn
      
      source('view/uiModal.R',encoding = 'UTF-8',env)
      source('model/Dialog.R',encoding = 'UTF-8',env)
      source('model/Swiper.R',encoding = 'UTF-8',env)
      source('control/Server_DAO.R',env)
      source('control/Driver_DAO.R',env)
      source('control/Model_DAO.R',env)
      
      server     <- selectAllServerWithDriver(con)
      typedatas  <- selectAllTypeDatas(con)
      estruturas <- selectAllEstruturas(con)
      timezones  <- selectAllTimezones(con) 
      
      if(nrow(server) == 0){
        
        showNotification("Não foi possivel executar essa operação, nenhum registro de servidores foi encontrado!", type = "error")
        
        if (!is.null(processo.now))
        {
          processo.now$start()
        }
        event.click <<- FALSE
        DBI::dbDisconnect(con)
        removeProgressLoader(1000)
        
        rm(list = ls(all.names = T,envir = env),envir = env)
        gc()
        return()
      }
      
      if(nrow(estruturas) == 0){
        
        showNotification("Não foi possivel executar essa operação, nenhum registro de estruturas foi encontrado!", type = "error")
        
        if (!is.null(processo.now))
        {
          processo.now$start()
        }
        event.click <<- FALSE
        DBI::dbDisconnect(con)
        removeProgressLoader(1000)
        
        rm(list = ls(all.names = T,envir = env),envir = env)
        gc()
        return()
      }
      
      uiEstruturaTable(con, input, output,server,typedatas,estruturas,timezones,callback = function() {
        
        if (!is.null(processo.now))
        {
          processo.now$start()
        } 
        event.click <<- FALSE
        
        rm(list = ls(all.names = T,envir = env),envir = env)
        gc()
        
      })
      
    })
  })
  
  
})

shinyjs::onclick('plotNew',{
  
  if(event.click) return(NULL)
  
   event.click <<- TRUE
  
  if (!is.null(processo.now))
  {
    processo.now$stop()
  }
  
  actionWebUser(function() {
    
    env <- environment()
    
    source('control/Database.R',encoding = "UTF-8",env)
    
    con     <- newConnection()
    
    tryResetConnection(con,function(conn){
      
      con <<- conn
      
      source('view/uiPlot.R',encoding = 'UTF-8',env)
      source('model/Dialog.R',encoding = 'UTF-8',env)
      source('model/Swiper.R',encoding = 'UTF-8',env)
      source('control/Setor_DAO.R',env)
      source('control/Model_DAO.R',env)
      source('control/Plot_DAO.R',env)
      source('control/Object_DAO.R',env)

      setores    <- selectSetoresOnly(con,user)
      typedatas  <- selectAllTypeDatas(con)
      tipoPlots  <- selectTypesPlots(con)
      estruturas <- selectAllEstruturas(con)
      objetos    <- selectAllObjects(con,check.fg.online = TRUE)

      if(nrow(setores) == 0){
        
        showNotification("Não foi possivel executar essa operação, nenhum registro de setor foi encontrado!", type = "error")
        
        if (!is.null(processo.now))
        {
          processo.now$start()
        }
        event.click <<- FALSE
        DBI::dbDisconnect(con)
        removeProgressLoader(1000)
        
        rm(list = ls(all.names = T,envir = env),envir = env)
        gc()
        return()
      }
      
      if(nrow(estruturas) == 0){
        
        showNotification("Não foi possivel executar essa operação, nenhum registro de estruturas foi encontrado!", type = "error")
        
        if (!is.null(processo.now))
        {
          processo.now$start()
        }
        event.click <<- FALSE
        DBI::dbDisconnect(con)
        removeProgressLoader(1000)
        
        rm(list = ls(all.names = T,envir = env),envir = env)
        gc()
        return()
      }
      
      if(nrow(objetos) == 0){
        
        showNotification("Não foi possivel executar essa operação, nenhum registro de objetos foi encontrado ou ativos!", type = "error")
        
        if (!is.null(processo.now))
        {
          processo.now$start()
        }
        event.click <<- FALSE
        DBI::dbDisconnect(con)
        removeProgressLoader(1000)
        
        rm(list = ls(all.names = T,envir = env),envir = env)
        gc()
        return()
      }
      #filter only setor has object children      
      setores    <- setores %>% filter(CD_ID_SETOR %in% objetos$CD_ID_SETOR)

      uiPlotNew(con,input,output,tipoPlots,setores,typedatas,estruturas,objetos,callback = function() {
        
        if (!is.null(processo.now))
        {
          processo.now$start()
        }
        event.click <<- FALSE
        
        rm(list = ls(all.names = T,envir = env),envir = env)
        gc()
        
      })
      
    })
  })
  
  
})

shinyjs::onclick('plotTable',{

  if(event.click) return(NULL)
  
   event.click <<- TRUE
  
  if (!is.null(processo.now))
  {
    processo.now$stop()
  }

  actionWebUser(function() {

    env <- environment()

    source('control/Database.R',encoding = "UTF-8",env)

    con     <- newConnection()

    tryResetConnection(con,function(conn){

      con <<- conn

      source('view/uiPlot.R',encoding = 'UTF-8',env)
      source('model/Dialog.R',encoding = 'UTF-8',env)
      source('model/Swiper.R',encoding = 'UTF-8',env)
      source('control/Setor_DAO.R',env)
      source('control/Model_DAO.R',env)
      source('control/Plot_DAO.R',env)
      source('control/Object_DAO.R',env)

      setores    <- selectSetoresOnly(con,user)
      typedatas  <- selectAllTypeDatas(con)
      tipoPlots  <- selectTypesPlots(con)
      estruturas <- selectAllEstruturas(con)
      objetos    <- selectAllObjects(con,check.fg.online = TRUE)
      plots      <- selelectAllPlots(con)

      if(nrow(setores) == 0){

        showNotification("Não foi possivel executar essa operação, nenhum registro de setor foi encontrado!", type = "error")

        if (!is.null(processo.now))
        {
          processo.now$start()
        }
        event.click <<- FALSE
        DBI::dbDisconnect(con)
        removeProgressLoader(1000)

        rm(list = ls(all.names = T,envir = env),envir = env)
        gc()
        return()
      }

      if(nrow(estruturas) == 0){

        showNotification("Não foi possivel executar essa operação, nenhum registro de estruturas foi encontrado!", type = "error")

        if (!is.null(processo.now))
        {
          processo.now$start()
        }
        event.click <<- FALSE
        DBI::dbDisconnect(con)
        removeProgressLoader(1000)

        rm(list = ls(all.names = T,envir = env),envir = env)
        gc()
        return()
      }

      if(nrow(objetos) == 0){

        showNotification("Não foi possivel executar essa operação, nenhum registro de objetos foi encontrado ou ativos!", type = "error")

        if (!is.null(processo.now))
        {
          processo.now$start()
        }
        event.click <<- FALSE
        DBI::dbDisconnect(con)
        removeProgressLoader(1000)

        rm(list = ls(all.names = T,envir = env),envir = env)
        gc()
        return()
      }

      if(nrow(plots) == 0){

        showNotification("Não foi possivel executar essa operação, nenhum registro de graficos foi encontrado!", type = "error")

        if (!is.null(processo.now))
        {
          processo.now$start()
        }
        event.click <<- FALSE
        DBI::dbDisconnect(con)
        removeProgressLoader(1000)

        rm(list = ls(all.names = T,envir = env),envir = env)
        gc()
        return()
      }

      #obtem os setores que tem plot
      setores <- setores %>% filter(CD_ID_SETOR %in% plots$CD_ID_SETOR)

      uiPlotTable(con,input,output,plots,tipoPlots,setores,typedatas,estruturas,objetos,callback = function() {

        if (!is.null(processo.now))
        {
          processo.now$start()
        }
        event.click <<- FALSE
        
        rm(list = ls(all.names = T,envir = env),envir = env)
        gc()

      })

    })
  })


})

shinyjs::onclick('plotTools',{
  
  if(event.click) return(NULL)
  
   event.click <<- TRUE
  
  if(!is.null(processo.now))
  {
    processo.now$stop()
  }
  
  actionWebUser(function(){
    
    env <- environment()
    
    source('control/Database.R',encoding = "UTF-8",env)
    
    con <- newConnection()
    
    tryResetConnection(con,function(con){
      
      source('control/Setor_DAO.R',encoding = 'UTF-8',env)
      source('control/Plot_DAO.R',encoding = 'UTF-8',env)
      source('view/uiPlot.R',encoding = 'UTF-8',env) 
      source('model/Dialog.R',encoding = 'UTF-8',env)
      source('model/Swiper.R',encoding = 'UTF-8',env)
      source('model/Map.R',encoding = 'UTF-8',env)
      
      setores    <- selectSetoresOnly(con,user)
      
      if(nrow(setores) == 0){
        
        showNotification("Não foi possivel executar essa operação, nenhum registro de setor foi encontrado!", type = "error")
        
        if (!is.null(processo.now))
        {
          processo.now$start()
        }
        event.click <<- FALSE
        DBI::dbDisconnect(con)
        removeProgressLoader(1000)
        rm(list = ls(all.names = T,envir = env),envir = env)
        gc()
        return()
      }
      
      setores <- setores %>% filter(COUNT_PLOTS  > 0)
      
      if(nrow(setores) == 0){
        
        showNotification("Não foi possivel executar essa operação, nenhum registro de grafico foi encontrado!", type = "error")
        
        if (!is.null(processo.now))
        {
          processo.now$start()
        }
        event.click <<- FALSE
        DBI::dbDisconnect(con)
        removeProgressLoader(1000)
        rm(list = ls(all.names = T,envir = env),envir = env)
        gc()
        return()
      }
      
      #New Dialog
      uiConfigTools(con,input,output,setores,function(){
        
        event.click <<- FALSE
        
        rm(list = ls(all.names = T,envir = env),envir = env)
        gc()
        
      })
      
      
    })
    
  })
  
})

#Email
shinyjs::onclick("contatoNew",{
  
  if(event.click) return(NULL)
  
   event.click <<- TRUE
  
  if(!is.null(processo.now))
  {
    processo.now$stop()
  }
  
  actionWebUser(function(){
    
    env <- environment()
    
    source('control/Database.R',encoding = "UTF-8",env)
    
    con     <- newConnection()
    
    tryResetConnection(con,function(conn){
      
      con <<- conn
      source('view/uiContato.R',encoding = 'UTF-8',env) 
      source('model/Dialog.R',encoding = 'UTF-8',env)
      source('model/Swiper.R',encoding = 'UTF-8',env)
      # New Dialog
      uiContatoNew(
        con = con,
        input = input,
        output = output,
        user = user,
        callback = function(setor) {
          
          if(!is.null(processo.now))
          {
            processo.now$start()
          }
          event.click <<- FALSE
          
          rm(list = ls(all.names = T,envir = env),envir = env)
          gc()
          
        })  
      
    })
    
  })
  
})

shinyjs::onclick('contatoTable',{
  
  if(event.click) return(NULL)
  
   event.click <<- TRUE
  
  if(!is.null(processo.now))
  {
    processo.now$stop()
  }
  
  actionWebUser(function(){
    
    env <- environment()
    
    source('control/Database.R',encoding = "UTF-8",env)
    
    con     <- newConnection()
    
    tryResetConnection(con,function(conn){
      
      con <<- conn 
      source('view/uiContato.R',encoding = 'UTF-8',env)
      source('model/Dialog.R',encoding = 'UTF-8',env)
      source('model/Swiper.R',encoding = 'UTF-8',env)
      source('control/Contatos_DAO.R',encoding = 'UTF-8',env)
      
      contatos <- selectContatosDao(con,user)
      
      if(nrow(contatos) == 0){
        
        showNotification("Não foi possivel executar essa operação, nenhum registro de cantato foi encontrado!", type = "error")
        
        if (!is.null(processo.now))
        {
          processo.now$start()
        }
        event.click <<- FALSE
        DBI::dbDisconnect(con)
        removeProgressLoader(1000)
        
        rm(list = ls(all.names = T,envir = env),envir = env)
        gc()
        return()
      }
      
      uiContatoTable(input = input,output = output,user = user,con = con,contatos = contatos,callback = function(){
        
        if(!is.null(processo.now))
        {
          processo.now$start()
        }
        event.click <<- FALSE
        
        rm(list = ls(all.names = T,envir = env),envir = env)
        gc()
      })
      
    })
    
  })
  
})

#User
shinyjs::onclick('userNew',{
  
  if(event.click) return(NULL)
  
   event.click <<- TRUE
  
  if(!is.null(processo.now))
  {
    processo.now$stop()
  }
  
  actionWebUser(function(){
    
    env <- environment()
    
    source('control/Database.R',encoding = "UTF-8",env)
    
    con     <- newConnection()
    
    tryResetConnection(con,function(conn){
      
      con <<- conn
      source('view/uiUser.R',encoding = 'UTF-8',env)
      source('model/Dialog.R',encoding = 'UTF-8',env)
      source('control/Setor_DAO.R',encoding = 'UTF-8',env)
      
      setores    <- selectSetoresOnly(con,user)
      
      uiUserNew(con,input,output,user,setores,function(){
        
        if(!is.null(processo.now))
        {
          processo.now$start()
        }
        event.click <<- FALSE
        rm(list = ls(all.names = T,envir = env),envir = env)
        gc()
      })
      
    })
    
  })
  
})

#User
shinyjs::onclick('userTable',{
  
  if(event.click) return(NULL)
  
  event.click <<- TRUE
  
  if(!is.null(processo.now))
  {
    processo.now$stop()
  }
  
  actionWebUser(function(){
    
    env <- environment()
    
    source('control/Database.R',encoding = "UTF-8",env)
    
    con     <- newConnection()
    
    tryResetConnection(con,function(conn){
      
      con <<- conn
      source('view/uiUser.R',encoding = 'UTF-8',env)
      source('model/Dialog.R',encoding = 'UTF-8',env)
      source('control/Users.R',encoding = 'UTF-8',env)
      source('model/Swiper.R',encoding = 'UTF-8',env)
      source('control/Setor_DAO.R',encoding = 'UTF-8',env)
      
      setores    <- selectSetoresOnly(con,user)
      usuarios   <- selectAllChildrenOfUser(con,user)
      
      if(nrow(usuarios) == 0){
        
        showNotification("Não foi possivel executar essa operação, nenhum registro de usuarios foi encontrado!", type = "error")
        
        if (!is.null(processo.now))
        {
          processo.now$start()
        }
        event.click <<- FALSE
        DBI::dbDisconnect(con)
        removeProgressLoader(1000)
        
        rm(list = ls(all.names = T,envir = env),envir = env)
        gc()
        return()
      }
      
      uiUserTable(con,input,output,setores,user,usuarios,function(){
        
        if(!is.null(processo.now))
        {
          processo.now$start()
        }
        event.click <<- FALSE
        
        rm(list = ls(all.names = T,envir = env),envir = env)
        gc()
      })
      
    })
    
  })
  
})

#Monitor
shinyjs::onclick('alarmeNew',{
  
  if(event.click) return(NULL)
  
  event.click <<- TRUE
  
  if(!is.null(processo.now))
  {
    processo.now$stop()
  }
  
  actionWebUser(function(){
    
    env <- environment()
    
    source('control/Database.R',encoding = "UTF-8",env)
    
    con     <- newConnection()
    
    tryResetConnection(con,function(conn){
      
      con <<- conn
      source('view/uiAlarme.R',encoding = 'UTF-8',env)
      source('model/Dialog.R',encoding = 'UTF-8',env)
      source('model/Swiper.R',encoding = 'UTF-8',env)
      source('control/Contatos_DAO.R',encoding = 'UTF-8',env)
      source('control/Setor_DAO.R',encoding = 'UTF-8',env)
      source('control/Agendamento_DAO.R',encoding = 'UTF-8',env)
      source('control/Server_DAO.R',env)
      
      setores <- selectSetores(con,user)
      servers <- selectAllServerWithDriver(con)
      
      if(length(setores) == 0){
        
        showNotification("Não foi possivel executar essa operação, nenhum registro de setor foi encontrado!", type = "error")
        
        if (!is.null(processo.now))
        {
          processo.now$start()
        }
        event.click <<- FALSE
        DBI::dbDisconnect(con)
        removeProgressLoader(1000)
        
        rm(list = ls(all.names = T,envir = env),envir = env)
        gc()
        return()
      }

      if(!all(sapply(setores, function(setor) length(setor$OBJETOS)))){
        
        showNotification("Não foi possivel executar essa operação, nenhum registro de objeto foi encontrado!", type = "error")
        
        if (!is.null(processo.now))
        {
          processo.now$start()
        }
        event.click <<- FALSE
        DBI::dbDisconnect(con)
        removeProgressLoader(1000)
        
        rm(list = ls(all.names = T,envir = env),envir = env)
        gc()
        return()
      }
      
      uiAlarmeNew(input,output,con,setores,servers,function(){
        
        if(!is.null(processo.now))
        {
          processo.now$start()
        }
        event.click <<- FALSE
        
        rm(list = ls(all.names = T,envir = env),envir = env)
        gc()
      })
      
    })
    
  })
  
})

shinyjs::onclick('alarmeTable',{
  
  if(event.click) return(NULL)
  
  event.click <<- TRUE
  
  if(!is.null(processo.now))
  {
    processo.now$stop()
  }
  
  actionWebUser(function(){
    
    env <- environment()
    
    source('control/Database.R',encoding = "UTF-8",env)
    
    con     <- newConnection()
    
    tryResetConnection(con,function(conn){
      
      con <<- conn
      source('view/uiAlarme.R',encoding = 'UTF-8',env)
      source('model/Dialog.R',encoding = 'UTF-8',env)
      source('model/Swiper.R',encoding = 'UTF-8',env)
      source('control/Contatos_DAO.R',encoding = 'UTF-8',env)
      source('control/Setor_DAO.R',encoding = 'UTF-8',env)
      source('control/Agendamento_DAO.R',encoding = 'UTF-8',env)
      source('control/Alarme_DAO.R',env)
      
      setores <- selectSetores(con,user)
      alarmes <- selectAllAlarmesDAO(con)
      
      if(nrow(alarmes) == 0){
        
        showNotification("Não foi possivel executar essa operação, nenhum registro de alarmes foi encontrado!", type = "error")
        
        if (!is.null(processo.now))
        {
          processo.now$start()
        }
        event.click <<- FALSE
        DBI::dbDisconnect(con)
        removeProgressLoader(1000)
        
        rm(list = ls(all.names = T,envir = env),envir = env)
        gc()
        return()
      }
      
      if(length(setores) == 0){
        
        showNotification("Não foi possivel executar essa operação, nenhum registro de setor foi encontrado!", type = "error")
        
        if (!is.null(processo.now))
        {
          processo.now$start()
        }
        event.click <<- FALSE
        DBI::dbDisconnect(con)
        removeProgressLoader(1000)
        
        rm(list = ls(all.names = T,envir = env),envir = env)
        gc()
        return()
      }
      
      if(!all(sapply(setores, function(setor) length(setor$OBJETOS)))){
        
        showNotification("Não foi possivel executar essa operação, nenhum registro de objeto foi encontrado!", type = "error")
        
        if (!is.null(processo.now))
        {
          processo.now$start()
        }
        event.click <<- FALSE
        DBI::dbDisconnect(con)
        removeProgressLoader(1000)
        
        rm(list = ls(all.names = T,envir = env),envir = env)
        gc()
        return()
      }
      
      uiAlarmeTable(input,output,con,setores,alarmes,function(){
        
        if(!is.null(processo.now))
        {
          processo.now$start()
        }
        event.click <<- FALSE
        
        rm(list = ls(all.names = T,envir = env),envir = env)
        gc()
      })
      
    })
    
  })
  
})

shinyjs::onclick('funcaoNew',{
  
  if(event.click) return(NULL)
  
  event.click <<- TRUE
  
  if (!is.null(processo.now))
  {
    processo.now$stop()
  }
  
  actionWebUser(function() {
    
    env <- environment()
    
    source('control/Database.R',encoding = "UTF-8",env)
    
    con   <- newConnection()
    
    tryResetConnection(con,function(conn){
      
      con <<- conn
      
      source('view/uiFunction.R',encoding = 'UTF-8',env)
      source('model/Dialog.R',encoding = 'UTF-8',env)
      source('model/Swiper.R',encoding = 'UTF-8',env)
      source('control/Funcation.R',env)
      source('control/Model_DAO.R',env)
      
      estruturas <- selectAllEstruturas(con)
      
      if(nrow(estruturas) == 0){
        
        showNotification("Não foi possivel executar essa operação, nenhum registro de estruturas foi encontrada!", type = "error")
        
        if (!is.null(processo.now))
        {
          processo.now$start()
        }
        event.click <<- FALSE
        DBI::dbDisconnect(con)
        removeProgressLoader(1000)
        
        rm(list = ls(all.names = T,envir = env),envir = env)
        gc()
        return()
      }

      uiFunctionNew(con, input, output,estruturas, callback = function() {
        
        if (!is.null(processo.now))
        {
          processo.now$start()
        }
        event.click <<- FALSE
        
        rm(list = ls(all.names = T,envir = env),envir = env)
        gc()
        
      })
      
    })
  })
})

shinyjs::onclick('funcaoTable',{
  
  if(event.click) return(NULL)
  
  event.click <<- TRUE
  
  if (!is.null(processo.now))
  {
    processo.now$stop()
  }
  
  actionWebUser(function() {
    
    env <- environment()
    
    source('control/Database.R',encoding = "UTF-8",env)
    
    con     <- newConnection()
    
    tryResetConnection(con,function(conn){
      
      con <<- conn
      
      source('view/uiFunction.R',encoding = 'UTF-8',env)
      source('model/Dialog.R',encoding = 'UTF-8',env)
      source('model/Swiper.R',encoding = 'UTF-8',env)
      source('control/Funcation.R',env)
      source('control/Model_DAO.R',env)
      
      estruturas <- selectAllEstruturas(con)
      funcoes    <- selectAllFuncao(con)
      
      if(nrow(funcoes) == 0){
        
        showNotification("Não foi possivel executar essa operação, nenhum registro de funções foi encontrado!", type = "error")
        
        if (!is.null(processo.now))
        {
          processo.now$start()
        }
        event.click <<- FALSE
        DBI::dbDisconnect(con)
        removeProgressLoader(1000)
        
        rm(list = ls(all.names = T,envir = env),envir = env)
        gc()
        return()
      }
      
      uiFunctionTable(con, input, output,estruturas,funcoes, callback = function() {
        
        if (!is.null(processo.now))
        {
          processo.now$start()
        }
        event.click <<- FALSE
        
        rm(list = ls(all.names = T,envir = env),envir = env)
        gc()
        
      })
      
    })
  })
})
#Tab selecao de Setores
observeEvent(input$tabsetSetor,{
  
  if(event.click) return(NULL)
  
  event.click <<- TRUE
  
  actionWebUser(function(){
    
    if(!is.null(processo.now)){
      processo.now$stop(remover = TRUE)
    }
    
    processo.now <<- processos[[which(lapply(processos, function(p) p$id == input$tabsetSetor)  == TRUE)]]
    processo.now$start(inserir = TRUE)
    event.click <<- FALSE
  })
  
},ignoreInit = TRUE)

#Evento no qual o status do processo é alterado
observeEvent(input$statusProcesso,{
  
  status <- input$statusProcesso
  icone  <- ifelse(input$statusProcesso,'pause','play')
  
  shinyjs::onclick('btStatusProcesso',{
    
    if(is.null(processo.now)) return()
    
    if(input$statusProcesso){
      
      actionWebUser(function(){
        
        print('stop')
        processo.now$stop(manual = TRUE)
        
      },auto.remove = TRUE)
      
    }else{
      print('start')
      processo.now$start(inserir = FALSE,manual = TRUE)
    }
    
  })
  
  output$containerPlay <- renderUI({
    
    tagList(
      actionButton('btStatusProcesso',label = '',icon = icon(icone)),
      bsTooltip(
        'btStatusProcesso',
        'Inicia ou para o monitoramento do setor no qual está selecionado.',
        placement = "right",
        trigger = "hover",
        options =  list(container = "body")
      )
    )
    
  })
  
},priority = 20)

#Evento drop notificacao
observeEvent(input$dropNotification,{
  
  if(length(inputListNotificationNotRead) > 0){
    
    rm(list = ls(all.names = TRUE)) #will clear all objects includes hidden objects.
    gc()
    
    disableAllNotification(inputListNotificationNotRead,function(){
      inputListNotificationNotRead <<- list()
    })
    
  }
  
  inputDropsNotification(list())
  
},priority = 1)

#listener esperando novas notificacao
observeEvent(reactiveNotification(),{
  
  mensagensNotification <- reactiveNotification()

  tryCatch({
    
    for (i in 1:nrow(mensagensNotification)) {
      
      cd_id_online      <- mensagensNotification$CD_ID_ONLINE[i]
      
      if(rlist::list.any(inputListNotificationNotRead,CD_ID_ONLINE == cd_id_online))
        next
      
      nome.alarme       <- mensagensNotification$NAME_ALARME[i]
      hora              <- format(mensagensNotification$DT_HR_LOCAL[i], "%d/%m/%y %H:%M")
      setor             <- mensagensNotification$NAME_SETOR[i]
      object            <- mensagensNotification$NAME_OBJECT[i]
      origem            <- paste0(setor,' - ',object)
      titulo            <- paste0(nome.alarme,', ',origem,' AS ',hora)
      message           <- mensagensNotification$DESCRICAO_ALARME[i]
      status            <- mensagensNotification$STATUS[i]
      
      component         <- tags$li(tags$div(
        style = paste0('color: gray;  border-bottom: 1px solid gray; padding: 10px; cursor: pointer;'),
        span(style = paste0('padding-left: 1px; color: ', textStatus(status)),
             iconStatus(status),
             span(style = 'margin-left: 10px;',titulo)
        ),
        div(message)
      ),br())
      
      inputListNotificationNotRead <<- rlist::list.insert(inputListNotificationNotRead,1,mensagensNotification[i,c("CD_ID_ONLINE","DT_HR_LOCAL")])
      inputDropsNotification(rlist::list.insert(inputDropsNotification(),1,component))
      
    }
    
  },error = function(e){
    print(paste0('Location = reactiveNotification(), error = ',e))
  })
  
},priority = 0)

#User logout
shinyjs::onclick('menulogout',{
  
  if(!is.null(processo.now))
  {
    processo.now$stop()
  }
  
  actionWebUser(function(){
    
    env <- environment()
    
    source('control/Database.R',encoding = "UTF-8",env)
    source('view/uiLogin.R',encoding = "UTF-8",env)
    
    con     <- newConnection()
    
    tryResetConnection(con,function(conn){
      
      con <<- conn
      source('model/Dialog.R',encoding = 'UTF-8',env)
      
      dialogConfirm(
        title = 'Confirma saída',
        text = 'Deseja realmente fechar está sessão atual?',
        type = "question",
        callback = function(status) {
          
          #logout yes
          if(status){
            inputListNotificationNotRead <<- list()
            queeNotification$consumer$stop()
            queeNotification$destroy()
            
            #destroy cada setor
            sapply(processos, function(x) {
              #remove tab dos dashboard dos setores
              removeTab(inputId = 'tabsetSetor',target = as.character(x$id))
              x$destroy(default = TRUE)
            })
            
            updateUserOnline(con,user, FALSE)
            
            #define NULL
            output$sidebarMenu  <- NULL
            user               <<- NULL
            processos          <<- NULL
            processo.now       <<- NULL
            queeNotification   <<- NULL
            
            env$uiLogin(
              input = input,
              output    = output,
              session   = session,
              translate = translate,
              callback  = function(con,session.user){
                
                source('control/Database.R',local  = T)
                source('control/Setor_DAO.R',local = T)
                
                systemCache <<- cachem::cache_disk(max_size = Inf,missing = NULL)
                user        <<- session.user
                setores     <-  selectSetoresOnly(con,user)
                processos   <<- uiTabSetores(input,output,setores)
                
                eventObserveDropClosed('dropsAlertas','dropNotification')
                #start processo de notificacao
                queeNotification <<- processaMessageOnline('reactiveNotification')
                
                rm(list = ls(all.names = TRUE,envir = environment())) #will clear all objects includes hidden objects.
                rm(list = ls(all.names = T,envir = env.global),envir = env.global)
                
                gc()
                
              })
            
          }
          else{
            DBI::dbDisconnect(con)
            rm(list = ls(all.names = T,envir = env),envir = env)
            gc()
          }
          
        })
      
    })
    
  },auto.remove = T,delay = 0)
  
})