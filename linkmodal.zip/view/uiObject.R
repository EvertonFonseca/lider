uiObjectNew <- function(con,input,output,setores,estruturas,callback){
  
  source('model/SmartObserve.R',local = T)
  obs      <- newObserve()
  resete   <- reactiveVal()
 
  id <- 'dialogObj'
  cssStyle <- list()
  cssStyle[[paste0(' #parent',id,' .modal-dialog')]]  <- paste0('height: 450px !important;')
  cssStyle[[paste0(' #parent',id,' .modal-content')]] <- paste0('width: 100% !important; height: 100% !important;')
  cssStyle[[paste0(' #parent',id,' .modal-body')]]    <- paste0('width: 100% !important; height: calc(100% - 57px - 65px) !important; overflow-y: hidden;')
  
  showModal(
    shiny::div(
      id = paste0('parent', id),
      style = paste0("height: 100%;"),
      shinyjs::inlineCSS(cssStyle),
      dialogModal(
        title = dialogTitleClose('Novo Objeto',function(){
          
          #destroy all observe events
          DBI::dbDisconnect(con)
          obs$destroy()
          removeModal()
          callback()
          
        }),
        size = 'm',
        uiOutput(outputId = 'renderContainer',style = 'height: 100%; width: 100%; overflow-y: hidden;'),
        footer = tagList(actionButton(inputId = "btSair","Voltar"),actionButton('btSalvar','Salvar'))))
  )
  
  obs$add(observeEvent(input$comboEstrutura,{
    
    nameStruct <- input$comboEstrutura
    
    estrutura <- estruturas %>% filter(NAME_STRUCT == nameStruct)
    
    output$atributoKey <- renderUI({
      
      textInput('textIdObject',label = estrutura$ID_ATRIBUTO,placeholder = 'Digite o registro desse atributo',value = isolate(input$textIdObject))
      
    })
    
  }))
  
  output$renderContainer <- renderUI({
    
    resete()
    updateTextInput(inputId = 'textIdObject',value = '')
    
    tagList(
      shinyjs::inlineCSS("#textNameObject {text-transform: uppercase;}"),
      selectInput('comboSetor',label = 'Seleciona Setor',choices = setores$NAME_SETOR),
      selectInput('comboEstrutura',label = 'Estrutura',choices = estruturas$NAME_STRUCT),
      uiOutput('atributoKey'),
      textInput('textNameObject',label = 'Nome',placeholder   = 'Digite o nome para o objeto')
    )
    
  })
  
  obs$add(observeEvent(input$btSalvar,{

     setor      <- setores %>% filter(NAME_SETOR == isolate(input$comboSetor))
     estrutura  <- estruturas %>% filter(NAME_STRUCT == isolate(input$comboEstrutura))
     idAtributo <- isolate(input$textIdObject)
     nome       <- toupper(isolate(input$textNameObject))

     if(stringi::stri_isempty(stringr::str_trim(idAtributo))){
       
       showNotification("O ID não foi preenchido!", type = "error")
       
       return()
     } 
     
    if(stringi::stri_isempty(stringr::str_trim(nome))){
      
      showNotification("O nome não foi preenchido!", type = "error")
      
      return()
    }
    
    if(checkifExistNameObject(con = con,name = nome)){
      
       showNotification("O nome já possui nos registros!", type = "error")
    }
    else if(checkifExistIdObject(con = con,name = idAtributo,estrutura$CD_ID_STRUCT)){
       
       showNotification("O id já possui nos registros!", type = "error")
    }
    else{
      
      tryResetConnection(con,function(coon){
        
        con <<- coon
        
        insertTable(con,'OBJECT',list(
          ID_OBJECT    = idAtributo,
          NAME_OBJECT  = nome,
          CD_ID_SETOR  = setor$CD_ID_SETOR,
          CD_ID_STRUCT = estrutura$CD_ID_STRUCT,
          FG_ONLINE    = 1
        ))
        
        dialogConfirm(
          title = 'Objeto criado com sucesso!',
          text = 'Deseja criar novamente um novo objeto?',
          callback = function(status) {
        
            if(!status){
              DBI::dbDisconnect(con)
              obs$destroy()
              callback()
              removeModal()
            }
            else
              resete(Sys.time())
          })
        
      })
    }
    
  },ignoreInit = T))
  
  obs$add(observeEvent(input$btSair,{
    
    #destroy all observe events
    DBI::dbDisconnect(con)
    obs$destroy()
    removeModal()
    callback()
    
  },ignoreInit = T))
  
}



uiObjectTable <- function(con,input,output,setores,estruturas,objetos,callback){
  
  source('model/SmartObserve.R',local = T)
  obs   <- newObserve()
  obs2  <- newObserve()
  
  observeEvents  <- list()
  objetos        <- reactiveVal(objetos)
  objeto         <- NULL
  sliderPosition <- reactiveVal(1)
  status.object  <- FALSE
  
  id <- 'dialogObj'
  cssStyle <- list()
  cssStyle[[paste0(' #parent',id,' .modal-dialog')]]  <- paste0('height: 650px !important;')
  cssStyle[[paste0(' #parent',id,' .modal-content')]] <- paste0('width: 100% !important; height: 100% !important;')
  cssStyle[[paste0(' #parent',id,' .modal-body')]]    <- paste0('width: 100% !important; height: calc(100% - 57px - 65px) !important; overflow-y: hidden;')
  
  #Modal para Dialog
  showModal(div(
    id = paste0('parent', id),
    style = paste0("height: 100%;"),
    shinyjs::inlineCSS(cssStyle),
    dialogModal(
      title = dialogTitleClose('Registro Objetos',function(){
        
        #destroy all observe events
        DBI::dbDisconnect(con)
        obs$destroy()
        obs2$destroy()
        removeModal()
        callback(status.object)
        
      }),
      size = 'm',
      swiper(id = 'swiperMain',
             parent.style = 'height: 100%; width: 100%;',
             width = '100%',height = '100%',
             swiperSlide(
               style = 'height: 100%; width: 100%; overflow-y: hidden; padding: 5px;',
               uiOutput('slider1',style = 'height: 100%; width: 100%;')
             ),
             swiperSlide(
               style = 'height: 100%; width: 100%; overflow-y: hidden; padding: 5px;',
               uiOutput('slider2',style = 'height: 100%; width: 100%;')
             )
      ),
      footer = uiOutput('uiFooter'),
      callback = function(size){onResizedWindows(list(height = size$height))}
    )
  ))
  
  output$uiFooter <- renderUI({
    
    current <- sliderPosition()
    
    if(current == 1){
      tagList(actionButton('btActionCancel', label = "Sair"))
    }
    else{
      tagList(actionButton('btActionCancel', label = "Voltar"),actionButton('btActionUpdate', label = "Atualizar"))
    }
    
    
  })
  
  output$slider1 <- renderUI({
    
    output$tableDinamica <- DT::renderDataTable({
      
      # future({
      dataset  <-  objetos() %>% filter(NAME_SETOR == input$comboSetor)
      
      if(length(dataset) == 0) return(NULL)
      
      colunaNames <- c('LINHA','OBJETO','ESTRUTURA','ATIVO','VISUALIZAR / EDITAR','REMOVER')
      
      DT::datatable({
        
        dataset %>% 
          mutate_if(is.POSIXct,function(x){ format(x,'%d/%m/%Y %H:%M:%S')})  %>% 
          mutate_if(is.Date,function(x){ format(x,'%d/%m/%Y')}) %>% 
          mutate_if(is.character,toupper) %>% 
          mutate(!!colunaNames[1] :=  1:nrow(dataset),
                 !!colunaNames[2] :=  dataset$NAME_OBJECT,
                 !!colunaNames[3] :=  dataset$NAME_STRUCT,
                 !!colunaNames[4] :=  apply(dataset,1, function(x) {
                   
                   x <- as.list(x)
                   
                   json <- paste0('{"object":"',x$CD_ID_OBJECT,'","status":document.getElementById("',paste0("checkBoxActive",x$CD_ID_OBJECT),'").checked}')  
                   
                   as.character( div(
                     style = "width: auto; height: auto;",
                     prettyToggle(
                       inputId = paste0("checkBoxActive",x$CD_ID_OBJECT),
                       label_on = "Sim",
                       label_off = "Não", 
                       outline = TRUE,
                       plain = TRUE,
                       value = as.logical(as.integer(x$FG_ONLINE)),
                       icon_on = icon("thumbs-up"),
                       icon_off = icon("thumbs-down"),
                       bigger = T,
                       width = 'auto'
                     ),
                     onclick = paste0('Shiny.setInputValue(\"editPressedStatus\",',json,',{priority: "event"})')
                   ))
                   
                 }),
                 !!colunaNames[5] :=  sapply(dataset$CD_ID_OBJECT, function (x) {
                   
                   as.character(
                     actionButton(
                       paste0('btEdit'),
                       label = '',
                       icon = icon('eye'),
                       onclick = paste0('Shiny.setInputValue(\"editPressedRow\","',x,'",{priority: "event"})'),
                       #style = 'background-color: transparent; color: lightblue; border-solid: none;'
                     )
                   )
                 }),
                 !!colunaNames[6] := sapply(dataset$CD_ID_OBJECT, function(x){
                   
                   as.character(
                     actionButton(
                       paste0('btRemove'),
                       label = '',
                       icon = icon('trash'),
                       onclick = paste0('Shiny.setInputValue(\"deletePressedRow\","',x,'",{priority: "event"})'),
                       #style = 'background-color: transparent; color: lightblue; border-solid: none;'
                     )
                   )
                   
                 })
                 
          ) %>% select(colunaNames) %>% arrange(colunaNames[2])
      }, 
      class = 'cell-border stripe',
      extensions = 'Scroller',
      options = list(
        language = list(url = 'js/table/translate.json'),
        dom = 't',
        bSort=FALSE,
        columnDefs = list(list(visible=FALSE, targets=c(0)),list(className = 'dt-center', targets = "_all")),
        deferRender = TRUE,
        scroller = TRUE,
        fixedHeader = TRUE,
        scrollX = TRUE,
        scrollY = '300px'
      ),
      escape = F,
      selection = 'none',
      )  %>% DT::formatStyle(colnames(result), cursor = 'pointer')
      
    })
    
    div(
      style = 'border-style: solid; border-color: white; border-width: 1px; overflow-x: auto;',
      selectInput('comboSetor','Setor',choices = setores$NAME_SETOR),
      DT::dataTableOutput(outputId = 'tableDinamica')
    )
    
  })
  
  output$slider2 <- renderUI({
    
    req(sliderPosition() == 2)
    
    obs2$clear()
    
    obs2$add(observeEvent(input$comboEstruturaEdit,{
      
      nameStruct <- input$comboEstruturaEdit
   
      estrutura <- estruturas %>% filter(NAME_STRUCT == nameStruct)
      
      output$atributoKeyEdit <- renderUI({
        
        textInput('textIdObjectEdit',label = estrutura$ID_ATRIBUTO,placeholder = 'Digite o registro desse atributo',value = objeto$ID_OBJECT)
        
      })
      
    }))
    
    
    tagList(
      shinyjs::inlineCSS("#textNameObjectEdit {text-transform: uppercase;}"),
      selectInput('comboSetorEdit',label = 'Seleciona Setor',choices = setores$NAME_SETOR,selected   = objeto$NAME_SETOR),
      selectInput('comboEstruturaEdit',label = 'Estrutura',choices = estruturas$NAME_STRUCT,selected = objeto$NAME_STRUCT),
      uiOutput('atributoKeyEdit'),
      textInput('textNameObjectEdit',label = 'Nome',placeholder   = 'Digite o nome para o objeto',value = objeto$NAME_OBJECT)
    )
    
  })
  
  
  obs$add(observeEvent(input$editPressedStatus,{
    
    obj  <- input$editPressedStatus
 
     tryResetConnection(con,function(coon){
       
       con <<- coon
       updateTable(con,'OBJECT',paste0('CD_ID_OBJECT = ',obj$object),list(FG_ONLINE = as.integer(obj$status)))
       
       if(!status.object)
          status.object <<- TRUE
     })
    
  },ignoreInit = T))

  obs$add(observeEvent(input$editPressedRow,{
    
    objeto <<- isolate(objetos()) %>% filter(CD_ID_OBJECT == input$editPressedRow)
    
    swiperSlideNext()
    sliderPosition(swiperPosition)
    
  },ignoreInit = T))
  
  obs$add(observeEvent(input$deletePressedRow,{
    
    objeto <- isolate(objetos()) %>% filter(CD_ID_OBJECT == input$deletePressedRow)
    
    messageAlerta(input,
                  title   = paste0('Todos os processos ligado a esse objeto será excluido'),
                  message = paste0('Deseja realmente excluir o objeto',objeto$NAME_OBJECT,"?"),
                  callback.no = function(){
                    
                  },
                  callback.yes = function(){
                    
                    tryResetConnection(con,function(conn){
                      
                      con <<- conn
                      DBI::dbExecute(con,"DELETE FROM OBJECT WHERE CD_ID_OBJECT = ?",params = list(objeto$CD_ID_OBJECT))
                      
                      objetos.tmp <- selectAllObjects(con)
                      
                      if(!status.object)
                          status.object <<- TRUE
                      
                      if(nrow(objetos.tmp) > 0){
                        objetos(objetos.tmp)
                      }
                      else{
                        #destroy all observe events
                        DBI::dbDisconnect(con)
                        obs$destroy()
                        obs2$destroy()
                        swiperDestroy()
                        removeModal()
                        callback(status.object)
                      }

                    })
                    
                    
                  })
    
  },ignoreInit = T))
  
  obs$add(observeEvent(input$btActionCancel,{
    
    current <- swiperPosition
    
    if(current == 1){
      #destroy all observe events
      DBI::dbDisconnect(con)
      obs$destroy()
      obs2$destroy()
      removeModal()
      callback(status.object)
    }
    else{
    
      objeto <<- NULL
      swiperSlidePrevious()
      sliderPosition(swiperPosition)
    }
    
  },ignoreInit = T))
  
  obs$add(observeEvent(input$btActionUpdate,{
    
    setor      <- setores %>% filter(NAME_SETOR == isolate(input$comboSetorEdit))
    estrutura  <- estruturas %>% filter(NAME_STRUCT == isolate(input$comboEstruturaEdit))
    idAtributo <- isolate(input$textIdObjectEdit)
    nome       <- toupper(isolate(input$textNameObjectEdit))

    if(stringi::stri_isempty(stringr::str_trim(idAtributo))){
      
      showNotification("O ID não foi preenchido!", type = "error")
      
      return()
    } 
    
    if(stringi::stri_isempty(stringr::str_trim(nome))){
      
      showNotification("O nome não foi preenchido!", type = "error")
      
      return()
    }
    
    if(checkifExistNameObjectEdit(con = con,name = nome,objeto$CD_ID_OBJECT)){
      
      showNotification("O nome já possui nos registros!", type = "error")
    }
    else if(checkifExistIdObjectEdit(con = con,name = idAtributo,objeto$CD_ID_OBJECT,estrutura$CD_ID_STRUCT)){
      
      showNotification("O id já possui nos registros!", type = "error")
    }
    else{
      
      tryResetConnection(con,function(coon){
        
        con <<- coon
        
        updateTable(con,'OBJECT',paste0('CD_ID_OBJECT = ',objeto$CD_ID_OBJECT),list(
          ID_OBJECT    = idAtributo,
          NAME_OBJECT  = nome,
          CD_ID_SETOR  = setor$CD_ID_SETOR,
          CD_ID_STRUCT = estrutura$CD_ID_STRUCT
        ))
        
        objeto <<- NULL
        objetos(selectAllObjects(con))
        swiperSlidePrevious()
        sliderPosition(swiperPosition)
        
      })
    }
    
  },ignoreInit = T))
  
}
