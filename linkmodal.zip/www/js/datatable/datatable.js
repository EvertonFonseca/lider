    function resizePage() {
        const container = $("#TableContainer");
        const height = container.height() - container.find(".dataTables_scrollHead").height();
        updateDataTable(height + "px");
    };
 
    var resizeTimer;
 
    $(window).resize(function() {
        clearTimeout(resizeTimer);
        resizeTimer = setTimeout(resizePage, 100);
    });
 
    function updateDataTable(scrollHeight) {
        $('#example').DataTable(
            {
                destroy: true,
                paging: false,
                "bFilter": false,
                "bInfo": false,
                scrollY: scrollHeight,
                columnDefs: [{ width: "16%", targets: 0 }]
            }
        );
    }
 
    $(document).ready(function() {
        updateDataTable('1px'); // give it any height, it will be changed by the timer event, but it needs some size for the page to work
        resizeTimer = setTimeout(resizePage, 100);
    });